#!/usr/bin/env python3
"""
CIRCUIT+ — Automated recon pipelines chaining multiple modules.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import (
        Progress, SpinnerColumn, TextColumn,
        BarColumn, TimeElapsedColumn, MofNCompleteColumn
    )
    from rich.live import Live
    from rich.table import Table
    from rich import box
except ImportError:
    pass

from config import Config, append_history
from utils.helpers import (
    make_loot_dir, timestamp, read_lines,
    count_lines, is_valid_domain, write_lines
)
from utils.logger import console, log_ok, log_err, log_info, log_warn, LootLogger


# ── Full Recon Pipeline ───────────────────────────────────────────────────────

def full_recon(domain: str, cfg: Config) -> Optional[Path]:
    """
    Full automated reconnaissance pipeline:
        1. Subdomain enumeration (subfinder + dnsx)
        2. Host probing (httpx)
        3. Web crawling on live hosts (katana + gau)
        4. Vulnerability scan (nuclei)
        5. Port scan on root domain (rustscan + nmap)
        6. Generate summary report

    Args:
        domain: Target domain.
        cfg:    CIRCUIT+ config.

    Returns:
        Path to summary markdown report, or None on failure.
    """
    if not is_valid_domain(domain):
        log_err(f"Invalid domain: '{domain}'")
        return None

    ts = timestamp()
    loot_root = cfg.loot_path / domain.replace('.', '_') / ts
    loot_root.mkdir(parents=True, exist_ok=True)
    logger = LootLogger(loot_root, "workflow_full_recon")

    steps = [
        "Subdomain Enumeration",
        "Host Probing (httpx)",
        "Web Crawling",
        "Vulnerability Scan",
        "Port Scan",
        "Report Generation",
    ]

    console.print(Panel(
        f"[bold bright_green]Full Recon Pipeline[/bold bright_green]\n"
        f"  Target: [cyan]{domain}[/cyan]\n"
        f"  Output: [dim]{loot_root}[/dim]\n"
        f"  Steps:  [white]{len(steps)}[/white]",
        border_style="bright_green",
        title="[bold bright_green]// WORKFLOW[/bold bright_green]",
    ))

    results: Dict[str, Any] = {
        "domain":    domain,
        "timestamp": ts,
        "steps":     {},
    }

    # ── Step 1: Subdomain Enumeration ─────────────────────────────
    _print_step(1, len(steps), "Subdomain Enumeration")
    from modules.recon import subdomain_enum
    subs_file = subdomain_enum(domain, cfg)
    results["steps"]["subdomain_enum"] = {
        "file":  str(subs_file) if subs_file else None,
        "count": count_lines(subs_file) if subs_file else 0,
    }

    if not subs_file or count_lines(subs_file) == 0:
        log_warn("No subdomains found. Continuing with root domain only.")
        # Create a minimal file with just the root domain
        subs_file = loot_root / "recon" / "subdomains.txt"
        subs_file.parent.mkdir(parents=True, exist_ok=True)
        write_lines(subs_file, [domain])

    # ── Step 2: Host Probing ──────────────────────────────────────
    _print_step(2, len(steps), "Host Probing (httpx)")
    from modules.recon import probe_hosts
    web_hosts_file = probe_hosts(str(subs_file), cfg)
    results["steps"]["probe_hosts"] = {
        "file":  str(web_hosts_file) if web_hosts_file else None,
        "count": count_lines(web_hosts_file) if web_hosts_file else 0,
    }

    if not web_hosts_file or count_lines(web_hosts_file) == 0:
        log_warn("No live web hosts found. Skipping web steps.")
        web_hosts_file = None

    # ── Step 3: Web Crawling ──────────────────────────────────────
    _print_step(3, len(steps), "Web Crawling")
    crawl_results: list[str] = []
    if web_hosts_file:
        from modules.web import crawl_target
        live_hosts = read_lines(web_hosts_file)[:10]  # cap at 10 for pipeline
        for host_url in live_hosts:
            try:
                url_list = crawl_target(host_url, cfg)
                if url_list:
                    crawl_results.extend(read_lines(url_list))
            except KeyboardInterrupt:
                log_warn("Crawling interrupted.")
                break
    results["steps"]["crawl"] = {"urls_collected": len(crawl_results)}

    # ── Step 4: Vulnerability Scan ────────────────────────────────
    _print_step(4, len(steps), "Vulnerability Scan (nuclei)")
    if web_hosts_file:
        from modules.web import vuln_scan
        vuln_output = vuln_scan(str(web_hosts_file), cfg)
        results["steps"]["vuln_scan"] = {
            "file":     str(vuln_output) if vuln_output else None,
            "findings": _count_json_findings(vuln_output),
        }
    else:
        log_warn("Skipping vulnerability scan (no live hosts).")
        results["steps"]["vuln_scan"] = {"findings": 0}

    # ── Step 5: Port Scan ─────────────────────────────────────────
    _print_step(5, len(steps), "Port Scan (rustscan + nmap)")
    from modules.network import port_scan
    nmap_output = port_scan(domain, cfg)
    results["steps"]["port_scan"] = {
        "file": str(nmap_output) if nmap_output else None,
    }

    # ── Step 6: Summary Report ────────────────────────────────────
    _print_step(6, len(steps), "Generating Summary Report")
    report_path = _generate_markdown_report(domain, loot_root, results, cfg)

    # Final status panel
    console.print()
    console.print(Panel(
        _format_summary(results, report_path),
        border_style="bright_green",
        title="[bold bright_green]// Pipeline Complete[/bold bright_green]",
    ))

    logger.flush()
    append_history({
        "ts": ts, "action": "full_recon",
        "target": domain, "report": str(report_path)
    })

    return report_path


# ── Web Target Chain ──────────────────────────────────────────────────────────

def web_target_chain(url: str, cfg: Config) -> Optional[Path]:
    """
    Focused web assessment chain on a single URL:
        1. Content discovery (ffuf)
        2. Crawl (katana + gau)
        3. Vulnerability scan (nuclei)

    Args:
        url: Target URL.
        cfg: Config.

    Returns:
        Path to summary report, or None.
    """
    from utils.helpers import normalize_url
    url = normalize_url(url)
    target_name = url.split("//")[-1].split("/")[0].replace(":", "_")

    ts = timestamp()
    loot_root = cfg.loot_path / target_name / ts
    loot_root.mkdir(parents=True, exist_ok=True)

    console.print(Panel(
        f"[bold bright_green]Web Target Chain[/bold bright_green]\n  Target: [cyan]{url}[/cyan]",
        border_style="bright_green",
    ))

    results: Dict[str, Any] = {"target": url, "timestamp": ts, "steps": {}}

    _print_step(1, 3, "Content Discovery (ffuf)")
    from modules.web import content_discovery
    default_wl = str(Path(cfg.wordlist_path) / "SecLists/Discovery/Web-Content/common.txt")
    content_discovery(url, default_wl, cfg)

    _print_step(2, 3, "Crawling (katana + gau)")
    from modules.web import crawl_target
    crawl_target(url, cfg)

    _print_step(3, 3, "Vulnerability Scan (nuclei)")
    # Create a temp file with the single URL for nuclei
    tmp_targets = loot_root / "targets.txt"
    write_lines(tmp_targets, [url])
    from modules.web import vuln_scan
    vuln_scan(str(tmp_targets), cfg)

    log_ok(f"Web chain complete for {url}")
    return loot_root


# ── Network Recon Chain ───────────────────────────────────────────────────────

def network_recon_chain(target: str, cfg: Config) -> Optional[Path]:
    """
    Network recon chain:
        1. RustScan + nmap
        2. Naabu top-1000

    Args:
        target: IP or domain.
        cfg:    Config.
    """
    console.print(Panel(
        f"[bold bright_green]Network Recon Chain[/bold bright_green]\n  Target: [cyan]{target}[/cyan]",
        border_style="bright_green",
    ))

    _print_step(1, 2, "Port Scan (rustscan + nmap)")
    from modules.network import port_scan
    port_scan(target, cfg)

    _print_step(2, 2, "Naabu top-1000")
    from modules.network import naabu_scan
    naabu_scan(target, cfg, ports="top-1000")

    log_ok(f"Network recon complete for {target}")
    return None


# ── Interactive Workflow Menu Handler ─────────────────────────────────────────

def run_workflow_menu(cfg: Config) -> None:
    """Interactive loop for the Workflow submenu."""
    from ui.menus import show_workflow_menu, get_choice, divider

    while True:
        try:
            console.print()
            show_workflow_menu()
            choice = get_choice("workflow> ")

            if choice == "0":
                break

            elif choice == "1":
                divider()
                try:
                    domain = input("\033[92m[?] Target domain: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if domain:
                    full_recon(domain, cfg)

            elif choice == "2":
                divider()
                try:
                    url = input("\033[92m[?] Target URL: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if url:
                    web_target_chain(url, cfg)

            elif choice == "3":
                divider()
                try:
                    target = input("\033[92m[?] Target (IP/domain): \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if target:
                    network_recon_chain(target, cfg)

            elif choice == "99":
                break

            else:
                log_warn(f"Unknown option: {choice}")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break


# ── Report Generator ──────────────────────────────────────────────────────────

def _generate_markdown_report(
    domain: str,
    loot_root: Path,
    results: Dict[str, Any],
    cfg: Config,
) -> Path:
    """
    Generate a structured Markdown summary report.

    Args:
        domain:    Target domain.
        loot_root: Root loot directory for this run.
        results:   Pipeline results dict.
        cfg:       Config.

    Returns:
        Path to generated report file.
    """
    report_path = loot_root / "summary.md"
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    sub_count  = results.get("steps", {}).get("subdomain_enum", {}).get("count", 0)
    host_count = results.get("steps", {}).get("probe_hosts", {}).get("count", 0)
    url_count  = results.get("steps", {}).get("crawl", {}).get("urls_collected", 0)
    findings   = results.get("steps", {}).get("vuln_scan", {}).get("findings", 0)

    md = f"""# CIRCUIT+ Recon Report — {domain}

**Operator:** {cfg.operator_name}
**Date:** {ts}
**Target:** `{domain}`
**Loot Dir:** `{loot_root}`

---

## Summary

| Step | Result |
|------|--------|
| Subdomains Found | {sub_count} |
| Live Web Hosts   | {host_count} |
| URLs Collected   | {url_count} |
| Vulns Found      | {findings} |

---

## Subdomain Enumeration

- Tool: `subfinder` → `dnsx`
- File: `{results.get("steps", {}).get("subdomain_enum", {}).get("file", "N/A")}`
- Total: **{sub_count}** live subdomains

## Host Probing

- Tool: `httpx`
- File: `{results.get("steps", {}).get("probe_hosts", {}).get("file", "N/A")}`
- Live Hosts: **{host_count}**

## Vulnerability Scan

- Tool: `nuclei`
- Severity: `{cfg.nuclei_severity}`
- Findings: **{findings}**
- File: `{results.get("steps", {}).get("vuln_scan", {}).get("file", "N/A")}`

## Port Scan

- Tool: `rustscan` → `nmap`
- File: `{results.get("steps", {}).get("port_scan", {}).get("file", "N/A")}`

---

## Files

```
{loot_root}/
├── recon/
│   ├── subdomains_raw.txt
│   ├── subdomains.txt
│   └── web_hosts.txt
├── web/
│   ├── ffuf_results.json
│   ├── vulns.json
│   └── all_urls.txt
├── network/
│   ├── nmap_detailed.xml
│   └── nmap_detailed.nmap
└── summary.md   ← you are here
```

---

*Generated by CIRCUIT+ — Authorized Use Only*
"""

    report_path.write_text(md, encoding='utf-8')
    log_ok(f"Report written: {report_path}")
    return report_path


# ── Helpers ───────────────────────────────────────────────────────────────────

def _print_step(current: int, total: int, name: str) -> None:
    """Print a pipeline step header."""
    console.print(
        f"\n[bold bright_green]┌─[{current}/{total}][/bold bright_green] "
        f"[white]{name}[/white]"
    )
    console.print("[bright_green]│[/bright_green]")


def _count_json_findings(path: Optional[Path]) -> int:
    """Count findings in a nuclei JSON file."""
    if not path or not path.exists():
        return 0
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        return len(data) if isinstance(data, list) else 0
    except (json.JSONDecodeError, OSError):
        return 0


def _format_summary(results: Dict[str, Any], report: Optional[Path]) -> str:
    """Format pipeline completion summary text."""
    steps = results.get("steps", {})
    subs    = steps.get("subdomain_enum", {}).get("count", 0)
    hosts   = steps.get("probe_hosts", {}).get("count", 0)
    urls    = steps.get("crawl", {}).get("urls_collected", 0)
    findings = steps.get("vuln_scan", {}).get("findings", 0)

    lines = [
        f"  [green]✓[/green] Subdomains:  [cyan]{subs}[/cyan]",
        f"  [green]✓[/green] Live Hosts:  [cyan]{hosts}[/cyan]",
        f"  [green]✓[/green] URLs:        [cyan]{urls}[/cyan]",
        f"  [yellow]★[/yellow] Findings:    [red]{findings}[/red]",
    ]
    if report:
        lines.append(f"\n  [dim]Report → {report}[/dim]")
    return "\n".join(lines)
