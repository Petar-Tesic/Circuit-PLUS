#!/usr/bin/env python3
"""
CIRCUIT+ — Reconnaissance: subdomain enum, DNS brute-force, host probing.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Optional

try:
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    from rich import box
except ImportError:
    pass

from config import Config, append_history
from core.engine import run_tool, run_with_progress, run_piped
from core.validator import assert_tool
from core.parser import (
    parse_httpx_jsonl, print_httpx_results,
    print_subdomain_list,
)
from utils.helpers import (
    is_valid_domain, make_loot_dir, timestamp,
    read_lines, write_lines, merge_files, count_lines, confirm
)
from utils.logger import console, log_ok, log_err, log_info, log_warn, LootLogger

# ── Recon Entry Points ────────────────────────────────────────────────────────

def subdomain_enum(domain: str, cfg: Config) -> Optional[Path]:
    """
    Enumerate subdomains using subfinder piped through dnsx.

    Workflow:
        subfinder -d domain | dnsx → live_subs.txt

    Args:
        domain: Target domain (e.g. example.com).
        cfg:    CIRCUIT+ config object.

    Returns:
        Path to the output subdomains file, or None on failure.
    """
    if not is_valid_domain(domain):
        log_err(f"Invalid domain: {domain}")
        return None

    if not assert_tool("subfinder"):
        return None

    loot = make_loot_dir(cfg.loot_path, domain, "recon")
    logger = LootLogger(loot, "recon")
    subs_raw = loot / "subdomains_raw.txt"
    subs_live = loot / "subdomains.txt"

    log_info(f"Starting subdomain enumeration: {domain}")

    # ── Step 1: subfinder ────────────────────────────────────────
    subfinder_cmd = [
        "subfinder", "-d", domain,
        "-o", str(subs_raw),
        "-silent",
    ]

    rc, stdout, stderr = run_with_progress(
        subfinder_cmd,
        description=f"Enumerating subdomains for {domain}...",
        cwd=loot,
    )

    logger.command(subfinder_cmd, rc, count_lines(subs_raw))

    if not subs_raw.exists() or count_lines(subs_raw) == 0:
        # Fallback: capture stdout if no -o flag output
        if stdout.strip():
            write_lines(subs_raw, stdout.splitlines())
        else:
            log_warn("subfinder found no subdomains.")
            return None

    raw_count = count_lines(subs_raw)
    log_ok(f"subfinder: {raw_count} subdomains found")

    # ── Step 2: dnsx (DNS resolution / alive check) ───────────────
    if assert_tool("dnsx"):
        dnsx_cmd = [
            "dnsx",
            "-l", str(subs_raw),
            "-o", str(subs_live),
            "-silent",
            "-a",           # resolve A records
        ]
        rc2, _, _ = run_with_progress(
            dnsx_cmd,
            description="Resolving live subdomains with dnsx...",
            cwd=loot,
        )
        logger.command(dnsx_cmd, rc2, count_lines(subs_live))

        if subs_live.exists() and count_lines(subs_live) > 0:
            live_count = count_lines(subs_live)
            log_ok(f"dnsx: {live_count} live subdomains")
        else:
            # dnsx found nothing — fall back to raw
            subs_live = subs_raw
            log_warn("dnsx: no resolved hosts; using raw subfinder output.")
    else:
        log_warn("dnsx not found — skipping DNS resolution step.")
        subs_live = subs_raw

    # ── Display Results ───────────────────────────────────────────
    lines = read_lines(subs_live)
    print_subdomain_list(lines, title=f"Subdomains — {domain}")

    logger.ok(f"Subdomain enum complete: {len(lines)} live hosts")
    logger.flush()

    append_history({
        "ts": timestamp(), "action": "subdomain_enum",
        "target": domain, "results": len(lines), "file": str(subs_live)
    })

    log_info(f"Output saved: {subs_live}")
    return subs_live


def dns_brute(domain: str, wordlist: str, cfg: Config) -> Optional[Path]:
    """
    DNS brute-force using massdns (or dnsx if massdns unavailable).

    Args:
        domain:   Target domain.
        wordlist: Path to subdomain wordlist.
        cfg:      Config object.

    Returns:
        Path to merged subdomains file, or None on failure.
    """
    from utils.picker import require_wordlist
    validated_wl = require_wordlist(wordlist, cfg=cfg, context="DNS brute-force")
    if not validated_wl:
        return None
    wordlist_path = Path(validated_wl)
    wordlist = validated_wl

    if not is_valid_domain(domain):
        log_err(f"Invalid domain: {domain}")
        return None

    loot = make_loot_dir(cfg.loot_path, domain, "recon")
    logger = LootLogger(loot, "dns_brute")
    brute_out = loot / "dns_brute.txt"
    merged_out = loot / "subdomains_merged.txt"

    log_info(f"DNS brute-force: {domain} ({count_lines(wordlist_path)} words)")

    if assert_tool("dnsx"):
        # Generate subdomain list with domain appended
        temp_list = loot / "brute_fqdn.txt"
        lines_to_write = []
        for word in read_lines(wordlist_path):
            lines_to_write.append(f"{word}.{domain}")
        write_lines(temp_list, lines_to_write)

        cmd = [
            "dnsx", "-l", str(temp_list),
            "-o", str(brute_out),
            "-silent", "-a",
        ]
        rc, _, _ = run_with_progress(
            cmd,
            description=f"DNS brute-forcing {domain}...",
        )
        logger.command(cmd, rc, count_lines(brute_out))

    elif assert_tool("massdns"):
        resolver_file = Path("/etc/resolv.conf")  # basic fallback
        cmd = [
            "massdns", "-r", str(resolver_file),
            "-t", "A", "-o", "S",
            "-w", str(brute_out),
            str(wordlist_path),
        ]
        rc, _, _ = run_with_progress(cmd, description="massdns brute-force...")
        logger.command(cmd, rc, count_lines(brute_out))
    else:
        log_err("Neither dnsx nor massdns found. Cannot brute-force DNS.")
        return None

    # Merge with existing enumeration results
    existing = loot / "subdomains.txt"
    sources = [f for f in [brute_out, existing] if f.exists() and count_lines(f) > 0]
    if sources:
        total = merge_files(sources, merged_out)
        log_ok(f"Merged results: {total} unique subdomains → {merged_out}")
        append_history({
            "ts": timestamp(), "action": "dns_brute",
            "target": domain, "results": total
        })
        return merged_out

    return brute_out


def probe_hosts(file_path: str, cfg: Config) -> Optional[Path]:
    """
    Probe a list of hosts/domains with httpx for live web services.

    Runs:
        httpx -l file_path -tech-detect -status-code -title -json

    Args:
        file_path: Path to file containing hosts (one per line).
        cfg:       Config object.

    Returns:
        Path to web_hosts.txt output file, or None on failure.
    """
    hosts_file = Path(file_path)
    if not hosts_file.exists():
        from rich.panel import Panel as _P
        _msg = (
            "[bold red][!] Hosts File Not Found[/bold red]\n\n"
            "  Path: [cyan]" + str(file_path) + "[/cyan]\n\n"
            "  [dim]Run [bold]Subdomain Enumeration[/bold] first,\n"
            "  or select a file with one subdomain/IP per line.[/dim]"
        )
        console.print(_P(_msg, border_style="red", expand=False))
        try:
            from utils.picker import pick_file
            ans = input("\033[92m[?] Browse for a hosts file? [Y/n]: \033[0m").strip().lower()
            if ans in ("", "y", "yes"):
                picked = pick_file(
                    title="Select Hosts / Subdomains File",
                    label="Hosts file",
                    must_exist=True,
                    filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
                )
                if picked:
                    hosts_file = Path(picked)
                    file_path = picked
                else:
                    return None
            else:
                return None
        except (EOFError, KeyboardInterrupt):
            return None

    if not assert_tool("httpx"):
        return None

    # Determine target name for loot dir (use parent dirname or filename)
    target_name = hosts_file.parent.parent.name or hosts_file.stem
    loot = make_loot_dir(cfg.loot_path, target_name, "recon")
    logger = LootLogger(loot, "probe_hosts")
    output_file = loot / "web_hosts.json"
    output_txt  = loot / "web_hosts.txt"

    log_info(f"Probing hosts from: {hosts_file}")

    cmd = [
        "httpx",
        "-l", str(hosts_file),
        "-status-code",
        "-tech-detect",
        "-title",
        "-json",
        "-o", str(output_file),
        "-silent",
        "-threads", str(min(cfg.threads, 50)),
        "-timeout", "10",
    ]

    rc, stdout, stderr = run_with_progress(
        cmd,
        description=f"Probing {count_lines(hosts_file)} hosts...",
    )

    logger.command(cmd, rc, 0)

    # Parse and display
    json_output = ""
    if output_file.exists():
        json_output = output_file.read_text(encoding='utf-8')
    elif stdout:
        json_output = stdout

    results = parse_httpx_jsonl(json_output)
    print_httpx_results(results)

    # Write plain text URL list
    live_urls = [r['url'] for r in results if r.get('url')]
    if live_urls:
        write_lines(output_txt, live_urls)
        log_ok(f"Live hosts saved: {output_txt} ({len(live_urls)} hosts)")

    logger.flush()
    append_history({
        "ts": timestamp(), "action": "probe_hosts",
        "target": str(hosts_file), "live": len(live_urls)
    })

    return output_txt if output_txt.exists() else None


def alterx_permutations(domain: str, input_file: str, cfg: Config) -> Optional[Path]:
    """
    Generate subdomain permutations using alterx, then resolve with dnsx.

    Args:
        domain:     Base domain.
        input_file: Path to existing subdomains file.
        cfg:        Config object.

    Returns:
        Path to permutation results file, or None.
    """
    if not assert_tool("alterx"):
        return None

    subs_file = Path(input_file)
    if not subs_file.exists():
        log_err(f"Input file not found: {subs_file}")
        return None

    loot = make_loot_dir(cfg.loot_path, domain, "recon")
    logger = LootLogger(loot, "alterx")
    perm_out = loot / "permutations.txt"
    resolved_out = loot / "permutations_live.txt"

    cmd = [
        "alterx",
        "-l", str(subs_file),
        "-o", str(perm_out),
        "-silent",
    ]

    rc, _, _ = run_with_progress(cmd, description="Generating permutations...")
    logger.command(cmd, rc, count_lines(perm_out))

    if not perm_out.exists():
        log_warn("alterx: no output generated.")
        return None

    log_ok(f"alterx: {count_lines(perm_out)} permutations generated")

    # Resolve with dnsx
    if assert_tool("dnsx"):
        dnsx_cmd = [
            "dnsx", "-l", str(perm_out),
            "-o", str(resolved_out),
            "-silent", "-a",
        ]
        run_with_progress(dnsx_cmd, description="Resolving permutations...")
        log_ok(f"Resolved permutations: {count_lines(resolved_out)}")
        return resolved_out

    return perm_out


# ── Interactive Recon Menu Handler ────────────────────────────────────────────

def run_recon_menu(cfg: Config) -> None:
    """Interactive loop for the Reconnaissance submenu."""
    from ui.menus import show_recon_menu, get_choice, divider
    from ui.effects import clear_screen

    while True:
        try:
            console.print()
            show_recon_menu()
            choice = get_choice("recon> ")

            if choice == "0":
                break

            elif choice == "1":
                # Subdomain Enumeration
                divider()
                try:
                    domain = input("\033[92m[?] Target domain: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if domain:
                    subdomain_enum(domain, cfg)
                else:
                    log_warn("No domain entered.")

            elif choice == "2":
                # DNS Brute-force
                divider()
                try:
                    domain = input("\033[92m[?] Target domain: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if not domain:
                    log_warn("No domain entered.")
                    continue
                from utils.picker import pick_wordlist
                console.print("\n[dim]Select DNS wordlist:[/dim]")
                wordlist = pick_wordlist(cfg=cfg, title="DNS Brute-Force Wordlist")
                if not wordlist:
                    log_warn("No wordlist selected — DNS brute-force cancelled.")
                    continue
                dns_brute(domain, wordlist, cfg)

            elif choice == "3":
                # Probe Hosts
                divider()
                from utils.picker import pick_file
                console.print("\n[dim]Select hosts file (one subdomain/IP per line):[/dim]")
                console.print("  [1] Browse for file  (picker)\n  [2] Type path manually")
                try:
                    pm = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
                except (KeyboardInterrupt, EOFError):
                    continue
                if pm == "2":
                    try:
                        file_path = input("\033[92m[?] Hosts file path: \033[0m").strip()
                    except (KeyboardInterrupt, EOFError):
                        continue
                else:
                    file_path = pick_file(
                        title="Select Hosts / Subdomains File",
                        label="Hosts file",
                        must_exist=True,
                        filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
                    )
                if file_path:
                    probe_hosts(file_path, cfg)
                else:
                    log_warn("No hosts file selected.")

            elif choice == "4":
                # Alterx Permutations
                divider()
                try:
                    domain   = input("\033[92m[?] Target domain: \033[0m").strip()
                    sub_file = input("\033[92m[?] Subdomains file: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if domain and sub_file:
                    alterx_permutations(domain, sub_file, cfg)

            elif choice == "99":
                break

            else:
                log_warn(f"Unknown option: {choice}")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break


# ── Helpers ───────────────────────────────────────────────────────────────────

def _offer_download_seclists(cfg: Config) -> None:
    """Offer to download SecLists if wordlist not found."""
    if confirm("Wordlist not found. Download SecLists (~400MB)?", default=False):
        wl_dir = Path(cfg.wordlist_path)
        wl_dir.mkdir(parents=True, exist_ok=True)
        cmd = ["git", "clone", "--depth", "1",
               "https://github.com/danielmiessler/SecLists.git",
               str(wl_dir / "SecLists")]
        run_with_progress(cmd, description="Downloading SecLists...")
