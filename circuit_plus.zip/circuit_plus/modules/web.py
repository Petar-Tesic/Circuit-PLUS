#!/usr/bin/env python3
"""
CIRCUIT+ — Web assessment: ffuf, nuclei, gobuster, feroxbuster, katana.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, List, Optional

try:
    from rich.console import Console
    from rich.live import Live
    from rich.text import Text
except ImportError:
    pass

from config import Config, append_history
from core.engine import run_tool, run_with_progress, stream_lines
from core.validator import assert_tool
from core.parser import (
    parse_ffuf_file, print_ffuf_results,
    parse_nuclei_line, print_nuclei_finding, print_nuclei_summary,
)
from utils.helpers import (
    is_valid_url, normalize_url, make_loot_dir, timestamp,
    read_lines, write_lines, count_lines, confirm
)
from utils.logger import console, log_ok, log_err, log_info, log_warn, LootLogger


# ── Scan Mode / Wordlist Resolution ──────────────────────────────────────────

# Known relative paths inside the SecLists root
_QUICK_CANDIDATES = [
    "SecLists/Discovery/Web-Content/small.txt",
    "SecLists/Discovery/Web-Content/common.txt",
    "Discovery/Web-Content/small.txt",
    "Discovery/Web-Content/common.txt",
    "small.txt",
    "common.txt",
]

_BIG_CANDIDATES = [
    "SecLists/Discovery/Web-Content/big.txt",
    "SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt",
    "SecLists/Discovery/Web-Content/raft-medium-directories.txt",
    "Discovery/Web-Content/big.txt",
    "Discovery/Web-Content/directory-list-2.3-medium.txt",
    "big.txt",
    "directory-list-2.3-medium.txt",
]

# Direct download URLs for the two key files
_QUICK_URL = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/small.txt"
_BIG_URL   = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/Web-Content/big.txt"


def _find_wordlist_in_dir(wl_root: Path, candidates: list[str]) -> Optional[Path]:
    """
    Walk through candidate relative paths under wl_root.
    Returns the first one that exists and is non-empty.
    """
    for rel in candidates:
        p = wl_root / rel
        if p.exists() and p.stat().st_size > 0:
            return p
    return None


def _download_wordlist(url: str, dest: Path) -> bool:
    """
    Download a single wordlist file with curl or wget.
    Returns True on success.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    import subprocess as _sp
    import shutil as _sh

    if _sh.which("curl"):
        cmd = ["curl", "-sSL", "-o", str(dest), url]
    elif _sh.which("wget"):
        cmd = ["wget", "-q", "-O", str(dest), url]
    else:
        log_err("Neither curl nor wget found — cannot download wordlist.")
        return False

    log_info(f"Downloading {dest.name} …")
    console.print(f"  [dim cyan]  $ {' '.join(cmd)}[/dim cyan]")
    try:
        r = _sp.run(cmd, timeout=120)
        if r.returncode == 0 and dest.exists() and dest.stat().st_size > 100:
            log_ok(f"Downloaded → {dest}")
            return True
        log_err(f"Download failed (exit {r.returncode})")
        return False
    except _sp.TimeoutExpired:
        log_err("Download timed out after 120 s.")
        return False
    except Exception as exc:
        log_err(f"Download error: {exc}")
        return False


def _prompt_fix_missing_wordlist(
    missing_label: str,
    dest_path: Path,
    download_url: str,
    cfg: Config,
) -> Optional[Path]:
    """
    The required wordlist file is missing.
    Offer three recovery options:
      [1] Download it now (single file, fast)
      [2] Download full SecLists (git clone, large)
      [3] Pick manually (file picker)
      [0] Cancel this scan

    Returns a valid Path on success, or None if the user cancels.
    """
    from rich.panel import Panel as _P
    console.print(_P(
        f"[bold yellow][~] Missing Wordlist: {missing_label}[/bold yellow]\n\n"
        f"  Expected at: [cyan]{dest_path}[/cyan]\n\n"
        f"  [1] Download [bold]{dest_path.name}[/bold] only  (~fast, single file)\n"
        f"  [2] Clone full SecLists              (~450 MB, all wordlists)\n"
        f"  [3] Pick a different file            (file picker)\n"
        f"  [0] Cancel scan",
        border_style="yellow", expand=False,
    ))

    try:
        choice = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
    except (EOFError, KeyboardInterrupt):
        return None

    if choice == "0":
        return None

    elif choice == "1":
        if _download_wordlist(download_url, dest_path):
            return dest_path
        log_err("Single-file download failed. Try option [2] or [3].")
        return None

    elif choice == "2":
        import subprocess as _sp
        wl_root = Path(cfg.wordlist_path)
        seclists_dest = wl_root / "SecLists"
        if seclists_dest.exists():
            log_info("SecLists directory exists — pulling latest …")
            cmd = f"git -C {seclists_dest} pull --quiet"
        else:
            wl_root.mkdir(parents=True, exist_ok=True)
            cmd = f"git clone --depth 1 https://github.com/danielmiessler/SecLists.git {seclists_dest}"
        log_info(f"Running: {cmd}")
        r = _sp.run(cmd, shell=True)
        if r.returncode == 0:
            log_ok("SecLists ready.")
            # Now re-scan for the file
            found = _find_wordlist_in_dir(wl_root, _QUICK_CANDIDATES if "small" in str(dest_path) else _BIG_CANDIDATES)
            if found:
                return found
            # Still not found? Fall through to manual
            log_warn(f"Still could not locate {missing_label} after clone.")
        else:
            log_err("git clone failed. Check your internet connection.")
        return None

    elif choice == "3":
        from utils.picker import pick_file
        picked = pick_file(
            title=f"Select {missing_label}",
            label=f"Wordlist file ({missing_label})",
            initial_dir=cfg.wordlist_path,
            must_exist=True,
            filetypes=[("Text wordlists", "*.txt *.lst"), ("All files", "*.*")],
        )
        if picked and Path(picked).exists():
            return Path(picked)
        log_warn("No file selected.")
        return None

    return None


def resolve_scan_wordlist(cfg: Config) -> Optional[str]:
    """
    Prompt the operator to choose Quick or Normal scan mode,
    then resolve and validate the correct SecLists wordlist for that mode.

    Quick  →  SecLists/Discovery/Web-Content/small.txt   (~950 words,  fast)
    Normal →  SecLists/Discovery/Web-Content/big.txt     (~20k words, thorough)

    If the required file is not found under cfg.wordlist_path the operator is
    offered three recovery paths:
      • download the single file directly
      • clone the full SecLists repository
      • pick any file manually

    Returns:
        Absolute path string to the selected wordlist, or None if cancelled.
    """
    from rich.panel import Panel as _P
    from rich.table import Table as _T
    from rich import box as _box

    wl_root = Path(cfg.wordlist_path)

    # Pre-check both files so we can show status in the menu
    quick_path = _find_wordlist_in_dir(wl_root, _QUICK_CANDIDATES)
    big_path   = _find_wordlist_in_dir(wl_root, _BIG_CANDIDATES)

    def _status(p: Optional[Path]) -> str:
        if p:
            try:
                n = sum(1 for _ in open(p, errors="ignore"))
                return f"[green]✓ found[/green]  [dim]({n:,} words) {p.name}[/dim]"
            except Exception:
                return "[green]✓ found[/green]"
        return "[red]✗ missing[/red]"

    tbl = _T(box=_box.SIMPLE_HEAVY, border_style="bright_green",
             show_header=True, header_style="bold bright_green", expand=False)
    tbl.add_column("Mode",        style="bold cyan",  width=10)
    tbl.add_column("Key",         style="dim",         width=5)
    tbl.add_column("Description", style="white",       width=36)
    tbl.add_column("Wordlist",    width=48)

    tbl.add_row("Quick",  "[1]",
                "~950 words · fast baseline scan",
                _status(quick_path), style="on grey11")
    tbl.add_row("Normal", "[2]",
                "~20k words · thorough directory sweep",
                _status(big_path))
    tbl.add_row("Custom", "[3]",
                "Pick any wordlist manually",
                "[dim](file picker)[/dim]")
    tbl.add_row("Cancel", "[0]",
                "Abort scan", "")

    console.print()
    console.print(_P(tbl,
        title="[bold bright_green]// Select Scan Mode[/bold bright_green]",
        border_style="bright_green", expand=False))

    try:
        choice = input("\033[92m  Scan mode [1]: \033[0m").strip() or "1"
    except (EOFError, KeyboardInterrupt):
        return None

    if choice == "0":
        return None

    elif choice == "1":
        # Quick scan — small.txt
        if quick_path:
            log_info(f"Quick scan wordlist: {quick_path.name}")
            return str(quick_path)
        # Missing — offer recovery
        default_dest = wl_root / "SecLists" / "Discovery" / "Web-Content" / "small.txt"
        result = _prompt_fix_missing_wordlist("small.txt (quick scan)", default_dest, _QUICK_URL, cfg)
        return str(result) if result else None

    elif choice == "2":
        # Normal scan — big.txt
        if big_path:
            log_info(f"Normal scan wordlist: {big_path.name}")
            return str(big_path)
        # Missing — offer recovery
        default_dest = wl_root / "SecLists" / "Discovery" / "Web-Content" / "big.txt"
        result = _prompt_fix_missing_wordlist("big.txt (normal scan)", default_dest, _BIG_URL, cfg)
        return str(result) if result else None

    elif choice == "3":
        from utils.picker import pick_wordlist
        return pick_wordlist(cfg=cfg, title="Custom Wordlist")

    else:
        log_warn(f"Invalid choice: {choice}")
        return None


# ── Content Discovery ─────────────────────────────────────────────────────────

def content_discovery(
    url: str,
    wordlist: str,
    cfg: Config,
    extensions: str = "php,html,js,txt,json,asp,aspx,jsp",
    threads: int = 50,
) -> Optional[Path]:
    """
    Fuzz web content with ffuf.

    Args:
        url:        Target URL (FUZZ will be appended as path component).
        wordlist:   Path to wordlist file.
        cfg:        CIRCUIT+ config.
        extensions: Comma-separated file extensions to probe.
        threads:    Number of concurrent requests.

    Returns:
        Path to ffuf JSON results file, or None on failure.
    """
    if not assert_tool("ffuf"):
        return None

    url = normalize_url(url)

    # ── Validate / pick wordlist ─────────────────────────────────────────────
    # If called from pipeline with no wordlist, resolve via scan-mode prompt
    if not wordlist:
        wordlist = resolve_scan_wordlist(cfg) or ""
        if not wordlist:
            log_err("No wordlist — content discovery aborted.")
            return None

    from utils.picker import require_wordlist
    validated_wl = require_wordlist(wordlist, cfg=cfg, context="content discovery (ffuf)")
    if not validated_wl:
        return None
    wl_path = Path(validated_wl)
    wordlist = validated_wl

    target_name = url.split("//")[-1].split("/")[0].replace(":", "_")
    loot = make_loot_dir(cfg.loot_path, target_name, "web")
    logger = LootLogger(loot, "content_discovery")
    output_json = loot / "ffuf_results.json"

    fuzz_url = f"{url}/FUZZ"
    log_info(f"Content discovery: {fuzz_url}")
    log_info(f"Wordlist: {wl_path} ({count_lines(wl_path)} words)")

    cmd = [
        "ffuf",
        "-u", fuzz_url,
        "-w", str(wl_path),
        "-mc", "200,201,204,301,302,307,401,403,405",
        "-t", str(min(threads, cfg.threads)),
        "-timeout", str(cfg.timeout),
        "-o", str(output_json),
        "-of", "json",
        "-s",  # silent mode (no banner)
    ]

    if extensions:
        cmd.extend(["-e", extensions])

    rc, stdout, stderr = run_with_progress(
        cmd,
        description=f"Fuzzing {target_name}...",
        cwd=loot,
    )

    logger.command(cmd, rc, 0)

    # Parse and display
    results = parse_ffuf_file(output_json)
    print_ffuf_results(results)

    if results:
        log_ok(f"Found {len(results)} paths → {output_json}")
    else:
        log_warn("No results found (try different wordlist or extensions)")

    logger.flush()
    append_history({
        "ts": timestamp(), "action": "content_discovery",
        "target": url, "findings": len(results)
    })

    return output_json if output_json.exists() else None


# ── Vulnerability Scan ────────────────────────────────────────────────────────

def vuln_scan(
    target_file: str,
    cfg: Config,
    severity: Optional[str] = None,
) -> Optional[Path]:
    """
    Run nuclei vulnerability scan against a list of targets.

    Args:
        target_file: Path to file with URLs/hosts (one per line).
        cfg:         CIRCUIT+ config.
        severity:    Override severity filter (default from config).

    Returns:
        Path to nuclei JSON results file, or None on failure.
    """
    if not assert_tool("nuclei"):
        return None

    hosts_file = Path(target_file)
    if not hosts_file.exists():
        from rich.panel import Panel as _P
        _msg = (
            "[bold red][!] Target File Not Found[/bold red]\n\n"
            "  Path: [cyan]" + str(target_file) + "[/cyan]\n\n"
            "  [dim]Run Recon \u2192 Probe Hosts first to generate a target file,\n"
            "  or specify a file with one URL/host per line.[/dim]"
        )
        console.print(_P(_msg, border_style="red", expand=False))
        try:
            from utils.picker import pick_file
            ans = input("\033[92m[?] Browse for a target file? [Y/n]: \033[0m").strip().lower()
            if ans in ("", "y", "yes"):
                picked = pick_file(
                    title="Select Nuclei Target File",
                    label="Target file",
                    must_exist=True,
                    filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
                )
                if picked:
                    hosts_file = Path(picked)
                    target_file = picked
                else:
                    return None
            else:
                return None
        except (EOFError, KeyboardInterrupt):
            return None

    sev = severity or cfg.nuclei_severity
    target_name = hosts_file.parent.parent.name or "nuclei_scan"
    loot = make_loot_dir(cfg.loot_path, target_name, "web")
    logger = LootLogger(loot, "vuln_scan")
    output_json = loot / "vulns.json"

    log_info(f"Nuclei scan: {count_lines(hosts_file)} targets | severity={sev}")

    cmd = [
        "nuclei",
        "-l", str(hosts_file),
        "-severity", sev,
        "-json-export", str(output_json),
        "-silent",
        "-stats",
        "-retries", "2",
        "-timeout", "10",
        "-c", str(min(cfg.threads, 25)),
    ]

    log_info("Streaming nuclei findings in real time...")

    findings: list[Dict[str, Any]] = []

    # Stream output for real-time display
    for line in stream_lines(cmd, cwd=loot):
        finding = parse_nuclei_line(line)
        if finding:
            print_nuclei_finding(finding)
            findings.append(finding)
            logger.finding(finding)
        elif line.strip():
            console.print(f"  [dim]{line}[/dim]")

    # Display summary table
    console.print()
    print_nuclei_summary(findings)

    if not output_json.exists() and findings:
        # Write our own collected findings
        output_json.write_text(
            json.dumps(findings, indent=2),
            encoding='utf-8'
        )

    log_ok(f"Nuclei complete: {len(findings)} findings")
    logger.flush()
    append_history({
        "ts": timestamp(), "action": "vuln_scan",
        "target": str(hosts_file), "findings": len(findings)
    })

    return output_json if findings else None


# ── Crawl Target ──────────────────────────────────────────────────────────────

def crawl_target(url: str, cfg: Config) -> Optional[Path]:
    """
    Crawl a target URL with katana, supplement with gau URL harvesting.

    Args:
        url: Target URL.
        cfg: CIRCUIT+ config.

    Returns:
        Path to combined URL list, or None on failure.
    """
    if not assert_tool("katana"):
        return None

    url = normalize_url(url)
    target_name = url.split("//")[-1].split("/")[0].replace(":", "_")
    loot = make_loot_dir(cfg.loot_path, target_name, "web")
    logger = LootLogger(loot, "crawl")
    katana_out = loot / "katana_urls.txt"
    gau_out    = loot / "gau_urls.txt"
    combined   = loot / "all_urls.txt"

    log_info(f"Crawling: {url}")

    # ── katana ────────────────────────────────────────────────────
    katana_cmd = [
        "katana",
        "-u", url,
        "-jc",            # JavaScript crawl
        "-o", str(katana_out),
        "-silent",
        "-depth", "3",
        "-timeout", "10",
    ]

    rc, _, _ = run_with_progress(
        katana_cmd,
        description=f"Crawling {target_name} (katana)...",
    )
    logger.command(katana_cmd, rc, count_lines(katana_out))
    log_ok(f"katana: {count_lines(katana_out)} URLs found")

    # ── gau (Get All URLs) ────────────────────────────────────────
    if assert_tool("gau"):
        domain = target_name
        gau_cmd = ["gau", "--o", str(gau_out), domain]
        rc2, _, _ = run_with_progress(
            gau_cmd,
            description=f"Harvesting archived URLs (gau)...",
        )
        logger.command(gau_cmd, rc2, count_lines(gau_out))
        log_ok(f"gau: {count_lines(gau_out)} URLs harvested")
    else:
        log_warn("gau not found — skipping URL harvesting")

    # ── Merge outputs ─────────────────────────────────────────────
    sources = [f for f in [katana_out, gau_out] if f.exists() and count_lines(f) > 0]
    if sources:
        from utils.helpers import merge_files
        total = merge_files(sources, combined)
        log_ok(f"Combined: {total} unique URLs → {combined}")
        console.print(f"\n[dim]  First 20 URLs:[/dim]")
        for u in read_lines(combined)[:20]:
            console.print(f"  [cyan]{u}[/cyan]")
    else:
        log_warn("No URLs collected.")

    logger.flush()
    append_history({"ts": timestamp(), "action": "crawl", "target": url})
    return combined if combined.exists() else katana_out


# ── Feroxbuster Recursive Discovery ──────────────────────────────────────────

def feroxbuster_scan(url: str, wordlist: str, cfg: Config) -> Optional[Path]:
    """
    Recursive content discovery with feroxbuster.

    Args:
        url:      Target URL.
        wordlist: Path to wordlist file.
        cfg:      Config object.

    Returns:
        Path to feroxbuster output file, or None.
    """
    if not assert_tool("feroxbuster"):
        return None

    url = normalize_url(url)
    # ── Validate / pick wordlist ─────────────────────────────────────────────
    from utils.picker import require_wordlist
    validated_wl = require_wordlist(wordlist, cfg=cfg, context="feroxbuster recursive scan")
    if not validated_wl:
        return None
    wl_path = Path(validated_wl)
    wordlist = validated_wl

    target_name = url.split("//")[-1].split("/")[0].replace(":", "_")
    loot = make_loot_dir(cfg.loot_path, target_name, "web")
    logger = LootLogger(loot, "feroxbuster")
    output = loot / "feroxbuster.txt"

    cmd = [
        "feroxbuster",
        "--url", url,
        "--wordlist", str(wl_path),
        "--output", str(output),
        "--threads", str(min(cfg.threads, 50)),
        "--timeout", str(cfg.timeout),
        "--silent",
        "--no-state",
    ]

    rc, _, _ = run_with_progress(cmd, description=f"Feroxbuster: {target_name}...")
    logger.command(cmd, rc, count_lines(output))

    lines = read_lines(output)
    if lines:
        log_ok(f"feroxbuster: {len(lines)} results → {output}")
        for line in lines[:30]:
            console.print(f"  [cyan]{line}[/cyan]")
    else:
        log_warn("feroxbuster: no results.")

    logger.flush()
    return output if output.exists() else None


# ── Gobuster Scans ───────────────────────────────────────────────────────────

def _gobuster_run(
    mode: str,
    target: str,
    wordlist: str,
    loot: Path,
    cfg: Config,
    extra_flags: list[str] | None = None,
    label: str = "",
) -> tuple[int, Path]:
    """
    Internal: run one gobuster invocation.

    Args:
        mode:        gobuster subcommand (dir/dns/vhost/fuzz/s3).
        target:      -u URL or -d domain depending on mode.
        wordlist:    Path to wordlist.
        loot:        Output directory.
        cfg:         Config.
        extra_flags: Additional flags appended to the command.
        label:       Human description for progress bar.

    Returns:
        (exit_code, output_file_path)
    """
    output = loot / f"gobuster_{mode}_{Path(wordlist).stem}.txt"
    flag_map = {"dir": "-u", "vhost": "-u", "fuzz": "-u", "dns": "-d", "s3": "-u"}
    target_flag = flag_map.get(mode, "-u")

    cmd = [
        "gobuster", mode,
        target_flag, target,
        "-w", wordlist,
        "-o", str(output),
        "-t", str(min(cfg.threads, 50)),
        "--timeout", f"{cfg.timeout}s",
        "-q",
        "--no-error",
    ]
    if extra_flags:
        cmd.extend(extra_flags)

    rc, _, _ = run_with_progress(
        cmd,
        description=label or f"gobuster {mode} ...",
        cwd=loot,
    )
    return rc, output


def _print_gobuster_results(output: Path, mode: str) -> int:
    """Parse and display gobuster output file. Returns line count."""
    if not output.exists():
        log_warn(f"No output file: {output}")
        return 0
    lines = read_lines(output)
    if not lines:
        log_warn(f"gobuster {mode}: no results.")
        return 0

    from rich.table import Table as _T
    from rich import box as _box
    tbl = _T(
        title=f"[bold bright_green]// gobuster {mode.upper()}  ({len(lines)} results)[/bold bright_green]",
        box=_box.SIMPLE_HEAVY, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )

    if mode == "dir":
        tbl.add_column("Status", width=7,  justify="center")
        tbl.add_column("Path",   width=55, style="cyan")
        tbl.add_column("Size",   width=10, style="dim")
        for i, line in enumerate(lines[:150]):
            # gobuster dir format: /path (Status: 200) [Size: 1234]
            import re
            m_status = re.search(r'Status:\s*(\d+)', line)
            m_size   = re.search(r'Size:\s*(\d+)', line)
            m_path   = re.match(r'^(\S+)', line)
            status = m_status.group(1) if m_status else "?"
            size   = m_size.group(1)   if m_size   else ""
            path   = m_path.group(1)   if m_path   else line
            color  = "green" if status.startswith("2") else "yellow" if status.startswith("3") else "red" if status.startswith("4") else "white"
            tbl.add_row(f"[{color}]{status}[/{color}]", path, size,
                        style="on grey11" if i % 2 == 0 else "")
    else:
        tbl.add_column("Result", style="cyan", width=72)
        for i, line in enumerate(lines[:150]):
            tbl.add_row(line, style="on grey11" if i % 2 == 0 else "")

    if len(lines) > 150:
        tbl.add_row(f"[dim]... +{len(lines)-150} more → {output}[/dim]")
    console.print(tbl)
    log_ok(f"gobuster {mode}: {len(lines)} results → {output}")
    return len(lines)


def gobuster_scan(
    url: str,
    wordlist: str,
    cfg: Config,
    mode: str = "dir",
    extensions: str = "php,html,txt,js,asp,aspx,php3,bak,old,zip,tar",
) -> Optional[Path]:
    """
    Normal gobuster scan — single mode against the target URL/domain.

    Args:
        url:        Target URL (or bare domain for dns mode).
        wordlist:   Path to wordlist file (required).
        cfg:        CIRCUIT+ config.
        mode:       'dir', 'dns', 'vhost', 'fuzz', or 's3'.
        extensions: File extensions for dir mode.

    Returns:
        Path to output file, or None on failure.
    """
    if not assert_tool("gobuster"):
        return None

    from utils.picker import require_wordlist
    wordlist = require_wordlist(wordlist, cfg=cfg, context=f"gobuster {mode}") or ""
    if not wordlist:
        return None

    target = normalize_url(url) if mode != "dns" else url.lstrip("https://").lstrip("http://").split("/")[0]
    target_name = target.replace("https://","").replace("http://","").split("/")[0].replace(":","_")
    loot = make_loot_dir(cfg.loot_path, target_name, "web")

    extra: list[str] = []
    if mode == "dir" and extensions:
        extra = ["-x", extensions]
    elif mode == "vhost":
        extra = ["--append-domain"]

    rc, out = _gobuster_run(mode, target, wordlist, loot, cfg,
                            extra_flags=extra,
                            label=f"gobuster {mode}: {target_name}")
    total = _print_gobuster_results(out, mode)
    append_history({"ts": timestamp(), "action": f"gobuster_{mode}",
                    "target": target, "results": total})
    return out if out.exists() else None


def gobuster_full_scan(url: str, cfg: Config) -> Optional[Path]:
    """
    Full multi-vector gobuster scan — 5 scan types chained together.

    Scan types:
      1. Dir scan          — discover directories & files (small.txt)
      2. Dir scan deep     — larger wordlist for thorough file hunting (big.txt)
      3. DNS subdomain     — brute-force subdomains (subdomains wordlist)
      4. VHost enum        — find virtual hosts on the same IP
      5. Backup/sensitive  — hunt for backup & config files (.bak .zip .env etc.)

    Each result is shown in a live table as it completes. A summary table
    is printed at the end. All output saved under loot/.

    Args:
        url: Target URL or domain.
        cfg: CIRCUIT+ config.

    Returns:
        Loot directory path, or None on failure.
    """
    if not assert_tool("gobuster"):
        return None

    from rich.panel import Panel as _P
    from rich.table import Table as _T
    from rich import box as _box

    domain = url.lstrip("https://").lstrip("http://").split("/")[0]
    base_url = normalize_url(url)
    target_name = domain.replace(":","_")
    wl_root = Path(cfg.wordlist_path)
    loot = make_loot_dir(cfg.loot_path, target_name, "web")

    console.print(_P(
        "[bold bright_green]// Gobuster Full Scan[/bold bright_green]\n\n"
        "  Target:  [cyan]" + base_url + "[/cyan]\n"
        "  Domain:  [cyan]" + domain  + "[/cyan]\n"
        "  Output:  [dim]"  + str(loot) + "[/dim]\n\n"
        "  Running 5 scan types in sequence:\n"
        "  [dim]1.[/dim] Dir scan (quick)    [dim]2.[/dim] Dir scan (deep)\n"
        "  [dim]3.[/dim] DNS subdomains      [dim]4.[/dim] VHost enumeration\n"
        "  [dim]5.[/dim] Backup / sensitive files",
        border_style="bright_green", expand=False,
    ))

    # ── Resolve the wordlists we need ─────────────────────────────────────────
    quick_wl = _find_wordlist_in_dir(wl_root, _QUICK_CANDIDATES)
    big_wl   = _find_wordlist_in_dir(wl_root, _BIG_CANDIDATES)
    dns_candidates = [
        "SecLists/Discovery/DNS/subdomains-top1million-5000.txt",
        "SecLists/Discovery/DNS/namelist.txt",
        "SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
        "Discovery/DNS/subdomains-top1million-5000.txt",
        "dns-names.txt",
    ]
    dns_wl = _find_wordlist_in_dir(wl_root, dns_candidates)

    # Backup-file wordlist — built-in tiny list if not found
    backup_candidates = [
        "SecLists/Discovery/Web-Content/raft-medium-files.txt",
        "SecLists/Discovery/Web-Content/common.txt",
        "raft-medium-files.txt",
    ]
    backup_wl = _find_wordlist_in_dir(wl_root, backup_candidates)

    def _check_wl(path: Optional[Path], label: str, url_fallback: str) -> Optional[str]:
        if path:
            log_ok(f"{label}: {path.name}")
            return str(path)
        log_warn(f"{label} not found in wordlist dir.")
        result = _prompt_fix_missing_wordlist(label, wl_root / "SecLists/Discovery" / f"{label}.txt",
                                              url_fallback, cfg)
        return str(result) if result else None

    _QUICK_URL_DNS = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-5000.txt"
    quick_str  = _check_wl(quick_wl,  "small.txt",  _QUICK_URL)
    big_str    = _check_wl(big_wl,    "big.txt",    _BIG_URL)
    dns_str    = _check_wl(dns_wl,    "subdomains-top1million-5000.txt", _QUICK_URL_DNS)
    backup_str = backup_wl and str(backup_wl) or quick_str   # fallback to quick

    summary: list[dict] = []

    # ── Scan 1: Dir quick ─────────────────────────────────────────────────────
    _step_header(1, 5, "Directory scan (quick wordlist)")
    if quick_str:
        rc, out = _gobuster_run("dir", base_url, quick_str, loot, cfg,
                                extra_flags=["-x","php,html,txt,js,asp,aspx"],
                                label="Dir scan (quick)")
        n = _print_gobuster_results(out, "dir")
        summary.append({"scan": "Dir (quick)", "file": out.name, "results": n})
    else:
        log_warn("Skipping dir quick — no wordlist.")
        summary.append({"scan": "Dir (quick)", "file": "—", "results": 0})

    # ── Scan 2: Dir deep ──────────────────────────────────────────────────────
    _step_header(2, 5, "Directory scan (deep — big.txt)")
    if big_str:
        rc, out = _gobuster_run("dir", base_url, big_str, loot, cfg,
                                extra_flags=["-x","php,html,txt,js,asp,aspx,bak,old,zip,env,config,sql"],
                                label="Dir scan (deep)")
        n = _print_gobuster_results(out, "dir")
        summary.append({"scan": "Dir (deep)", "file": out.name, "results": n})
    else:
        log_warn("Skipping dir deep — big.txt missing.")
        summary.append({"scan": "Dir (deep)", "file": "—", "results": 0})

    # ── Scan 3: DNS subdomain brute-force ─────────────────────────────────────
    _step_header(3, 5, "DNS subdomain enumeration")
    if dns_str:
        rc, out = _gobuster_run("dns", domain, dns_str, loot, cfg,
                                extra_flags=["--wildcard"],
                                label="DNS subdomains")
        n = _print_gobuster_results(out, "dns")
        summary.append({"scan": "DNS subdomains", "file": out.name, "results": n})
    else:
        log_warn("Skipping DNS — no subdomain wordlist.")
        summary.append({"scan": "DNS subdomains", "file": "—", "results": 0})

    # ── Scan 4: VHost enumeration ─────────────────────────────────────────────
    _step_header(4, 5, "Virtual host (VHost) enumeration")
    if quick_str:
        rc, out = _gobuster_run("vhost", base_url, quick_str, loot, cfg,
                                extra_flags=["--append-domain", "--exclude-length", "0"],
                                label="VHost enum")
        n = _print_gobuster_results(out, "vhost")
        summary.append({"scan": "VHost enum", "file": out.name, "results": n})
    else:
        summary.append({"scan": "VHost enum", "file": "—", "results": 0})

    # ── Scan 5: Backup / sensitive files ──────────────────────────────────────
    _step_header(5, 5, "Backup & sensitive file hunting")
    if backup_str:
        rc, out = _gobuster_run(
            "dir", base_url, backup_str, loot, cfg,
            extra_flags=["-x", "bak,backup,old,orig,swp,~,tar,tar.gz,zip,7z,"
                                "env,.env,config,cfg,conf,ini,sql,db,log,txt"],
            label="Backup files",
        )
        n = _print_gobuster_results(out, "dir")
        summary.append({"scan": "Backup files", "file": out.name, "results": n})
    else:
        summary.append({"scan": "Backup files", "file": "—", "results": 0})

    # ── Summary table ─────────────────────────────────────────────────────────
    console.print()
    stbl = _T(
        title="[bold bright_green]// Full Scan Summary[/bold bright_green]",
        box=_box.DOUBLE_EDGE, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    stbl.add_column("Scan",    style="bold cyan",  width=20)
    stbl.add_column("Results", width=10, justify="right")
    stbl.add_column("Output",  style="dim", width=40)
    for i, row in enumerate(summary):
        color = "green" if row["results"] > 0 else "dim"
        stbl.add_row(
            row["scan"],
            f"[{color}]{row['results']}[/{color}]",
            row["file"],
            style="on grey11" if i % 2 == 0 else "",
        )
    console.print(stbl)
    log_ok(f"Full scan complete. All results saved to: {loot}")
    append_history({"ts": timestamp(), "action": "gobuster_full",
                    "target": url, "scans": len(summary),
                    "total": sum(r["results"] for r in summary)})
    return loot


def _step_header(n: int, total: int, label: str) -> None:
    """Print a numbered step header for multi-scan output."""
    console.print(
        f"\n[bold bright_green]\u250c\u2500 [{n}/{total}][/bold bright_green] "
        f"[white]{label}[/white]\n[bright_green]\u2502[/bright_green]"
    )




# ── Interactive Web Menu Handler ──────────────────────────────────────────────

def run_web_menu(cfg: Config) -> None:
    """Interactive loop for the Web Assessment submenu."""
    from ui.menus import show_web_menu, get_choice, divider

    while True:
        try:
            console.print()
            show_web_menu()
            choice = get_choice("web> ")

            if choice == "0":
                break

            elif choice == "1":
                # Content Discovery
                divider()
                try:
                    url = input("\033[92m[?] Target URL: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if not url:
                    log_warn("No URL entered.")
                    continue
                try:
                    exts = input("\033[92m[?] Extensions [php,html,js,txt]: \033[0m").strip() or "php,html,js,txt"
                except (KeyboardInterrupt, EOFError):
                    exts = "php,html,js,txt"
                # Scan mode selector → resolves quick/normal/custom wordlist
                wordlist = resolve_scan_wordlist(cfg)
                if not wordlist:
                    log_warn("No wordlist selected — content discovery cancelled.")
                    continue
                content_discovery(url, wordlist, cfg, extensions=exts)

            elif choice == "2":
                # Vulnerability Scan
                divider()
                try:
                    sev = input(f"\033[92m[?] Severity [{cfg.nuclei_severity}]: \033[0m").strip() or cfg.nuclei_severity
                except (KeyboardInterrupt, EOFError):
                    continue
                from utils.picker import pick_file
                console.print("\n[dim]Select targets file (one URL/host per line):[/dim]")
                console.print("  [1] Browse for file  (picker)\n  [2] Type path manually")
                try:
                    pm = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
                except (KeyboardInterrupt, EOFError):
                    continue
                if pm == "2":
                    try:
                        target_file = input("\033[92m[?] Targets file path: \033[0m").strip()
                    except (KeyboardInterrupt, EOFError):
                        continue
                else:
                    target_file = pick_file(
                        title="Select Nuclei Target File",
                        label="Targets file",
                        must_exist=True,
                        filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
                    )
                if target_file:
                    vuln_scan(target_file, cfg, severity=sev)
                else:
                    log_warn("No target file selected.")

            elif choice == "3":
                # Crawl Target
                divider()
                try:
                    url = input("\033[92m[?] Target URL: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if url:
                    crawl_target(url, cfg)

            elif choice == "4":
                # Feroxbuster
                divider()
                try:
                    url = input("\033[92m[?] Target URL: \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if not url:
                    log_warn("No URL entered.")
                    continue
                # Same scan mode selector — shares the same wordlist logic
                wordlist = resolve_scan_wordlist(cfg)
                if not wordlist:
                    log_warn("No wordlist selected — feroxbuster cancelled.")
                    continue
                feroxbuster_scan(url, wordlist, cfg)

            elif choice == "5":
                # Gobuster
                divider()
                from rich.panel import Panel as _GP
                from rich.table import Table as _GT
                from rich import box as _Gbox
                _gt = _GT(box=_Gbox.SIMPLE_HEAVY, border_style="bright_green",
                          show_header=False, expand=False)
                _gt.add_column("Key", style="bold cyan", width=5)
                _gt.add_column("Mode", style="bold white", width=14)
                _gt.add_column("Description", style="dim", width=48)
                _gt.add_row("[1]", "Normal Scan",
                    "Single mode — dir / dns / vhost / fuzz / s3",
                    style="on grey11")
                _gt.add_row("[2]", "Full Scan",
                    "5 scans chained: dir quick + deep, DNS subs, vhost, backup files")
                _gt.add_row("[0]", "Back", "")
                console.print(_GP(_gt,
                    title="[bold bright_green]// Gobuster[/bold bright_green]",
                    border_style="bright_green", expand=False))
                try:
                    gmode = input("\033[92m  gobuster> \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue

                if gmode == "0":
                    continue

                elif gmode == "1":
                    # Normal scan
                    try:
                        url = input("\033[92m[?] Target URL: \033[0m").strip()
                    except (KeyboardInterrupt, EOFError):
                        continue
                    if not url:
                        log_warn("No URL entered.")
                        continue
                    console.print(
                        "  Modes: [cyan]dir[/cyan] · [cyan]dns[/cyan] · "
                        "[cyan]vhost[/cyan] · [cyan]fuzz[/cyan] · [cyan]s3[/cyan]"
                    )
                    try:
                        scan_mode = input("\033[92m[?] Mode [dir]: \033[0m").strip().lower() or "dir"
                        if scan_mode not in ("dir","dns","vhost","fuzz","s3"):
                            log_warn(f"Unknown mode '{scan_mode}', using dir.")
                            scan_mode = "dir"
                        exts = "php,html,txt,js,asp,aspx,bak,zip,env"
                        if scan_mode == "dir":
                            exts = input("\033[92m[?] Extensions [php,html,txt,js,bak,zip]: \033[0m"
                                        ).strip() or exts
                    except (KeyboardInterrupt, EOFError):
                        scan_mode, exts = "dir", "php,html,txt,js"
                    wordlist = resolve_scan_wordlist(cfg)
                    if not wordlist:
                        log_warn("No wordlist selected — gobuster cancelled.")
                        continue
                    gobuster_scan(url, wordlist, cfg, mode=scan_mode, extensions=exts)

                elif gmode == "2":
                    # Full multi-scan
                    try:
                        url = input("\033[92m[?] Target URL: \033[0m").strip()
                    except (KeyboardInterrupt, EOFError):
                        continue
                    if not url:
                        log_warn("No URL entered.")
                        continue
                    gobuster_full_scan(url, cfg)

                else:
                    log_warn(f"Unknown choice: {gmode}")

            elif choice == "99":
                break

            else:
                log_warn(f"Unknown option: {choice}")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break


# ── Helpers ───────────────────────────────────────────────────────────────────

def _offer_seclists_download(cfg: Config) -> None:
    """Offer to download SecLists."""
    if confirm("Download SecLists (~400MB)?", default=False):
        wl_dir = Path(cfg.wordlist_path)
        wl_dir.mkdir(parents=True, exist_ok=True)
        from core.engine import run_with_progress as rwp
        rwp(
            ["git", "clone", "--depth", "1",
             "https://github.com/danielmiessler/SecLists.git",
             str(wl_dir / "SecLists")],
            description="Downloading SecLists..."
        )
