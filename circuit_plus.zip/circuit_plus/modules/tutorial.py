#!/usr/bin/env python3
"""
CIRCUIT+ — Interactive tutorial for new users.
"""
from __future__ import annotations

import shutil
import time
from pathlib import Path
from typing import Callable

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich import box

from utils.logger import console, log_ok, log_info, log_warn

# ══════════════════════════════════════════════════════════════════════════════
# LESSON DATA
# ══════════════════════════════════════════════════════════════════════════════

LESSONS: list[dict] = [
    {
        "id":    1,
        "title": "Welcome to CIRCUIT+",
        "icon":  "🛡️",
        "content": [
            ("overview", "What is CIRCUIT+?",
             "CIRCUIT+ is a Linux penetration testing framework that wraps "
             "industry-standard security tools (nmap, subfinder, nuclei, ffuf, "
             "gobuster…) into a unified terminal interface.\n\n"
             "It is designed for authorized security assessments only.\n"
             "Always obtain written permission before testing any target."),

            ("overview", "How it works",
             "CIRCUIT+ is organized into modules:\n\n"
             "  • [bold]Recon[/bold]     — find subdomains and live hosts\n"
             "  • [bold]Web[/bold]       — fuzz directories, scan for vulns\n"
             "  • [bold]Network[/bold]   — port scan and service detection\n"
             "  • [bold]Mass Scan[/bold] — run everything at once on a target\n"
             "  • [bold]Toolkit[/bold]   — basic diagnostics (ping, dig, whois…)\n\n"
             "Navigate by typing a number and pressing Enter."),

            ("overview", "Config & loot",
             "Your config lives at:\n"
             "  [cyan]~/.config/circuit_plus/config.json[/cyan]\n\n"
             "All scan output (findings, reports, screenshots) is saved to:\n"
             "  [cyan]./loot/{target}/{timestamp}/{module}/[/cyan]\n\n"
             "You can browse past results any time from [bold][13] Loot Browser[/bold]."),
        ],
    },
    {
        "id":    2,
        "title": "Installation & Setup",
        "icon":  "⚙️",
        "content": [
            ("install", "Python dependencies",
             "CIRCUIT+ needs Python 3.10+ and four packages:\n\n"
             "  [cyan]rich · pydantic · platformdirs · requests[/cyan]\n\n"
             "On first launch these are installed automatically. If you get a\n"
             "'externally-managed-environment' error, CIRCUIT+ will try apt/dnf/pacman\n"
             "first, then fall back to a virtual environment automatically."),

            ("install", "Security tools",
             "Go to [bold][17] Install Manager[/bold] to install tools.\n\n"
             "Key tools and their categories:\n\n"
             "  [bold]Recon:[/bold]    subfinder  dnsx  httpx  amass  alterx\n"
             "  [bold]Web:[/bold]      ffuf  nuclei  katana  gobuster  feroxbuster\n"
             "  [bold]Network:[/bold]  nmap  rustscan  masscan  naabu\n"
             "  [bold]Misc:[/bold]     curl  dig  whois  git  openssl\n\n"
             "In the installer: [cyan]a[/cyan] selects all missing, [cyan]i[/cyan] installs selected."),

            ("install", "Wordlists (required for fuzzing)",
             "Web fuzzing and DNS brute-force need wordlists.\n\n"
             "Recommended: [bold]SecLists[/bold] — the standard wordlist collection.\n"
             "  Install via: [bold][17] Install Manager[/bold] → Wordlists section\n"
             "  Or manually: [cyan]git clone --depth 1 https://github.com/danielmiessler/SecLists\n"
             "  ~/.local/share/wordlists/SecLists[/cyan]\n\n"
             "Key files CIRCUIT+ uses:\n"
             "  Quick scan → [dim]SecLists/Discovery/Web-Content/small.txt[/dim]\n"
             "  Full scan  → [dim]SecLists/Discovery/Web-Content/big.txt[/dim]"),

            ("install", "PATH setup for Go tools",
             "Go tools install to [cyan]~/go/bin/[/cyan] which may not be in your PATH.\n\n"
             "Add this to your [cyan]~/.bashrc[/cyan] or [cyan]~/.zshrc[/cyan]:\n\n"
             "  [cyan]export PATH=\"$PATH:$HOME/go/bin:$HOME/.cargo/bin\"[/cyan]\n\n"
             "Then reload: [cyan]source ~/.bashrc[/cyan]\n\n"
             "The Install Manager prints this reminder after each Go tool install."),
        ],
    },
    {
        "id":    3,
        "title": "Your First Scan",
        "icon":  "🔍",
        "content": [
            ("scan", "Choosing a target",
             "IMPORTANT: Only scan systems you own or have explicit written\n"
             "permission to test. Unauthorized scanning is illegal.\n\n"
             "For practice, use:\n"
             "  • Your own VPS or local VM\n"
             "  • HackTheBox / TryHackMe machines (they're designed for this)\n"
             "  • DVWA, VulnHub VMs on your local network\n"
             "  • Your own domain/server"),

            ("scan", "Option A — Mass Scan (recommended for beginners)",
             "The fastest way to see everything about a target:\n\n"
             "  1. From main menu, enter [bold]A → 5[/bold] (Scanning → Mass Scan)\n"
             "  2. Enter your target IP or domain\n"
             "  3. CIRCUIT+ runs 10 phases automatically:\n"
             "       DNS · Whois · GeoIP · HTTP · SSL · Tech · Ports\n"
             "       Subdomains · Traceroute · Service banners\n"
             "  4. After completion, choose to copy to clipboard or save\n\n"
             "Good for: initial target mapping, quick intel gathering."),

            ("scan", "Option B — Step by step",
             "For more control, run modules individually:\n\n"
             "  [bold]Step 1:[/bold] [cyan]A → 1 → 1[/cyan]  Subdomain enumeration\n"
             "           Gets all subdomains via subfinder + dnsx\n\n"
             "  [bold]Step 2:[/bold] [cyan]A → 1 → 3[/cyan]  Probe hosts\n"
             "           httpx checks which subdomains have web servers\n\n"
             "  [bold]Step 3:[/bold] [cyan]A → 2 → 1[/cyan]  Content discovery\n"
             "           ffuf fuzzes directories on live hosts\n\n"
             "  [bold]Step 4:[/bold] [cyan]A → 2 → 2[/cyan]  Vulnerability scan\n"
             "           nuclei checks for known CVEs and misconfigs"),

            ("scan", "Reading results",
             "All output is saved automatically.\n\n"
             "During a scan:\n"
             "  [green]✓[/green] = phase completed successfully\n"
             "  [yellow]△[/yellow] = warning (tool missing, no results)\n"
             "  [red]✗[/red] = error (check error message)\n\n"
             "After a scan:\n"
             "  [bold][13] Loot Browser[/bold] — browse all saved files\n"
             "  [bold][20] Export Report[/bold] — generate an HTML report\n\n"
             "Ctrl+C at any phase skips it and continues — never crashes."),
        ],
    },
    {
        "id":    4,
        "title": "Key Modules Explained",
        "icon":  "🧩",
        "content": [
            ("module", "Reconnaissance (A → 1)",
             "[bold]What it does:[/bold] Find every subdomain and live host.\n\n"
             "[bold]subfinder[/bold] — passive DNS enumeration (no noisy requests)\n"
             "[bold]dnsx[/bold]      — resolves found subdomains to real IPs\n"
             "[bold]httpx[/bold]     — checks which are web servers, grabs tech stack\n"
             "[bold]alterx[/bold]    — generates permutation subdomains (api2, dev2…)\n\n"
             "[bold]Workflow:[/bold] subfinder → dnsx → httpx → loot/recon/"),

            ("module", "Web Assessment (A → 2)",
             "[bold]Content Discovery (ffuf)[/bold]\n"
             "  Fuzzes URL paths using a wordlist.\n"
             "  Quick mode: small.txt (~950 words, seconds)\n"
             "  Normal mode: big.txt (~20k words, thorough)\n\n"
             "[bold]Vulnerability Scan (nuclei)[/bold]\n"
             "  Runs 9000+ templates against live hosts.\n"
             "  Finds: SQLi, XSS, RCE, misconfigs, exposed files…\n\n"
             "[bold]Gobuster[/bold]\n"
             "  Normal: single dir/dns/vhost scan\n"
             "  Full: 5 scans chained (dir+deep+DNS+vhost+backups)"),

            ("module", "Network (A → 3)",
             "[bold]Port Scan (RustScan → nmap)[/bold]\n"
             "  RustScan finds open ports in seconds (ulimit 5000)\n"
             "  Then nmap runs -sV -sC for service/version detection\n\n"
             "[bold]Masscan[/bold]\n"
             "  Scans entire CIDR ranges at 10,000+ packets/sec\n"
             "  Very loud — shows a warning + confirmation first\n\n"
             "[bold]Quick Port Check (Toolkit)[/bold]\n"
             "  Pure Python socket check — no tools needed\n"
             "  Checks top-25 ports instantly"),

            ("module", "Mods (A → 6)",
             "FSCF (CIRCUIT+ Flow) scripting language.\n"
             "Write automation scripts with 3 commands:\n\n"
             "  [cyan]ip = input(\"Enter IP: \")[/cyan]   — prompt, store value\n"
             "  [cyan]sys(nmap -sV {ip})[/cyan]          — run tool with {var}\n"
             "  [cyan]print(\"Scanning {ip}\")[/cyan]     — display message\n\n"
             "Drop .fscf files into Modifs/ — they appear in the Mods menu.\n"
             "5 example mods included: quick_recon, dns_full, web_fingerprint…"),

            ("module", "Total Recon (Special → T)",
             "The most comprehensive scan CIRCUIT+ can run.\n\n"
             "Chains 16 phases against a single domain:\n"
             "  Passive subdomain enum → DNS brute-force → permutations\n"
             "  → host probing → full port scan → web crawling\n"
             "  → content discovery → vuln scan → cloud enum\n"
             "  → tech fingerprint → CVE correlation → screenshots\n"
             "  → backup file hunting → SSL audit → GeoIP → report\n\n"
             "Takes 15-60 minutes depending on target size.\n"
             "Only run on targets you are authorized to test."),
        ],
    },
    {
        "id":    5,
        "title": "Tips & Best Practices",
        "icon":  "💡",
        "content": [
            ("tip", "Always set your scope first",
             "Before any scan, define your authorized targets in\n"
             "[bold][C] Utilities → [15] Scope Manager[/bold].\n\n"
             "This prevents accidental out-of-scope testing and\n"
             "gives you a clear record of what you're authorized to test.\n\n"
             "Scope supports: IPs, CIDR ranges, domains, *.wildcard.com"),

            ("tip", "Use sessions for long engagements",
             "[bold][C] Utilities → [14] Session Manager[/bold]\n\n"
             "Each scan session is saved with:\n"
             "  • Completed phases (so you can resume if interrupted)\n"
             "  • Key findings (ports, subdomains, tech, vulns)\n"
             "  • Notes and loot directory path\n\n"
             "Resume a session → re-runs from where you left off."),

            ("tip", "Nuclei — start with critical/high only",
             "Running nuclei with all severities floods you with info.\n\n"
             "Default config: [cyan]critical,high,medium[/cyan]\n"
             "For quick triage: change to [cyan]critical,high[/cyan] in\n"
             "[bold][D] Settings → [16] Configuration[/bold]\n\n"
             "Always update templates first:\n"
             "[cyan]nuclei -update-templates[/cyan]"),

            ("tip", "Threading and rate limits",
             "Default threads: 50 (suitable for local networks)\n"
             "For external targets: reduce to 10-20 to be polite\n"
             "and avoid triggering WAF/IDS blocks.\n\n"
             "Change in [bold][D] Settings → [16] Configuration[/bold]\n\n"
             "masscan rate: default 10,000 pps — very loud.\n"
             "Reduce for stealth: --rate 1000"),

            ("tip", "Keyboard shortcuts",
             "Works everywhere in CIRCUIT+:\n\n"
             "  [cyan]Ctrl+C[/cyan]  — Cancel current operation, return to menu\n"
             "             (never crashes — always handled gracefully)\n"
             "  [cyan]0[/cyan]       — Back to previous menu\n"
             "  [cyan]99[/cyan]      — Jump to main menu from any submenu\n\n"
             "In the Install Manager:\n"
             "  [cyan]a[/cyan]  — Select all missing tools\n"
             "  [cyan]r[/cyan]  — Select only required tools\n"
             "  [cyan]i[/cyan]  — Install selected"),
        ],
    },
]

# ══════════════════════════════════════════════════════════════════════════════
# RENDERER
# ══════════════════════════════════════════════════════════════════════════════

def _print_step(step_num: int, total: int, kind: str, title: str, body: str) -> None:
    """Render a single tutorial step."""
    kind_colors = {
        "overview": "bright_blue",
        "install":  "bright_cyan",
        "scan":     "bright_green",
        "module":   "bright_yellow",
        "tip":      "bright_magenta",
    }
    color = kind_colors.get(kind, "bright_green")

    console.print()
    console.print(Panel(
        f"[bold {color}]{title}[/bold {color}]\n\n{body}",
        border_style=color,
        expand=False,
        padding=(1, 3),
    ))
    console.print(
        f"  [dim]Step {step_num}/{total}   "
        "[cyan][Enter][/cyan] next   "
        "[cyan][b][/cyan] back   "
        "[cyan][q][/cyan] quit tutorial[/dim]"
    )


def _lesson_header(lesson: dict, lesson_num: int, total_lessons: int) -> None:
    console.print()
    console.print(Rule(
        f"[bold bright_green]{lesson['icon']}  Lesson {lesson_num}/{total_lessons}: "
        f"{lesson['title']}[/bold bright_green]",
        style="bright_green",
    ))


def run_tutorial(cfg=None) -> None:
    """
    Run the interactive tutorial — navigable with Enter/b/q.
    """
    console.print()
    console.print(Panel(
        "  [bold bright_green]Welcome to the CIRCUIT+ Tutorial[/bold bright_green]\n\n"
        "  This guide covers:\n"
        "    [bold]1.[/bold] What CIRCUIT+ is and how it works\n"
        "    [bold]2.[/bold] Installing tools and wordlists\n"
        "    [bold]3.[/bold] Running your first scan\n"
        "    [bold]4.[/bold] Key modules explained\n"
        "    [bold]5.[/bold] Tips and best practices\n\n"
        "  Navigation: [cyan][Enter][/cyan] next   "
        "[cyan][b][/cyan] back   "
        "[cyan][q][/cyan] quit\n\n"
        "  [dim]Estimated time: ~10 minutes[/dim]",
        title="[bold bright_green]// CIRCUIT+ Tutorial[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    try:
        input("\n\033[92m  Press Enter to begin...\033[0m")
    except (EOFError, KeyboardInterrupt):
        return

    # Flatten all steps with lesson context
    all_steps: list[tuple[dict, int, int, int, int, str, str, str]] = []
    # (lesson, lesson_num, total_lessons, step_in_lesson, total_in_lesson, kind, title, body)
    for l_idx, lesson in enumerate(LESSONS, 1):
        total_in_lesson = len(lesson["content"])
        for s_idx, (kind, title, body) in enumerate(lesson["content"], 1):
            all_steps.append(
                (lesson, l_idx, len(LESSONS), s_idx, total_in_lesson, kind, title, body)
            )

    pos = 0
    while 0 <= pos < len(all_steps):
        lesson, l_num, l_total, s_num, s_total, kind, title, body = all_steps[pos]

        # Print lesson header when entering a new lesson
        if s_num == 1:
            _lesson_header(lesson, l_num, l_total)

        _print_step(s_num, s_total, kind, title, body)

        # Check current environment where relevant
        _contextual_check(kind, title)

        try:
            raw = input("\n\033[92m  > \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break

        if raw in ("q", "quit", "exit"):
            break
        elif raw in ("b", "back") and pos > 0:
            pos -= 1
        else:
            pos += 1

    # Completion screen
    console.print()
    console.print(Panel(
        "  [bold bright_green]Tutorial complete![/bold bright_green]\n\n"
        "  You're ready to start. Suggested first steps:\n\n"
        "  [bold]1.[/bold] [cyan][D] Settings → [17] Install Manager[/cyan]\n"
        "          Install tools you need (start with: nmap, subfinder, httpx, nuclei)\n\n"
        "  [bold]2.[/bold] [cyan][D] Settings → [16] Configuration[/cyan]\n"
        "          Set your wordlist directory if you have SecLists\n\n"
        "  [bold]3.[/bold] [cyan][A] Scanning → Mass Scan[/cyan]\n"
        "          Run your first scan on an authorized target\n\n"
        "  [dim]Remember: Always get written authorization before testing.[/dim]",
        title="[bold bright_green]// All Done[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    try:
        input("\033[2m  Press Enter to return to menu...\033[0m")
    except (EOFError, KeyboardInterrupt):
        pass


def _contextual_check(kind: str, title: str) -> None:
    """Show live environment hints relevant to the current step."""
    if kind == "install" and "wordlist" in title.lower():
        wl = Path.home() / ".local" / "share" / "wordlists"
        if wl.exists() and any(wl.rglob("*.txt")):
            console.print(f"  [green]✓ Wordlists found at {wl}[/green]")
        else:
            console.print(f"  [yellow]△ No wordlists at {wl} — install via Install Manager[/yellow]")

    elif kind == "install" and "PATH" in title:
        go_bin = Path.home() / "go" / "bin"
        cargo_bin = Path.home() / ".cargo" / "bin"
        if go_bin.exists():
            in_path = str(go_bin) in __import__("os").environ.get("PATH","")
            status = "[green]✓ in PATH[/green]" if in_path else "[yellow]△ NOT in PATH[/yellow]"
            console.print(f"  ~/go/bin:       {status}")
        if cargo_bin.exists():
            in_path = str(cargo_bin) in __import__("os").environ.get("PATH","")
            status = "[green]✓ in PATH[/green]" if in_path else "[yellow]△ NOT in PATH[/yellow]"
            console.print(f"  ~/.cargo/bin:   {status}")

    elif kind == "install" and "Security tools" in title:
        tools = ["nmap","subfinder","httpx","nuclei","ffuf","gobuster","rustscan","naabu"]
        found = [t for t in tools if shutil.which(t)]
        missing = [t for t in tools if not shutil.which(t)]
        if found:
            console.print(f"  [green]✓ Installed ({len(found)}/{len(tools)}):[/green] "
                          + ", ".join(found))
        if missing:
            console.print(f"  [yellow]△ Missing ({len(missing)}/{len(tools)}):[/yellow] "
                          + ", ".join(missing))
