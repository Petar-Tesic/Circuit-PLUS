#!/usr/bin/env python3
"""
CIRCUIT+ — Scope Manager: define and enforce authorized target lists.
"""
from __future__ import annotations

import ipaddress
import re
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import is_valid_ip, is_valid_domain, is_valid_cidr, timestamp
from config import Config, get_ext, set_ext, CONFIG_DIR

# ── Scope file location ───────────────────────────────────────────────────────
DEFAULT_SCOPE_FILE = CONFIG_DIR / "scope.txt"


# ── Validation helpers ────────────────────────────────────────────────────────

def _is_wildcard_domain(s: str) -> bool:
    return s.startswith("*.") and is_valid_domain(s[2:])


def _normalise_entry(raw: str) -> Optional[str]:
    """Return normalised scope entry or None if invalid."""
    s = raw.strip().lower()
    if not s or s.startswith("#"):
        return None
    if (is_valid_ip(s) or is_valid_cidr(s)
            or is_valid_domain(s) or _is_wildcard_domain(s)):
        return s
    # Try URL → extract host
    for prefix in ("https://", "http://"):
        if s.startswith(prefix):
            host = s[len(prefix):].split("/")[0].split(":")[0]
            if is_valid_domain(host) or is_valid_ip(host):
                return host
    return None


def _in_cidr(ip: str, cidr: str) -> bool:
    try:
        return ipaddress.ip_address(ip) in ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return False


# ── Core scope operations ─────────────────────────────────────────────────────

def load_scope(path: Optional[Path] = None) -> list[str]:
    """
    Load scope entries from a file.
    Lines starting with # are comments and are ignored.

    Args:
        path: Path to scope file. Defaults to ~/.config/circuit_plus/scope.txt.

    Returns:
        List of normalised scope entries (IPs, CIDRs, domains).
    """
    scope_file = path or Path(get_ext("scope_file", str(DEFAULT_SCOPE_FILE)))
    if not scope_file.exists():
        return []
    entries: list[str] = []
    for line in scope_file.read_text(encoding="utf-8").splitlines():
        entry = _normalise_entry(line)
        if entry:
            entries.append(entry)
    return entries


def save_scope(entries: list[str], path: Optional[Path] = None) -> None:
    """Write scope entries to file (one per line, sorted)."""
    scope_file = path or Path(get_ext("scope_file", str(DEFAULT_SCOPE_FILE)))
    scope_file.parent.mkdir(parents=True, exist_ok=True)
    scope_file.write_text(
        "# CIRCUIT+ Scope File — one entry per line\n"
        "# Supported: IP, CIDR, domain, *.wildcard.domain\n"
        "# Lines starting with # are comments\n\n"
        + "\n".join(sorted(set(entries))) + "\n",
        encoding="utf-8",
    )


def is_in_scope(target: str, scope: list[str]) -> bool:
    """
    Check if a target is within the defined scope.
    If scope is empty, all targets are considered in-scope.

    Args:
        target: IP address, domain, or URL.
        scope:  List of scope entries from load_scope().

    Returns:
        True if in-scope or scope is empty.
    """
    if not scope:
        return True  # No scope restriction

    # Normalise the target
    host = target.strip().lower()
    for prefix in ("https://", "http://"):
        if host.startswith(prefix):
            host = host[len(prefix):].split("/")[0].split(":")[0]

    for entry in scope:
        # Exact match
        if host == entry:
            return True
        # CIDR
        if "/" in entry and is_valid_ip(host):
            if _in_cidr(host, entry):
                return True
        # Wildcard domain (*.example.com matches sub.example.com)
        if entry.startswith("*."):
            suffix = entry[2:]
            if host.endswith("." + suffix) or host == suffix:
                return True

    return False


def assert_in_scope(target: str, scope: list[str]) -> bool:
    """
    Check scope and print an error if out-of-scope.

    Returns:
        True if in-scope, False if out-of-scope (after printing warning).
    """
    if is_in_scope(target, scope):
        return True
    console.print(Panel(
        f"[bold red]⛔ OUT OF SCOPE[/bold red]\n\n"
        f"  Target: [cyan]{target}[/cyan]\n\n"
        f"  This target is not in your scope file.\n"
        f"  To add it: [cyan][5] Configuration → Scope Manager[/cyan]",
        border_style="red", expand=False,
    ))
    return False


# ── Interactive scope menu ────────────────────────────────────────────────────

def run_scope_menu() -> None:
    """Interactive scope file editor."""
    scope_file = Path(get_ext("scope_file", str(DEFAULT_SCOPE_FILE)))

    while True:
        entries = load_scope(scope_file)
        console.print()

        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",      width=5,  justify="right", style="dim")
        tbl.add_column("Entry",  width=40, style="cyan")
        tbl.add_column("Type",   width=12, style="dim")

        for i, entry in enumerate(entries, 1):
            if "/" in entry:     kind = "CIDR"
            elif entry.startswith("*."):  kind = "Wildcard"
            elif is_valid_ip(entry):      kind = "IP"
            else:                         kind = "Domain"
            tbl.add_row(str(i), entry, kind, style="on grey11" if i % 2 == 0 else "")

        if not entries:
            tbl.add_row("", "[dim]Scope is empty — all targets allowed[/dim]", "", style="on grey11")

        console.print(Panel(
            tbl,
            title=f"[bold bright_green]// Scope Manager[/bold bright_green]  [dim]{scope_file}[/dim]",
            border_style="bright_green", expand=False,
        ))
        console.print(
            "  [cyan][a] <target>[/cyan] Add entry     "
            "[cyan][d] <#>[/cyan] Delete     "
            "[cyan][l] <file>[/cyan] Load from file\n"
            "  [cyan][c][/cyan] Clear all            "
            "[cyan][f] <path>[/cyan] Change scope file     "
            "[cyan][0][/cyan] Back"
        )

        try:
            cmd = input("\033[92m  scope> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0", "back"):
            break

        parts = cmd.split(None, 1)
        verb  = parts[0].lower()
        arg   = parts[1].strip() if len(parts) > 1 else ""

        if verb == "a" and arg:
            entry = _normalise_entry(arg)
            if entry:
                entries.append(entry)
                save_scope(entries, scope_file)
                log_ok(f"Added: {entry}")
            else:
                log_err(f"Invalid scope entry: {arg}")

        elif verb == "d" and arg.isdigit():
            idx = int(arg) - 1
            if 0 <= idx < len(entries):
                removed = entries.pop(idx)
                save_scope(entries, scope_file)
                log_ok(f"Removed: {removed}")

        elif verb == "l" and arg:
            src = Path(arg)
            if src.exists():
                new_entries = load_scope(src)
                entries = list(set(entries + new_entries))
                save_scope(entries, scope_file)
                log_ok(f"Loaded {len(new_entries)} entries from {src}")
            else:
                log_err(f"File not found: {src}")

        elif verb == "c":
            try:
                confirm = input("\033[92m[?] Clear all scope entries? [y/N]: \033[0m").strip().lower()
            except (EOFError, KeyboardInterrupt):
                confirm = "n"
            if confirm in ("y", "yes"):
                save_scope([], scope_file)
                log_ok("Scope cleared.")

        elif verb == "f" and arg:
            new_path = Path(arg)
            set_ext("scope_file", str(new_path))
            scope_file = new_path
            log_ok(f"Scope file changed to: {new_path}")

        else:
            log_warn(f"Unknown command: {cmd}")
