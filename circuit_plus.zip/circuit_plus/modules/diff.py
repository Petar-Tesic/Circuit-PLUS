#!/usr/bin/env python3
"""
CIRCUIT+ — Scan Diff: compare two reports and show what changed.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import timestamp, make_loot_dir
from config import Config, append_history


# ── Diff helpers ──────────────────────────────────────────────────────────────

def _set_diff(old: list, new: list) -> tuple[list, list]:
    """Return (added, removed) between old and new lists."""
    old_set = set(str(x) for x in old)
    new_set = set(str(x) for x in new)
    return sorted(new_set - old_set), sorted(old_set - new_set)


def _extract_phase(report: dict, phase_name: str) -> dict:
    """Extract data dict from a named phase in a report."""
    for phase in report.get("phases", []):
        if phase.get("name","").lower() == phase_name.lower():
            return phase.get("data", {})
    return {}


# ── Core diff engine ──────────────────────────────────────────────────────────

def diff_reports(report_a: dict, report_b: dict) -> dict:
    """
    Compare two mass scan reports and return a structured diff.

    Args:
        report_a: Older report dict.
        report_b: Newer report dict.

    Returns:
        Dict of changes organised by category.
    """
    diff: dict[str, Any] = {
        "target":    report_b.get("target", "unknown"),
        "scan_a":    report_a.get("started", "?"),
        "scan_b":    report_b.get("started", "?"),
        "changes":   {},
        "summary":   [],
    }

    # ── Open ports ────────────────────────────────────────────────────────────
    ports_a = _extract_phase(report_a, "Port Check (top-25)").get("open", [])
    ports_b = _extract_phase(report_b, "Port Check (top-25)").get("open", [])
    added_ports, removed_ports = _set_diff(ports_a, ports_b)
    if added_ports or removed_ports:
        diff["changes"]["ports"] = {
            "added":   added_ports,
            "removed": removed_ports,
        }
        if added_ports:
            diff["summary"].append(f"[red]NEW PORTS:[/red] {', '.join(added_ports)}")
        if removed_ports:
            diff["summary"].append(f"[green]CLOSED PORTS:[/green] {', '.join(removed_ports)}")

    # ── Subdomains ────────────────────────────────────────────────────────────
    subs_a = _extract_phase(report_a, "Subdomain Enumeration").get("subdomains", [])
    subs_b = _extract_phase(report_b, "Subdomain Enumeration").get("subdomains", [])
    added_subs, removed_subs = _set_diff(subs_a, subs_b)
    if added_subs or removed_subs:
        diff["changes"]["subdomains"] = {
            "added":   added_subs[:50],
            "removed": removed_subs[:50],
        }
        if added_subs:
            diff["summary"].append(f"[red]NEW SUBDOMAINS ({len(added_subs)}):[/red] "
                                   + ", ".join(added_subs[:5])
                                   + ("…" if len(added_subs) > 5 else ""))

    # ── Technology ────────────────────────────────────────────────────────────
    def _flatten_tech(data: dict) -> list[str]:
        result: list[str] = []
        for k, v in data.items():
            if k.startswith("_") or k == "Vuln Hints":
                continue
            if isinstance(v, list):
                result.extend(str(x) for x in v)
            elif v:
                result.append(str(v))
        return result

    tech_a = _flatten_tech(_extract_phase(report_a, "Tech Fingerprint"))
    tech_b = _flatten_tech(_extract_phase(report_b, "Tech Fingerprint"))
    added_tech, removed_tech = _set_diff(tech_a, tech_b)
    if added_tech or removed_tech:
        diff["changes"]["tech"] = {
            "added":   added_tech,
            "removed": removed_tech,
        }
        if added_tech:
            diff["summary"].append(f"[yellow]NEW TECH:[/yellow] {', '.join(added_tech)}")
        if removed_tech:
            diff["summary"].append(f"[green]REMOVED TECH:[/green] {', '.join(removed_tech)}")

    # ── SSL Certificate expiry ────────────────────────────────────────────────
    ssl_a = _extract_phase(report_a, "SSL/TLS Certificate")
    ssl_b = _extract_phase(report_b, "SSL/TLS Certificate")
    days_a = ssl_a.get("Days Until Expiry", None)
    days_b = ssl_b.get("Days Until Expiry", None)
    if days_a is not None and days_b is not None:
        if abs(int(str(days_b)) - int(str(days_a))) > 1:
            diff["changes"]["ssl_expiry"] = {
                "before": days_a,
                "after":  days_b,
            }
            if int(str(days_b)) < 14:
                diff["summary"].append(f"[bold red]SSL EXPIRING IN {days_b} DAYS![/bold red]")
            elif int(str(days_b)) < int(str(days_a)):
                diff["summary"].append(f"[yellow]SSL: {days_b} days left (was {days_a})[/yellow]")

    # ── HTTP security headers ─────────────────────────────────────────────────
    http_a = _extract_phase(report_a, "HTTP Headers")
    http_b = _extract_phase(report_b, "HTTP Headers")
    missing_a = set(http_a.get("Security Missing", []))
    missing_b = set(http_b.get("Security Missing", []))
    new_missing    = sorted(missing_b - missing_a)  # now missing, wasn't before
    now_present    = sorted(missing_a - missing_b)  # was missing, now fixed
    if new_missing:
        diff["changes"]["security_headers_lost"] = new_missing
        diff["summary"].append(f"[red]SECURITY HEADERS REMOVED:[/red] {', '.join(new_missing)}")
    if now_present:
        diff["changes"]["security_headers_added"] = now_present
        diff["summary"].append(f"[green]SECURITY HEADERS ADDED:[/green] {', '.join(now_present)}")

    # ── Server / tech stack fingerprint change ────────────────────────────────
    server_a = http_a.get("Server", "")
    server_b = http_b.get("Server", "")
    if server_a and server_b and server_a != server_b:
        diff["changes"]["server_changed"] = {"from": server_a, "to": server_b}
        diff["summary"].append(f"[yellow]SERVER CHANGED:[/yellow] {server_a} → {server_b}")

    return diff


def print_diff(diff: dict) -> None:
    """Display a diff report as Rich tables."""
    console.print()
    console.print(Panel(
        f"  [bold white]Target[/bold white]  : [cyan]{diff['target']}[/cyan]\n"
        f"  [bold white]Scan A[/bold white]  : [dim]{diff['scan_a']}[/dim]\n"
        f"  [bold white]Scan B[/bold white]  : [dim]{diff['scan_b']}[/dim]",
        title="[bold bright_green]// Scan Diff[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    if not diff["changes"]:
        log_ok("No changes detected between the two scans.")
        return

    # Summary
    console.print("\n[bold bright_green]── Summary ──────────────────────────────────────[/bold bright_green]")
    for line in diff["summary"]:
        console.print(f"  {line}")

    # Detailed tables
    changes = diff["changes"]

    if "ports" in changes:
        _print_diff_section(
            "Port Changes",
            changes["ports"].get("added", []),
            changes["ports"].get("removed", []),
            "Port",
        )

    if "subdomains" in changes:
        _print_diff_section(
            "Subdomain Changes",
            changes["subdomains"].get("added", []),
            changes["subdomains"].get("removed", []),
            "Subdomain",
        )

    if "tech" in changes:
        _print_diff_section(
            "Technology Changes",
            changes["tech"].get("added", []),
            changes["tech"].get("removed", []),
            "Technology",
        )


def _print_diff_section(title: str, added: list, removed: list, col_label: str) -> None:
    """Print a diff section with added/removed columns."""
    if not added and not removed:
        return

    tbl = Table(
        title=f"[bold bright_green]// {title}[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    tbl.add_column(f"➕ Added",   style="green",  width=35)
    tbl.add_column(f"➖ Removed", style="red",    width=35)

    max_len = max(len(added), len(removed))
    for i in range(min(max_len, 30)):
        a = added[i]   if i < len(added)   else ""
        r = removed[i] if i < len(removed) else ""
        tbl.add_row(a[:34], r[:34], style="on grey11" if i % 2 == 0 else "")

    if max_len > 30:
        tbl.add_row(f"[dim]+{max_len-30} more[/dim]", "", style="dim")
    console.print(tbl)


# ── Interactive menu ──────────────────────────────────────────────────────────

def run_diff_menu(cfg: Config) -> None:
    """Interactive diff tool entry point."""
    from utils.picker import pick_file
    console.print()
    console.print(Panel(
        "  Compare two mass scan [bold]report.json[/bold] files.\n"
        "  Shows new/removed ports, subdomains, tech, SSL changes,\n"
        "  and security header regressions.\n\n"
        "  Select the OLDER scan first, then the NEWER scan.",
        title="[bold bright_green]// Scan Diff[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    console.print("\n[dim]Step 1: Select the OLDER scan report[/dim]")
    path_a = pick_file(
        title="Select OLDER report.json",
        label="Older report (scan A)",
        must_exist=True,
        filetypes=[("JSON files","*.json"),("All files","*.*")],
    )
    if not path_a:
        return

    console.print("\n[dim]Step 2: Select the NEWER scan report[/dim]")
    path_b = pick_file(
        title="Select NEWER report.json",
        label="Newer report (scan B)",
        must_exist=True,
        filetypes=[("JSON files","*.json"),("All files","*.*")],
    )
    if not path_b:
        return

    try:
        report_a = json.loads(Path(path_a).read_text(encoding="utf-8"))
        report_b = json.loads(Path(path_b).read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        log_err(f"Failed to load reports: {e}")
        return

    diff = diff_reports(report_a, report_b)
    print_diff(diff)

    # Save diff
    loot = make_loot_dir(cfg.loot_path, diff["target"].replace(".","_"), "diff")
    out  = loot / f"diff_{timestamp()}.json"
    out.write_text(json.dumps(diff, indent=2), encoding="utf-8")
    log_ok(f"Diff saved: {out}")
    append_history({
        "ts": timestamp(), "action": "scan_diff",
        "target": diff["target"],
        "changes": len(diff["changes"]),
    })
