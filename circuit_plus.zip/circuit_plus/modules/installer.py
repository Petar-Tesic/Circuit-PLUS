#!/usr/bin/env python3
"""
CIRCUIT+ — Interactive Installer
Detects OS/distro, shows a live status table for every installable tool,
and lets the operator install individual items or everything at once.

Categories handled:
  • Python packages  (pip / system pkg / venv fallback)
  • System tools     (apt / dnf / pacman / zypper)
  • Go tools         (go install …@latest)
  • Rust tools       (cargo install …)
  • Wordlists        (git clone SecLists / git clone PayloadsAllTheThings / etc.)
  • Nuclei templates (nuclei -update-templates)
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text
from rich import box

console = Console(highlight=False)


# ══════════════════════════════════════════════════════════════════════════════
# DATA MODEL
# ══════════════════════════════════════════════════════════════════════════════

class InstallMethod(str, Enum):
    APT      = "apt"
    DNF      = "dnf"
    PACMAN   = "pacman"
    ZYPPER   = "zypper"
    GO       = "go"
    CARGO    = "cargo"
    PIP      = "pip"
    GIT      = "git"
    SCRIPT   = "script"   # arbitrary shell snippet
    MANUAL   = "manual"   # show instructions only


@dataclass
class ToolEntry:
    """One installable item in the registry."""
    name:        str
    category:    str
    description: str
    binary:      str                        # executable to check in PATH (or "" for Python pkg)
    required:    bool = False

    # Install commands, keyed by InstallMethod or distro name
    # Values are the *arguments* passed after the package manager command.
    apt_pkg:     str  = ""                  # e.g. "nmap"
    dnf_pkg:     str  = ""
    pacman_pkg:  str  = ""
    zypper_pkg:  str  = ""
    go_pkg:      str  = ""                  # full go import path@version
    cargo_pkg:   str  = ""                  # crate name
    pip_pkg:     str  = ""                  # PyPI name
    git_url:     str  = ""                  # clone URL (for wordlists)
    git_dest:    str  = ""                  # destination path (may use ~ or $HOME)
    script:      str  = ""                  # arbitrary shell command
    manual_hint: str  = ""                  # shown when nothing else works

    # runtime state (filled during a session)
    installed:   Optional[bool] = field(default=None, repr=False)
    version:     Optional[str]  = field(default=None, repr=False)


# ══════════════════════════════════════════════════════════════════════════════
# COMPLETE TOOL REGISTRY
# ══════════════════════════════════════════════════════════════════════════════

def _build_registry() -> List[ToolEntry]:
    """Return the complete list of installable items."""
    return [

        # ── Python Packages ────────────────────────────────────────────────
        ToolEntry("rich",          "Python", "Rich terminal UI library",
                  binary="",      required=True,
                  pip_pkg="rich", apt_pkg="python3-rich", dnf_pkg="python3-rich",
                  pacman_pkg="python-rich", zypper_pkg="python3-rich"),

        ToolEntry("pydantic",      "Python", "Data validation library",
                  binary="",      required=True,
                  pip_pkg="pydantic", apt_pkg="python3-pydantic", dnf_pkg="python3-pydantic",
                  pacman_pkg="python-pydantic", zypper_pkg="python3-pydantic"),

        ToolEntry("platformdirs",  "Python", "XDG / platform directory helper",
                  binary="",      required=True,
                  pip_pkg="platformdirs", apt_pkg="python3-platformdirs",
                  dnf_pkg="python3-platformdirs", pacman_pkg="python-platformdirs",
                  zypper_pkg="python3-platformdirs"),

        ToolEntry("requests",      "Python", "HTTP library",
                  binary="",      required=True,
                  pip_pkg="requests", apt_pkg="python3-requests", dnf_pkg="python3-requests",
                  pacman_pkg="python-requests", zypper_pkg="python3-requests"),

        # ── System / Core Tools ────────────────────────────────────────────
        ToolEntry("nmap",      "System", "Port scanner & service detection",
                  binary="nmap",    required=True,
                  apt_pkg="nmap",   dnf_pkg="nmap",   pacman_pkg="nmap",   zypper_pkg="nmap"),

        ToolEntry("curl",      "System", "HTTP/URL transfer tool",
                  binary="curl",    required=True,
                  apt_pkg="curl",   dnf_pkg="curl",   pacman_pkg="curl",   zypper_pkg="curl"),

        ToolEntry("wget",      "System", "File download utility",
                  binary="wget",    required=False,
                  apt_pkg="wget",   dnf_pkg="wget",   pacman_pkg="wget",   zypper_pkg="wget"),

        ToolEntry("git",       "System", "Version control (needed for wordlists)",
                  binary="git",     required=True,
                  apt_pkg="git",    dnf_pkg="git",    pacman_pkg="git",    zypper_pkg="git"),

        ToolEntry("jq",        "System", "JSON processor",
                  binary="jq",      required=False,
                  apt_pkg="jq",     dnf_pkg="jq",     pacman_pkg="jq",     zypper_pkg="jq"),

        ToolEntry("whois",     "System", "WHOIS domain lookup",
                  binary="whois",   required=False,
                  apt_pkg="whois",  dnf_pkg="whois",  pacman_pkg="whois",  zypper_pkg="whois"),

        ToolEntry("dnsutils",  "System", "dig, nslookup DNS tools",
                  binary="dig",     required=False,
                  apt_pkg="dnsutils", dnf_pkg="bind-utils", pacman_pkg="bind",
                  zypper_pkg="bind-utils"),

        ToolEntry("netcat",    "System", "TCP/UDP networking utility",
                  binary="nc",      required=False,
                  apt_pkg="netcat-openbsd", dnf_pkg="ncat", pacman_pkg="openbsd-netcat",
                  zypper_pkg="netcat-openbsd"),

        ToolEntry("masscan",   "System", "Mass IP port scanner",
                  binary="masscan", required=False,
                  apt_pkg="masscan", dnf_pkg="masscan", pacman_pkg="masscan",
                  zypper_pkg="masscan"),

        ToolEntry("massdns",   "System", "Fast DNS resolver/bruteforcer",
                  binary="massdns", required=False,
                  apt_pkg="massdns", dnf_pkg="",       pacman_pkg="massdns",
                  zypper_pkg="",
                  manual_hint="Build from source: git clone https://github.com/blechschmidt/massdns && cd massdns && make"),

        ToolEntry("nikto",     "System", "Web server vulnerability scanner",
                  binary="nikto",   required=False,
                  apt_pkg="nikto",  dnf_pkg="nikto",  pacman_pkg="nikto",  zypper_pkg="nikto"),

        ToolEntry("sqlmap",    "System", "Automatic SQL injection tool",
                  binary="sqlmap",  required=False,
                  apt_pkg="sqlmap", dnf_pkg="sqlmap", pacman_pkg="sqlmap", zypper_pkg="sqlmap"),

        ToolEntry("hydra",     "System", "Login brute-forcer",
                  binary="hydra",   required=False,
                  apt_pkg="hydra",  dnf_pkg="hydra",  pacman_pkg="hydra",  zypper_pkg="hydra"),

        ToolEntry("medusa",    "System", "Parallel login brute-forcer",
                  binary="medusa",  required=False,
                  apt_pkg="medusa", dnf_pkg="medusa", pacman_pkg="medusa", zypper_pkg="medusa"),

        ToolEntry("gobuster",  "System", "Directory/DNS/vhost brute-forcer",
                  binary="gobuster", required=False,
                  apt_pkg="gobuster", dnf_pkg="gobuster", pacman_pkg="gobuster",
                  zypper_pkg="gobuster",
                  go_pkg="github.com/OJ/gobuster/v3@latest"),

        ToolEntry("dirb",      "System", "Web content scanner",
                  binary="dirb",    required=False,
                  apt_pkg="dirb",   dnf_pkg="dirb",   pacman_pkg="dirb",   zypper_pkg="dirb"),

        ToolEntry("wfuzz",     "System", "Web application fuzzer",
                  binary="wfuzz",   required=False,
                  apt_pkg="wfuzz",  dnf_pkg="wfuzz",  pacman_pkg="wfuzz",  zypper_pkg="wfuzz"),

        ToolEntry("sslscan",   "System", "SSL/TLS scanner",
                  binary="sslscan", required=False,
                  apt_pkg="sslscan", dnf_pkg="sslscan", pacman_pkg="sslscan",
                  zypper_pkg="sslscan"),

        ToolEntry("enum4linux", "System", "SMB/Windows enumeration",
                  binary="enum4linux", required=False,
                  apt_pkg="enum4linux", dnf_pkg="", pacman_pkg="enum4linux",
                  zypper_pkg=""),

        ToolEntry("nbtscan",   "System", "NetBIOS scanner",
                  binary="nbtscan", required=False,
                  apt_pkg="nbtscan", dnf_pkg="nbtscan", pacman_pkg="nbtscan",
                  zypper_pkg="nbtscan"),

        ToolEntry("theharvester", "System", "Email/subdomain OSINT harvester",
                  binary="theharvester", required=False,
                  apt_pkg="theharvester", dnf_pkg="", pacman_pkg="",
                  zypper_pkg="",
                  pip_pkg="theHarvester"),

        ToolEntry("whatweb",   "System", "Web fingerprinting",
                  binary="whatweb", required=False,
                  apt_pkg="whatweb", dnf_pkg="", pacman_pkg="whatweb",
                  zypper_pkg=""),

        ToolEntry("exiftool",  "System", "File metadata extraction",
                  binary="exiftool", required=False,
                  apt_pkg="libimage-exiftool-perl", dnf_pkg="perl-Image-ExifTool",
                  pacman_pkg="perl-image-exiftool", zypper_pkg="perl-Image-ExifTool"),

        ToolEntry("binwalk",   "System", "Firmware analysis",
                  binary="binwalk",  required=False,
                  apt_pkg="binwalk", dnf_pkg="", pacman_pkg="binwalk",
                  zypper_pkg=""),

        ToolEntry("john",      "System", "John the Ripper (password cracker)",
                  binary="john",     required=False,
                  apt_pkg="john",    dnf_pkg="john",    pacman_pkg="john",    zypper_pkg="john"),

        ToolEntry("hashcat",   "System", "GPU-accelerated hash cracker",
                  binary="hashcat",  required=False,
                  apt_pkg="hashcat", dnf_pkg="hashcat", pacman_pkg="hashcat", zypper_pkg="hashcat"),

        ToolEntry("tcpdump",   "System", "Packet capture",
                  binary="tcpdump",  required=False,
                  apt_pkg="tcpdump", dnf_pkg="tcpdump", pacman_pkg="tcpdump", zypper_pkg="tcpdump"),

        ToolEntry("tshark",    "System", "Wireshark CLI packet analyser",
                  binary="tshark",   required=False,
                  apt_pkg="tshark",  dnf_pkg="wireshark-cli", pacman_pkg="wireshark-cli",
                  zypper_pkg="wireshark"),

        ToolEntry("socat",     "System", "Multipurpose relay tool",
                  binary="socat",    required=False,
                  apt_pkg="socat",   dnf_pkg="socat",   pacman_pkg="socat",   zypper_pkg="socat"),

        ToolEntry("proxychains4", "System", "Proxy chaining tool",
                  binary="proxychains4", required=False,
                  apt_pkg="proxychains4", dnf_pkg="proxychains-ng", pacman_pkg="proxychains-ng",
                  zypper_pkg="proxychains-ng"),

        ToolEntry("tor",       "System", "Tor anonymity network",
                  binary="tor",      required=False,
                  apt_pkg="tor",     dnf_pkg="tor",     pacman_pkg="tor",     zypper_pkg="tor"),

        # ── Go Tools (ProjectDiscovery & others) ───────────────────────────
        ToolEntry("subfinder",   "Go / Recon", "Fast passive subdomain enumeration",
                  binary="subfinder", required=False,
                  go_pkg="github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"),

        ToolEntry("httpx",       "Go / Recon", "HTTP prober with tech detection",
                  binary="httpx",    required=False,
                  go_pkg="github.com/projectdiscovery/httpx/cmd/httpx@latest"),

        ToolEntry("dnsx",        "Go / Recon", "DNS toolkit & resolver",
                  binary="dnsx",     required=False,
                  go_pkg="github.com/projectdiscovery/dnsx/cmd/dnsx@latest"),

        ToolEntry("alterx",      "Go / Recon", "Subdomain permutation engine",
                  binary="alterx",   required=False,
                  go_pkg="github.com/projectdiscovery/alterx/cmd/alterx@latest"),

        ToolEntry("amass",       "Go / Recon", "In-depth attack surface mapping (OWASP)",
                  binary="amass",    required=False,
                  go_pkg="github.com/owasp-amass/amass/v4/cmd/amass@latest"),

        ToolEntry("shuffledns",  "Go / Recon", "MassDNS wrapper for subdomain brute-forcing",
                  binary="shuffledns", required=False,
                  go_pkg="github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"),

        ToolEntry("mapcidr",     "Go / Recon", "CIDR / IP range utility",
                  binary="mapcidr",  required=False,
                  go_pkg="github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest"),

        ToolEntry("cdncheck",    "Go / Recon", "CDN/WAF/cloud range detection",
                  binary="cdncheck", required=False,
                  go_pkg="github.com/projectdiscovery/cdncheck/cmd/cdncheck@latest"),

        ToolEntry("uncover",     "Go / Recon", "Attack surface discovery via shodan/fofa/censys",
                  binary="uncover",  required=False,
                  go_pkg="github.com/projectdiscovery/uncover/cmd/uncover@latest"),

        ToolEntry("nuclei",      "Go / Web",   "Fast template-based vulnerability scanner",
                  binary="nuclei",   required=False,
                  go_pkg="github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"),

        ToolEntry("katana",      "Go / Web",   "Fast JS-aware web crawler",
                  binary="katana",   required=False,
                  go_pkg="github.com/projectdiscovery/katana/cmd/katana@latest"),

        ToolEntry("ffuf",        "Go / Web",   "Fast web fuzzer",
                  binary="ffuf",     required=False,
                  go_pkg="github.com/ffuf/ffuf/v2@latest"),

        ToolEntry("gau",         "Go / Web",   "Get All URLs (Wayback / AlienVault / URLScan)",
                  binary="gau",      required=False,
                  go_pkg="github.com/lc/gau/v2/cmd/gau@latest"),

        ToolEntry("gospider",    "Go / Web",   "Fast web spider",
                  binary="gospider", required=False,
                  go_pkg="github.com/jaeles-project/gospider@latest"),

        ToolEntry("hakrawler",   "Go / Web",   "Simple web crawler",
                  binary="hakrawler", required=False,
                  go_pkg="github.com/hakluke/hakrawler@latest"),

        ToolEntry("waybackurls", "Go / Web",   "Fetch URLs from the Wayback Machine",
                  binary="waybackurls", required=False,
                  go_pkg="github.com/tomnomnom/waybackurls@latest"),

        ToolEntry("gf",          "Go / Web",   "Grep patterns for URLs (tomnomnom)",
                  binary="gf",       required=False,
                  go_pkg="github.com/tomnomnom/gf@latest"),

        ToolEntry("anew",        "Go / Utils", "Append new unique lines to a file",
                  binary="anew",     required=False,
                  go_pkg="github.com/tomnomnom/anew@latest"),

        ToolEntry("qsreplace",   "Go / Utils", "Replace query-string values in URLs",
                  binary="qsreplace", required=False,
                  go_pkg="github.com/tomnomnom/qsreplace@latest"),

        ToolEntry("naabu",       "Go / Net",   "Fast port scanner (ProjectDiscovery)",
                  binary="naabu",    required=False,
                  go_pkg="github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"),

        ToolEntry("proxify",     "Go / Net",   "HTTP/S proxy for traffic interception",
                  binary="proxify",  required=False,
                  go_pkg="github.com/projectdiscovery/proxify/cmd/proxify@latest"),

        ToolEntry("interactsh-client", "Go / OOB", "Out-of-band interaction server client",
                  binary="interactsh-client", required=False,
                  go_pkg="github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest"),

        ToolEntry("dalfox",      "Go / Web",   "Parameter analysis / XSS scanner",
                  binary="dalfox",   required=False,
                  go_pkg="github.com/hahwul/dalfox/v2@latest"),

        ToolEntry("gowitness",   "Go / Web",   "Web screenshot utility",
                  binary="gowitness", required=False,
                  go_pkg="github.com/sensepost/gowitness/v3@latest"),

        ToolEntry("aquatone",    "Go / Web",   "Visual inspection of domains",
                  binary="aquatone", required=False,
                  manual_hint="Download binary: https://github.com/michenriksen/aquatone/releases"),

        # ── Rust Tools ────────────────────────────────────────────────────
        ToolEntry("rustscan",    "Rust / Net", "Fast port scanner (Rust)",
                  binary="rustscan",   required=False,
                  cargo_pkg="rustscan"),

        ToolEntry("feroxbuster", "Rust / Web", "Recursive content discovery (Rust)",
                  binary="feroxbuster", required=False,
                  cargo_pkg="feroxbuster"),

        # ── Wordlists (git clone) ──────────────────────────────────────────
        ToolEntry("SecLists",    "Wordlists", "Daniel Miessler's SecLists (~450 MB)",
                  binary="",     required=False,
                  git_url="https://github.com/danielmiessler/SecLists.git",
                  git_dest="~/.local/share/wordlists/SecLists"),

        ToolEntry("PayloadsAllTheThings", "Wordlists", "Web application payloads (~150 MB)",
                  binary="",     required=False,
                  git_url="https://github.com/swisskyrepo/PayloadsAllTheThings.git",
                  git_dest="~/.local/share/wordlists/PayloadsAllTheThings"),

        ToolEntry("FuzzDB",      "Wordlists", "Attack/discovery pattern database",
                  binary="",     required=False,
                  git_url="https://github.com/fuzzdb-project/fuzzdb.git",
                  git_dest="~/.local/share/wordlists/fuzzdb"),

        ToolEntry("OneListForAll", "Wordlists", "Merged content-discovery wordlist",
                  binary="",     required=False,
                  git_url="https://github.com/six2dez/OneListForAll.git",
                  git_dest="~/.local/share/wordlists/OneListForAll"),

        ToolEntry("assetnote-wordlists", "Wordlists", "Assetnote automated wordlists",
                  binary="",     required=False,
                  git_url="https://github.com/assetnote/wordlists.git",
                  git_dest="~/.local/share/wordlists/assetnote"),

        # ── Nuclei Templates ──────────────────────────────────────────────
        ToolEntry("nuclei-templates", "Templates", "Official Nuclei vulnerability templates",
                  binary="",     required=False,
                  git_url="https://github.com/projectdiscovery/nuclei-templates.git",
                  git_dest="~/.local/nuclei-templates"),

        ToolEntry("fuzzing-templates", "Templates", "ProjectDiscovery fuzzing templates",
                  binary="",     required=False,
                  git_url="https://github.com/projectdiscovery/fuzzing-templates.git",
                  git_dest="~/.local/fuzzing-templates"),
    ]


# ══════════════════════════════════════════════════════════════════════════════
# OS / DISTRO DETECTION
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Distro:
    id:       str   # e.g. "ubuntu", "arch"
    family:   str   # "debian", "rhel", "arch", "suse"
    manager:  str   # "apt", "dnf", "pacman", "zypper"
    pretty:   str   # human label

    def install_cmd(self, pkg: str) -> str:
        """Return the full install shell command for a package."""
        cmds = {
            "apt":    f"sudo apt-get install -y {pkg}",
            "dnf":    f"sudo dnf install -y {pkg}",
            "pacman": f"sudo pacman -S --noconfirm {pkg}",
            "zypper": f"sudo zypper install -y {pkg}",
        }
        return cmds.get(self.manager, f"install {pkg}")

    def update_cmd(self) -> str:
        cmds = {
            "apt":    "sudo apt-get update -qq",
            "dnf":    "sudo dnf check-update -q || true",
            "pacman": "sudo pacman -Sy",
            "zypper": "sudo zypper refresh",
        }
        return cmds.get(self.manager, "")


def detect_distro() -> Distro:
    """
CIRCUIT+ — Install Manager: 60+ security tools across all distros.
    """
    os_info: Dict[str, str] = {}
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if "=" in line:
                k, _, v = line.partition("=")
                os_info[k.strip()] = v.strip().strip('"')
    except FileNotFoundError:
        pass

    dist_id    = os_info.get("ID", "").lower()
    id_like    = os_info.get("ID_LIKE", "").lower()
    pretty     = os_info.get("PRETTY_NAME", dist_id or "Linux")
    combined   = f"{dist_id} {id_like}"

    # Debian family
    if any(x in combined for x in ("debian", "ubuntu", "kali", "parrot", "mint", "pop", "raspbian", "elementary", "zorin")):
        return Distro(dist_id, "debian", "apt", pretty)

    # RHEL family
    if any(x in combined for x in ("fedora", "rhel", "centos", "rocky", "alma", "oracle", "scientific")):
        return Distro(dist_id, "rhel", "dnf", pretty)

    # Arch family
    if any(x in combined for x in ("arch", "manjaro", "blackarch", "garuda", "endeavour", "artix")):
        return Distro(dist_id, "arch", "pacman", pretty)

    # SUSE family
    if any(x in combined for x in ("opensuse", "suse", "sles")):
        return Distro(dist_id, "suse", "zypper", pretty)

    # Fallback: detect by binary presence
    for mgr in ("apt-get", "dnf", "pacman", "zypper"):
        if shutil.which(mgr):
            family_map = {"apt-get": "debian", "dnf": "rhel", "pacman": "arch", "zypper": "suse"}
            mgr_clean  = "apt" if mgr == "apt-get" else mgr
            return Distro("unknown", family_map[mgr], mgr_clean, "Linux (unknown distro)")

    return Distro("unknown", "unknown", "unknown", "Linux (undetected)")


# ══════════════════════════════════════════════════════════════════════════════
# STATUS CHECKING
# ══════════════════════════════════════════════════════════════════════════════

def _check_python_pkg(name: str) -> bool:
    """Return True if a Python package can be imported."""
    try:
        __import__(name.replace("-", "_"))
        return True
    except ImportError:
        return False


def _check_wordlist(entry: ToolEntry) -> bool:
    """Return True if the wordlist destination directory exists and is non-empty."""
    if not entry.git_dest:
        return False
    dest = Path(entry.git_dest.replace("~", str(Path.home())))
    return dest.exists() and any(dest.iterdir())


def _get_version(binary: str) -> Optional[str]:
    """Try common version flags and return a short version string."""
    for flag in ("--version", "-version", "version", "-V"):
        try:
            r = subprocess.run(
                [binary, flag], capture_output=True, text=True, timeout=4
            )
            out = (r.stdout + r.stderr).strip()
            for line in out.splitlines():
                line = line.strip()
                # Look for a version-like token
                m = re.search(r"v?(\d+\.\d+[\.\d]*)", line)
                if m:
                    return m.group(0)[:20]
                if line:
                    return line[:30]
        except Exception:
            pass
    return None


def refresh_status(entries: List[ToolEntry]) -> None:
    """Update .installed and .version for every entry in-place."""
    for e in entries:
        if e.category == "Python":
            e.installed = _check_python_pkg(e.pip_pkg or e.name)
            e.version   = None
        elif e.category in ("Wordlists", "Templates"):
            e.installed = _check_wordlist(e)
            e.version   = None
        else:
            found = bool(shutil.which(e.binary)) if e.binary else False
            e.installed = found
            if found:
                e.version = _get_version(e.binary)


# ══════════════════════════════════════════════════════════════════════════════
# INSTALLATION LOGIC
# ══════════════════════════════════════════════════════════════════════════════

def _run_live(
    cmd: str | list,
    label: str,
    cwd: str | None = None,
    env: dict | None = None,
) -> bool:
    """
    Run a command, streaming output live to the terminal.

    Args:
        cmd:   Shell string (shell=True) OR args list (shell=False).
        label: Human label shown on success/failure.
        cwd:   Working directory (default: current dir).
        env:   Environment dict (default: inherited).

    Returns True on exit code 0.
    """
    display = cmd if isinstance(cmd, str) else " ".join(str(c) for c in cmd)
    console.print(f"\n[dim cyan]  $ {display}[/dim cyan]")
    if cwd:
        console.print(f"[dim]  (cwd: {cwd})[/dim]")
    try:
        use_shell = isinstance(cmd, str)
        result = subprocess.run(
            cmd,
            shell=use_shell,
            text=True,
            cwd=cwd,
            env=env,
        )
        if result.returncode == 0:
            console.print(f"[bold green]  [+] {label} — done[/bold green]")
            return True
        else:
            console.print(f"[bold red]  [!] {label} — failed (exit {result.returncode})[/bold red]")
            return False
    except KeyboardInterrupt:
        console.print("[yellow]  [~] Interrupted[/yellow]")
        return False
    except FileNotFoundError as e:
        console.print(f"[bold red]  [!] Command not found: {e}[/bold red]")
        return False


def _ensure_go(distro: Distro) -> bool:
    """
    Ensure the `go` binary is available.
    Installs via package manager if missing, then patches PATH + GOPATH
    for the current session so subsequent go install calls work immediately.
    Returns True if `go` is usable after the call.
    """
    if shutil.which("go"):
        _patch_gopath_env()
        return True

    console.print("[yellow][~] Go not found. Attempting install via package manager...[/yellow]")

    # golang-go on apt is often old (1.13). Recommend manual install but try anyway.
    pkg_map = {"apt": "golang-go", "dnf": "golang", "pacman": "go", "zypper": "go"}
    pkg = pkg_map.get(distro.manager, "golang")
    ok = _run_live(distro.install_cmd(pkg), f"Install Go ({pkg})")

    if not ok or not shutil.which("go"):
        # Try common non-PATH locations
        for candidate in ("/usr/local/go/bin/go", "/usr/lib/go/bin/go"):
            if Path(candidate).exists():
                go_dir = str(Path(candidate).parent)
                os.environ["PATH"] = go_dir + ":" + os.environ["PATH"]
                console.print(f"[dim]  Found go at {candidate}, added {go_dir} to PATH[/dim]")
                break

    if not shutil.which("go"):
        console.print(
            "[bold red]  [!] Go still not found after install.[/bold red]\n"
            "  [dim]Install manually: https://go.dev/dl/\n"
            "  Then add to PATH: export PATH=$PATH:/usr/local/go/bin[/dim]"
        )
        return False

    _patch_gopath_env()
    return True


def _patch_gopath_env() -> str:
    """
    Ensure GOPATH and GOPATH/bin are set in the current process environment.
    Returns the resolved GOPATH string.
    """
    try:
        gopath = subprocess.run(
            ["go", "env", "GOPATH"],
            capture_output=True, text=True, timeout=10,
        ).stdout.strip()
    except Exception:
        gopath = str(Path.home() / "go")

    if not gopath:
        gopath = str(Path.home() / "go")

    gobin = str(Path(gopath) / "bin")
    os.environ["GOPATH"] = gopath

    path_parts = os.environ.get("PATH", "").split(":")
    if gobin not in path_parts:
        os.environ["PATH"] = gobin + ":" + os.environ["PATH"]
        console.print(f"[dim]  GOPATH={gopath}  →  added {gobin} to PATH[/dim]")

    return gopath


def _ensure_cargo(distro: Distro) -> bool:
    """
    Ensure cargo is available.
    Installs Rust via rustup if missing, then patches PATH for current session.
    Returns True if cargo is usable.
    """
    if shutil.which("cargo"):
        return True

    cargo_bin = Path.home() / ".cargo" / "bin" / "cargo"
    if cargo_bin.exists():
        # Already installed but not in PATH
        os.environ["PATH"] = str(cargo_bin.parent) + ":" + os.environ["PATH"]
        return True

    console.print("[yellow][~] Rust/cargo not found. Installing via rustup...[/yellow]")

    # Try system package first (faster, no internet)
    sys_pkg = {"apt": "cargo", "dnf": "cargo", "pacman": "rust", "zypper": "cargo"}.get(
        distro.manager if hasattr(distro, "manager") else "", ""
    )
    if sys_pkg:
        ok = _run_live(distro.install_cmd(sys_pkg), f"Install Rust via {distro.manager}")
        if ok and shutil.which("cargo"):
            return True

    # Fallback: rustup (always works)
    ok = _run_live(
        "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --no-modify-path",
        "Install Rust via rustup",
    )
    cargo_dir = str(Path.home() / ".cargo" / "bin")
    if Path(cargo_dir).exists():
        os.environ["PATH"] = cargo_dir + ":" + os.environ["PATH"]
        console.print(f"[dim]  Added {cargo_dir} to PATH[/dim]")

    if not shutil.which("cargo"):
        console.print(
            "[bold red]  [!] cargo still not found.[/bold red]\n"
            "  [dim]Try: source ~/.cargo/env  then re-run the installer.[/dim]"
        )
        return False
    return True


def _pip_install(pkg: str, distro: Distro) -> bool:
    """Install a Python package using the PEP 668-aware cascade."""
    import sys as _sys

    # 1. plain pip
    r = subprocess.run(
        [_sys.executable, "-m", "pip", "install", "--quiet", pkg],
        capture_output=True, text=True
    )
    if r.returncode == 0:
        return True

    pep668 = any(x in (r.stdout + r.stderr).lower() for x in
                 ["externally-managed", "pep 668", "break-system-packages"])

    if pep668:
        # 2. system package manager
        sys_pkg_map = {"apt": f"python3-{pkg}", "dnf": f"python3-{pkg}",
                       "pacman": f"python-{pkg}", "zypper": f"python3-{pkg}"}
        sys_pkg = sys_pkg_map.get(distro.manager, "")
        if sys_pkg:
            r2 = subprocess.run(distro.install_cmd(sys_pkg), shell=True)
            if r2.returncode == 0:
                return True
        # 3. --break-system-packages
        r3 = subprocess.run(
            [_sys.executable, "-m", "pip", "install", "--quiet",
             "--break-system-packages", pkg],
            capture_output=True, text=True
        )
        if r3.returncode == 0:
            return True

    return False


def install_entry(entry: ToolEntry, distro: Distro) -> bool:
    """
    Install a single ToolEntry using the best available method for this distro.

    Returns:
        True if installation succeeded (or was already present).
    """
    if entry.installed:
        console.print(f"[green][+] {entry.name} is already installed.[/green]")
        return True

    console.print(f"\n[bold bright_green]── Installing: {entry.name}[/bold bright_green]")
    console.print(f"   [dim]{entry.description}[/dim]")

    ok = False

    # ── Python package ────────────────────────────────────────────────────────
    if entry.category == "Python":
        pkg = entry.pip_pkg or entry.name
        ok = _pip_install(pkg, distro)

    # ── Wordlist / Template (git clone) ───────────────────────────────────────
    elif entry.category in ("Wordlists", "Templates"):
        if not entry.git_url or not entry.git_dest:
            console.print(f"[red][!] No git URL defined for {entry.name}[/red]")
            return False
        dest = entry.git_dest.replace("~", str(Path.home()))
        Path(dest).parent.mkdir(parents=True, exist_ok=True)
        if Path(dest).exists():
            # Update existing clone
            ok = _run_live(f"git -C {dest} pull --quiet", f"Update {entry.name}")
        else:
            ok = _run_live(
                f"git clone --depth 1 {entry.git_url} {dest}",
                f"Clone {entry.name}"
            )

    # ── Go tool ───────────────────────────────────────────────────────────────
    elif entry.go_pkg:
        if not _ensure_go(distro):
            console.print("[red][!] Go unavailable — cannot install Go tools.[/red]")
            return False

        gopath = _patch_gopath_env()

        # Build a fully clean Go environment:
        go_env = os.environ.copy()
        go_env["GOPATH"]     = gopath
        go_env["GOFLAGS"]    = ""       # clear -mod=vendor or similar flags
        go_env["GONOSUMDB"]  = "*"      # correct env var (not GONOSUMCHECK)
        go_env["GONOSUMCHECK"] = "*"    # also set for older go versions
        go_env["GOFLAGS"]    = ""
        go_env.pop("GOMOD",  None)      # do NOT inherit a parent go.mod
        go_env.pop("GOWORK", None)      # do NOT inherit go workspace file

        # Set GOCACHE to a user-writable location in case the default is broken
        gocache = str(Path.home() / ".cache" / "go-build")
        go_env["GOCACHE"] = gocache
        Path(gocache).mkdir(parents=True, exist_ok=True)

        # Set GOTMPDIR explicitly to a writable temp dir.
        # /tmp on some distros is mounted noexec which breaks go build.
        # We use ~/.cache/go-tmp which is always writable and exec-able.
        go_tmp = str(Path.home() / ".cache" / "go-tmp")
        Path(go_tmp).mkdir(parents=True, exist_ok=True)
        go_env["GOTMPDIR"] = go_tmp

        # Neutral working directory — MUST be outside any project tree.
        # We use GOPATH itself (always exists, no go.mod there).
        cwd_for_install = gopath

        # Fix: amass uses wildcard "...@master" which needs GONOSUMDB + GOFLAGS=-mod=mod
        # Several packages need -mod=mod to install from non-release branches
        pkg = entry.go_pkg
        if "...@" in pkg or "@master" in pkg or "@main" in pkg:
            go_env["GOFLAGS"] = "-mod=mod"

        go_cmd = ["go", "install", "-v", pkg]

        console.print(f"  [dim]GOPATH: {gopath}[/dim]")
        console.print(f"  [dim]GOTMPDIR: {go_tmp}[/dim]")
        ok = _run_live(go_cmd, f"go install {entry.name}",
                       cwd=cwd_for_install, env=go_env)

        if ok:
            gobin_path = str(Path(gopath) / "bin" / entry.binary)
            if entry.binary and Path(gobin_path).exists():
                console.print(f"[dim]  Binary: {gobin_path}[/dim]")
                # Ensure it's in PATH for the current session
                gobin_dir = str(Path(gopath) / "bin")
                if gobin_dir not in os.environ.get("PATH",""):
                    os.environ["PATH"] = gobin_dir + ":" + os.environ["PATH"]
            elif entry.binary and not shutil.which(entry.binary):
                console.print(
                    f"[yellow]  [~] '{entry.binary}' not in PATH yet.\n"
                    f"  Add permanently:\n"
                    f"  echo 'export PATH=$PATH:{gopath}/bin' >> ~/.bashrc && source ~/.bashrc[/yellow]"
                )

    # ── Cargo / Rust tool ─────────────────────────────────────────────────────
    elif entry.cargo_pkg:
        if not _ensure_cargo(distro):
            console.print("[red][!] Cargo unavailable — cannot install Rust tools.[/red]")
            return False
        # Use args list so the crate name is never shell-interpreted
        cargo_cmd = ["cargo", "install", "--locked", entry.cargo_pkg]
        ok = _run_live(cargo_cmd, f"cargo install {entry.name}")

    # ── System package manager ────────────────────────────────────────────────
    else:
        pkg_attr = f"{distro.manager}_pkg"
        pkg = getattr(entry, pkg_attr, "") or entry.apt_pkg
        if not pkg:
            if entry.manual_hint:
                console.print(f"[yellow][~] Manual install required:[/yellow]\n    {entry.manual_hint}")
            else:
                console.print(f"[red][!] No install method for {entry.name} on {distro.manager}[/red]")
            return False
        ok = _run_live(distro.install_cmd(pkg), f"Install {entry.name}")

    if ok:
        entry.installed = True
        # Try to grab the version now
        if entry.binary and shutil.which(entry.binary):
            entry.version = _get_version(entry.binary)
    return ok


# ══════════════════════════════════════════════════════════════════════════════
# RICH TABLE RENDERER
# ══════════════════════════════════════════════════════════════════════════════

_CATEGORY_ORDER = [
    "Python", "System", "Go / Recon", "Go / Web", "Go / Net",
    "Go / Utils", "Go / OOB", "Rust / Net", "Rust / Web",
    "Wordlists", "Templates",
]

def _status_cell(entry: ToolEntry) -> Text:
    if entry.installed is None:
        return Text("? checking", style="dim")
    if entry.installed:
        ver = f"  {entry.version}" if entry.version else ""
        return Text(f"✓ installed{ver}", style="bold green")
    return Text("✗ missing", style="bold red")


def build_status_table(
    entries: List[ToolEntry],
    selected: Optional[set[int]] = None,
    show_index: bool = True,
) -> Table:
    """Render the full tool list as a numbered Rich table."""
    table = Table(
        title="[bold bright_green]// CIRCUIT+ — Install Manager[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
        show_lines=False,
    )
    if show_index:
        table.add_column("#",         width=4,  justify="right", style="dim")
    table.add_column("Tool",          width=22, style="bold cyan")
    table.add_column("Category",      width=14, style="dim")
    table.add_column("Status",        width=22)
    table.add_column("Description",   width=42, style="dim")

    current_cat = ""
    for idx, e in enumerate(entries, 1):
        # Category separator row
        if e.category != current_cat:
            current_cat = e.category
            table.add_row(
                *(([""] if show_index else []) + [
                    f"[bold white]── {current_cat} ──",
                    "", "", "",
                ]),
            )

        sel_mark = "[bold yellow]►[/bold yellow] " if (selected and idx in selected) else "  "
        req_mark = "[red]★[/red]" if e.required else " "
        name_cell = f"{sel_mark}{req_mark} {e.name}"

        row_style = "on grey11" if idx % 2 == 0 else ""
        if show_index:
            table.add_row(
                str(idx), name_cell, e.category,
                _status_cell(e), e.description,
                style=row_style,
            )
        else:
            table.add_row(
                name_cell, e.category,
                _status_cell(e), e.description,
                style=row_style,
            )

    return table


# ══════════════════════════════════════════════════════════════════════════════
# INTERACTIVE MENU LOOP
# ══════════════════════════════════════════════════════════════════════════════

def _print_legend() -> None:
    console.print(
        "[dim]  [red]★[/red] = required  │  "
        "[bold yellow]►[/bold yellow] = selected  │  "
        "[green]✓[/green] = installed  │  "
        "[red]✗[/red] = missing[/dim]"
    )


def _print_commands() -> None:
    console.print(Panel(
        "  [bold cyan]<number>[/bold cyan]        toggle selection  (e.g. [cyan]3[/cyan] or [cyan]3 7 12[/cyan])\n"
        "  [bold cyan]a[/bold cyan] / [bold cyan]all[/bold cyan]       select ALL missing\n"
        "  [bold cyan]r[/bold cyan] / [bold cyan]req[/bold cyan]       select all REQUIRED missing\n"
        "  [bold cyan]c[/bold cyan] / [bold cyan]cat <name>[/bold cyan] select all missing in category\n"
        "  [bold cyan]i[/bold cyan] / [bold cyan]install[/bold cyan]   install selected items\n"
        "  [bold cyan]s[/bold cyan] / [bold cyan]status[/bold cyan]    re-scan installed status\n"
        "  [bold cyan]x[/bold cyan] / [bold cyan]clear[/bold cyan]     clear selection\n"
        "  [bold cyan]0[/bold cyan] / [bold cyan]back[/bold cyan]      return to main menu",
        title="[bold bright_green]// Commands[/bold bright_green]",
        border_style="green",
        expand=False,
    ))


def run_installer_menu(cfg=None) -> None:
    """
    Main interactive install manager loop.
    Detects distro, shows full tool table, handles selection and installation.

    Args:
        cfg: CIRCUIT+ Config object (optional, used for wordlist path).
    """
    distro = detect_distro()

    # Detect Go/cargo state upfront and show a setup tip
    gopath = ""
    if shutil.which("go"):
        try:
            gopath = subprocess.run(
                ["go", "env", "GOPATH"], capture_output=True, text=True, timeout=5
            ).stdout.strip() or str(Path.home() / "go")
        except Exception:
            gopath = str(Path.home() / "go")
        gobin = str(Path(gopath) / "bin")
        in_path = gobin in os.environ.get("PATH", "")
    else:
        gobin = str(Path.home() / "go" / "bin")
        in_path = False

    console.print()
    from rich.panel import Panel as _P
    tips = (
        f"  Distro: [cyan]{distro.pretty}[/cyan]  |  "
        f"Package manager: [cyan]{distro.manager}[/cyan]\n\n"
        f"  [bold]Go tools[/bold] install to: [cyan]{gobin}[/cyan]  "
        + ("[green]✓ in PATH[/green]" if in_path else "[red]✗ NOT in PATH[/red]") + "\n"
        f"  [bold]Rust tools[/bold] install to: [cyan]{Path.home()}/.cargo/bin[/cyan]\n\n"
        f"  [dim]To make Go/Rust tools permanent, add to ~/.bashrc:\n"
        f"  export PATH=\"$PATH:{gobin}:$HOME/.cargo/bin\"[/dim]"
    )
    console.print(_P(tips, title="[bold bright_green]// Install Manager[/bold bright_green]",
                     border_style="bright_green", expand=False))
    console.print()

    entries = _build_registry()

    # Initial status scan with spinner
    with Progress(
        SpinnerColumn(style="bright_green"),
        TextColumn("[bright_green]Scanning installed tools..."),
        TimeElapsedColumn(),
        console=console, transient=True,
    ) as prog:
        prog.add_task("scan")
        refresh_status(entries)

    selected: set[int] = set()   # 1-based indices

    while True:
        try:
            # Print table
            console.print()
            console.print(build_status_table(entries, selected))
            _print_legend()

            installed_count = sum(1 for e in entries if e.installed)
            total_count     = len(entries)
            missing_count   = total_count - installed_count
            console.print(
                f"\n  [dim]Total: {total_count}  │  "
                f"[green]Installed: {installed_count}[/green]  │  "
                f"[red]Missing: {missing_count}[/red]  │  "
                f"[yellow]Selected: {len(selected)}[/yellow][/dim]"
            )

            _print_commands()

            raw = input("\n\033[92minstaller> \033[0m").strip().lower()
            if not raw:
                continue

            # ── Exit ──────────────────────────────────────────────────────
            if raw in ("0", "back", "q", "exit"):
                break

            # ── Re-scan ───────────────────────────────────────────────────
            elif raw in ("s", "status", "refresh"):
                with Progress(SpinnerColumn(style="bright_green"),
                               TextColumn("[bright_green]Refreshing status..."),
                               console=console, transient=True) as p:
                    p.add_task("x")
                    refresh_status(entries)
                console.print("[green][+] Status refreshed.[/green]")

            # ── Show commands ─────────────────────────────────────────────
            elif raw in ("h", "help", "?"):
                _print_commands()

            # ── Clear selection ───────────────────────────────────────────
            elif raw in ("x", "clear", "none"):
                selected.clear()
                console.print("[dim]  Selection cleared.[/dim]")

            # ── Select all missing ─────────────────────────────────────────
            elif raw in ("a", "all"):
                selected = {i for i, e in enumerate(entries, 1) if not e.installed}
                console.print(f"[cyan][*] Selected {len(selected)} missing tools.[/cyan]")

            # ── Select required missing ────────────────────────────────────
            elif raw in ("r", "req", "required"):
                selected = {i for i, e in enumerate(entries, 1)
                            if not e.installed and e.required}
                console.print(f"[cyan][*] Selected {len(selected)} required tools.[/cyan]")

            # ── Select by category ─────────────────────────────────────────
            elif raw.startswith("c ") or raw.startswith("cat "):
                cat_query = raw.split(None, 1)[1].strip().lower()
                matched = {i for i, e in enumerate(entries, 1)
                           if cat_query in e.category.lower() and not e.installed}
                if matched:
                    selected |= matched
                    console.print(f"[cyan][*] Added {len(matched)} from matching categories.[/cyan]")
                else:
                    console.print(f"[yellow][~] No missing tools found in category matching '{cat_query}'.[/yellow]")
                    console.print(f"[dim]    Categories: {', '.join(_CATEGORY_ORDER)}[/dim]")

            # ── Install selected ──────────────────────────────────────────
            elif raw in ("i", "install", "go"):
                if not selected:
                    console.print("[yellow][~] Nothing selected. Use 'a' for all or type numbers.[/yellow]")
                    continue

                to_install = [entries[i - 1] for i in sorted(selected)]
                console.print(
                    Panel(
                        "\n".join(f"  [cyan]{e.name}[/cyan]  [dim]{e.description}[/dim]"
                                  for e in to_install),
                        title=f"[bold bright_green]// Installing {len(to_install)} items[/bold bright_green]",
                        border_style="bright_green",
                    )
                )

                try:
                    confirm = input("\033[92m[?] Proceed? [Y/n]: \033[0m").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    continue
                if confirm not in ("", "y", "yes"):
                    console.print("[dim]  Aborted.[/dim]")
                    continue

                succeeded = []
                failed    = []
                for e in to_install:
                    try:
                        ok = install_entry(e, distro)
                        (succeeded if ok else failed).append(e.name)
                    except KeyboardInterrupt:
                        console.print("\n[yellow][~] Installation interrupted.[/yellow]")
                        break

                console.print()
                if succeeded:
                    console.print(f"[bold green][+] Installed ({len(succeeded)}): {', '.join(succeeded)}[/bold green]")
                if failed:
                    console.print(f"[bold red][!] Failed    ({len(failed)}): {', '.join(failed)}[/bold red]")
                    console.print("[dim]    Check output above for details. Some tools may require manual steps.[/dim]")

                # Remove successfully installed from selection
                for i in list(selected):
                    if entries[i - 1].name in succeeded:
                        selected.discard(i)

                # Add GOPATH/bin reminder if Go tools were installed
                if any(entries[i - 1].go_pkg for i in range(1, len(entries) + 1)
                       if entries[i - 1].name in succeeded):
                    gopath = subprocess.run(
                        ["go", "env", "GOPATH"], capture_output=True, text=True
                    ).stdout.strip() if shutil.which("go") else "~/go"
                    console.print(
                        f"\n[yellow][~] Reminder:[/yellow] Add Go binaries to your PATH permanently:\n"
                        f"  [dim]echo 'export PATH=\"$PATH:{gopath}/bin\"' >> ~/.bashrc && source ~/.bashrc[/dim]"
                    )

            # ── Number toggling ───────────────────────────────────────────
            else:
                tokens = raw.replace(",", " ").split()
                toggled = 0
                for tok in tokens:
                    # Range like 3-7
                    if "-" in tok:
                        try:
                            lo, hi = tok.split("-", 1)
                            for n in range(int(lo), int(hi) + 1):
                                if 1 <= n <= len(entries):
                                    if n in selected:
                                        selected.discard(n)
                                    else:
                                        selected.add(n)
                                    toggled += 1
                        except ValueError:
                            pass
                    elif tok.isdigit():
                        n = int(tok)
                        if 1 <= n <= len(entries):
                            if n in selected:
                                selected.discard(n)
                                console.print(f"[dim]  Deselected [{n}] {entries[n-1].name}[/dim]")
                            else:
                                selected.add(n)
                                console.print(f"[cyan]  Selected   [{n}] {entries[n-1].name}[/cyan]")
                            toggled += 1
                        else:
                            console.print(f"[red][!] Number out of range: {n} (1–{len(entries)})[/red]")
                    else:
                        # Try name match
                        matches = [i for i, e in enumerate(entries, 1)
                                   if tok in e.name.lower()]
                        if matches:
                            for n in matches:
                                if n in selected:
                                    selected.discard(n)
                                else:
                                    selected.add(n)
                            toggled += len(matches)
                        else:
                            console.print(f"[red][!] Unknown command or tool: '{tok}'[/red]")

                if toggled and len(tokens) > 1:
                    console.print(f"[dim]  {toggled} items toggled. Selected: {len(selected)}[/dim]")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break
        except EOFError:
            break
