#!/usr/bin/env python3
"""
CIRCUIT+ — Loot Browser: navigate and view past scan results.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from config import Config


# ── Helpers ───────────────────────────────────────────────────────────────────

def _human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n //= 1024
    return f"{n:.0f} TB"


def _file_age(path: Path) -> str:
    mtime = path.stat().st_mtime
    age   = datetime.now().timestamp() - mtime
    if age < 3600:
        return f"{int(age//60)}m ago"
    if age < 86400:
        return f"{int(age//3600)}h ago"
    return f"{int(age//86400)}d ago"


def _count_files(directory: Path) -> int:
    try:
        return sum(1 for _ in directory.rglob("*") if _.is_file())
    except Exception:
        return 0


def _dir_size(directory: Path) -> int:
    try:
        return sum(f.stat().st_size for f in directory.rglob("*") if f.is_file())
    except Exception:
        return 0


# ── Listing functions ─────────────────────────────────────────────────────────

def _list_scans(loot_root: Path) -> list[Path]:
    """Return sorted list of top-level scan directories."""
    if not loot_root.exists():
        return []
    return sorted(
        [d for d in loot_root.iterdir() if d.is_dir()],
        key=lambda d: d.stat().st_mtime, reverse=True,
    )


def _list_scan_runs(scan_dir: Path) -> list[Path]:
    """Return timestamped run directories inside a scan directory."""
    return sorted(
        [d for d in scan_dir.iterdir() if d.is_dir()],
        key=lambda d: d.stat().st_mtime, reverse=True,
    )


def _list_files(directory: Path) -> list[Path]:
    """Return all files in a directory (non-recursive)."""
    return sorted(
        [f for f in directory.iterdir() if f.is_file()],
        key=lambda f: f.stat().st_mtime, reverse=True,
    )


# ── File viewer ───────────────────────────────────────────────────────────────

def _view_file(path: Path) -> None:
    """View a file with syntax highlighting where possible."""
    if not path.exists():
        log_err(f"File not found: {path}")
        return

    size = path.stat().st_size
    if size > 500_000:
        log_warn(f"File is large ({_human_size(size)}) — showing first 200 lines.")

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        log_err(f"Cannot read: {e}")
        return

    lines = content.splitlines()[:200]
    content_preview = "\n".join(lines)

    # Detect type for syntax highlighting
    ext_map = {
        ".json": "json", ".xml": "xml", ".html": "html",
        ".md": "markdown", ".py": "python", ".sh": "bash",
        ".txt": "text", ".log": "text",
    }
    lexer = ext_map.get(path.suffix.lower(), "text")

    console.print()
    console.print(Panel(
        Syntax(content_preview, lexer, theme="monokai", line_numbers=True,
               word_wrap=True),
        title=f"[bold bright_green]// {path.name}[/bold bright_green]  "
              f"[dim]{_human_size(size)} | {len(lines)} lines shown[/dim]",
        border_style="bright_green",
    ))

    if len(path.read_text(encoding="utf-8", errors="replace").splitlines()) > 200:
        console.print(f"  [dim](showing 200 of "
                      f"{len(path.read_text(errors='replace').splitlines())} lines)[/dim]")


# ── Main browser ──────────────────────────────────────────────────────────────

def run_loot_browser(cfg: Config) -> None:
    """
    Interactive loot directory browser.
    Navigate: scan → run → files → view/copy/delete.
    """
    loot_root = cfg.loot_path

    if not loot_root.exists():
        log_warn(f"Loot directory doesn't exist yet: {loot_root}")
        log_info("Run some scans first.")
        return

    # ── Level 1: Scan list ────────────────────────────────────────────────────
    while True:
        scans = _list_scans(loot_root)
        console.print()

        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",       width=4,  justify="right", style="dim")
        tbl.add_column("Target",  width=28, style="bold cyan")
        tbl.add_column("Runs",    width=6,  justify="right", style="dim")
        tbl.add_column("Files",   width=7,  justify="right", style="dim")
        tbl.add_column("Size",    width=8,  justify="right", style="dim")
        tbl.add_column("Latest",  width=10, style="dim")

        for i, scan_dir in enumerate(scans, 1):
            runs  = len(_list_scan_runs(scan_dir))
            files = _count_files(scan_dir)
            size  = _dir_size(scan_dir)
            age   = _file_age(scan_dir) if files else "—"
            tbl.add_row(
                str(i), scan_dir.name, str(runs), str(files),
                _human_size(size), age,
                style="on grey11" if i % 2 == 0 else "",
            )

        if not scans:
            tbl.add_row("", "[dim]No scan results yet[/dim]", "", "", "", "", style="on grey11")

        console.print(Panel(
            tbl,
            title=f"[bold bright_green]// Loot Browser[/bold bright_green]  "
                  f"[dim]{loot_root}[/dim]",
            border_style="bright_green", expand=False,
        ))
        console.print(
            "  [cyan]<#>[/cyan] Open scan     "
            "[cyan][d] <#>[/cyan] Delete scan     "
            "[cyan][o][/cyan] Open in file manager     "
            "[cyan][0][/cyan] Back"
        )

        try:
            cmd = input("\033[92m  loot> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0", "back"):
            break

        parts = cmd.split(None, 1)
        verb  = parts[0].lower()
        arg   = parts[1].strip() if len(parts) > 1 else ""

        # Numeric → drill into scan
        if verb.isdigit():
            idx = int(verb) - 1
            if 0 <= idx < len(scans):
                _browse_scan(scans[idx])
            else:
                log_warn(f"No scan #{verb}")

        elif verb == "d" and arg.isdigit():
            idx = int(arg) - 1
            if 0 <= idx < len(scans):
                target = scans[idx].name
                try:
                    confirm = input(f"\033[92m[?] Delete all data for '{target}'? [y/N]: \033[0m").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    confirm = "n"
                if confirm in ("y","yes"):
                    shutil.rmtree(scans[idx])
                    log_ok(f"Deleted: {target}")

        elif verb == "o":
            if shutil.which("xdg-open"):
                subprocess.Popen(["xdg-open", str(loot_root)])
            else:
                log_warn("xdg-open not found.")

        else:
            log_warn(f"Unknown: {cmd}")


def _browse_scan(scan_dir: Path) -> None:
    """Level 2: browse runs inside a scan directory."""
    while True:
        runs = _list_scan_runs(scan_dir)
        console.print()

        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",      width=4,  justify="right", style="dim")
        tbl.add_column("Run",    width=20, style="bold cyan")
        tbl.add_column("Files",  width=7,  justify="right", style="dim")
        tbl.add_column("Size",   width=8,  justify="right", style="dim")
        tbl.add_column("Age",    width=10, style="dim")

        for i, run_dir in enumerate(runs, 1):
            files = _count_files(run_dir)
            size  = _dir_size(run_dir)
            age   = _file_age(run_dir) if files else "—"
            tbl.add_row(
                str(i), run_dir.name, str(files),
                _human_size(size), age,
                style="on grey11" if i % 2 == 0 else "",
            )

        if not runs:
            # Might be a flat structure (no timestamped subdirs)
            _browse_files(scan_dir)
            return

        console.print(Panel(
            tbl,
            title=f"[bold bright_green]// {scan_dir.name}[/bold bright_green]",
            border_style="bright_green", expand=False,
        ))
        console.print("  [cyan]<#>[/cyan] Open run    [cyan][0][/cyan] Back")

        try:
            cmd = input("\033[92m  run> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0", "back"):
            break

        if cmd.isdigit():
            idx = int(cmd) - 1
            if 0 <= idx < len(runs):
                _browse_files(runs[idx])
        else:
            log_warn(f"Unknown: {cmd}")


def _browse_files(directory: Path) -> None:
    """Level 3: browse and view files in a directory."""
    while True:
        # Recursively list all files
        all_files = sorted(directory.rglob("*"), key=lambda p: str(p))
        files     = [f for f in all_files if f.is_file()]
        console.print()

        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",     width=4,  justify="right", style="dim")
        tbl.add_column("File",  width=50, style="bold cyan")
        tbl.add_column("Size",  width=8,  justify="right", style="dim")
        tbl.add_column("Age",   width=10, style="dim")

        for i, f in enumerate(files, 1):
            rel  = str(f.relative_to(directory))
            size = _human_size(f.stat().st_size)
            age  = _file_age(f)
            tbl.add_row(str(i), rel[:49], size, age,
                        style="on grey11" if i % 2 == 0 else "")

        if not files:
            console.print(f"  [dim]No files in {directory}[/dim]")
            break

        console.print(Panel(
            tbl,
            title=f"[bold bright_green]// Files — {directory.name}[/bold bright_green]",
            border_style="bright_green", expand=False,
        ))
        console.print(
            "  [cyan]<#>[/cyan] View file    "
            "[cyan][c] <#>[/cyan] Copy path    "
            "[cyan][d] <#>[/cyan] Delete    "
            "[cyan][o] <#>[/cyan] Open with xdg    "
            "[cyan][0][/cyan] Back"
        )

        try:
            cmd = input("\033[92m  files> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0","back"):
            break

        parts = cmd.split(None, 1)
        verb  = parts[0].lower()
        arg   = parts[1].strip() if len(parts) > 1 else ""

        def _resolve_file(a: str) -> Optional[Path]:
            if a.isdigit():
                idx = int(a) - 1
                return files[idx] if 0 <= idx < len(files) else None
            return None

        if verb.isdigit():
            f = _resolve_file(verb)
            if f: _view_file(f)

        elif verb == "c" and arg:
            f = _resolve_file(arg)
            if f:
                console.print(f"  [cyan]{f}[/cyan]")
                # Try clipboard
                for clip in (["xclip","-selection","clipboard"],["xsel","--clipboard","--input"],["wl-copy"]):
                    if shutil.which(clip[0]):
                        try:
                            subprocess.run(clip, input=str(f), text=True, timeout=5)
                            log_ok("Path copied to clipboard.")
                        except Exception:
                            pass
                        break

        elif verb == "d" and arg:
            f = _resolve_file(arg)
            if f:
                try:
                    confirm = input(f"\033[92m[?] Delete {f.name}? [y/N]: \033[0m").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    confirm = "n"
                if confirm in ("y","yes"):
                    f.unlink()
                    log_ok(f"Deleted: {f.name}")

        elif verb == "o" and arg:
            f = _resolve_file(arg)
            if f and shutil.which("xdg-open"):
                subprocess.Popen(["xdg-open", str(f)])

        else:
            log_warn(f"Unknown: {cmd}")
