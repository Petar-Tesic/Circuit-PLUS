#!/usr/bin/env python3
"""
CIRCUIT+ — Cloud Storage Enum: S3, GCS, Azure bucket discovery.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import make_loot_dir, timestamp
from config import Config, append_history

# ── Permutation generator ─────────────────────────────────────────────────────

_AFFIXES = [
    "", "-dev", "-prod", "-staging", "-test", "-backup", "-bak",
    "-assets", "-static", "-media", "-images", "-files", "-data",
    "-logs", "-cdn", "-public", "-private", "-internal", "-admin",
    "-uploads", "-content", "-resources", "-releases", "-archive",
    "-www", "-web", "-api", "-mobile", "-app", "-s3", "-storage",
    "dev", "prod", "staging", "test", "backup", "assets", "data",
    "media", "static", "files", "cdn", "public",
]


def _generate_names(target: str) -> list[str]:
    """
    Generate bucket name permutations from a domain/company name.

    Args:
        target: Domain name like 'example.com' or 'acme'.

    Returns:
        Sorted unique list of candidate bucket names.
    """
    # Extract base name (strip TLD)
    base = target.lower()
    for suffix in (".com",".net",".org",".io",".co",".us",".uk",".de",".fr"):
        if base.endswith(suffix):
            base = base[:-len(suffix)]
            break
    # Also try without subdomain
    parts = base.split(".")
    names = set()
    for part in [parts[-1], parts[0], ".".join(parts)]:
        clean = re.sub(r"[^a-z0-9\-]", "-", part).strip("-")
        if len(clean) < 3:
            continue
        for affix in _AFFIXES:
            candidate = f"{clean}{affix}"
            if 3 <= len(candidate) <= 63:
                names.add(candidate)
            if affix:
                candidate2 = f"{affix.strip('-')}-{clean}"
                if 3 <= len(candidate2) <= 63:
                    names.add(candidate2)
    return sorted(names)


# ── Check functions ───────────────────────────────────────────────────────────

def _curl_head(url: str, timeout: int = 8) -> tuple[int, dict[str, str]]:
    """Return (HTTP status code, headers dict) for a HEAD request."""
    if not shutil.which("curl"):
        return -1, {}
    try:
        r = subprocess.run(
            ["curl", "-sI", "--max-time", str(timeout),
             "-o", "/dev/null", "-w",
             "%{http_code}\\n%{header{x-amz-bucket-region}}\\n"
             "%{header{x-ms-version}}\\n%{header{x-goog-stored-content-length}}",
             url],
            capture_output=True, text=True, timeout=timeout + 3,
        )
        lines = r.stdout.strip().splitlines()
        code  = int(lines[0]) if lines else 0
        hdrs: dict[str, str] = {}
        if len(lines) > 1 and lines[1]: hdrs["x-amz-bucket-region"] = lines[1]
        if len(lines) > 2 and lines[2]: hdrs["x-ms-version"]        = lines[2]
        if len(lines) > 3 and lines[3]: hdrs["x-goog-content-len"]  = lines[3]
        return code, hdrs
    except Exception:
        return 0, {}


def _check_s3(bucket: str) -> dict | None:
    """
    Check an AWS S3 bucket name.
    Returns finding dict if public/misconfigured, else None.
    """
    url  = f"https://{bucket}.s3.amazonaws.com/"
    url2 = f"https://s3.amazonaws.com/{bucket}/"
    for test_url in (url, url2):
        code, hdrs = _curl_head(test_url)
        if code == 200:
            return {"provider": "AWS S3", "name": bucket, "url": test_url,
                    "status": "PUBLIC (200)", "severity": "CRITICAL"}
        if code == 403:
            return {"provider": "AWS S3", "name": bucket, "url": test_url,
                    "status": "EXISTS (403 Forbidden)", "severity": "INFO"}
        if code == 301 and hdrs.get("x-amz-bucket-region"):
            region = hdrs["x-amz-bucket-region"]
            regional = f"https://{bucket}.s3.{region}.amazonaws.com/"
            code2, _ = _curl_head(regional)
            if code2 == 200:
                return {"provider": "AWS S3", "name": bucket, "url": regional,
                        "status": "PUBLIC (200)", "severity": "CRITICAL"}
    return None


def _check_gcs(bucket: str) -> dict | None:
    """Check a Google Cloud Storage bucket."""
    url  = f"https://storage.googleapis.com/{bucket}/"
    url2 = f"https://{bucket}.storage.googleapis.com/"
    for test_url in (url, url2):
        code, hdrs = _curl_head(test_url)
        if code == 200:
            return {"provider": "GCS", "name": bucket, "url": test_url,
                    "status": "PUBLIC (200)", "severity": "CRITICAL"}
        if code == 403:
            return {"provider": "GCS", "name": bucket, "url": test_url,
                    "status": "EXISTS (403)", "severity": "INFO"}
    return None


def _check_azure(bucket: str, account: Optional[str] = None) -> dict | None:
    """Check Azure Blob Storage containers."""
    if not account:
        account = bucket
    for container in (bucket, "public", "uploads", "assets", "data"):
        url = f"https://{account}.blob.core.windows.net/{container}?restype=container&comp=list"
        code, _ = _curl_head(url)
        if code == 200:
            return {"provider": "Azure Blob", "name": f"{account}/{container}",
                    "url": url, "status": "PUBLIC (200)", "severity": "CRITICAL"}
        if code == 403:
            return {"provider": "Azure Blob", "name": f"{account}/{container}",
                    "url": url, "status": "EXISTS (403)", "severity": "INFO"}
    return None


# ── Main scan function ────────────────────────────────────────────────────────

def cloud_enum(
    target: str,
    cfg: Config,
    check_s3: bool = True,
    check_gcs: bool = True,
    check_azure: bool = True,
    max_workers: int = 20,
) -> Optional[Path]:
    """
    Enumerate cloud storage buckets for a target domain/company.

    Args:
        target:      Domain name or company name.
        cfg:         Config.
        check_s3:    Check AWS S3.
        check_gcs:   Check Google Cloud Storage.
        check_azure: Check Azure Blob Storage.
        max_workers: Concurrent check threads.

    Returns:
        Path to results file, or None if nothing found.
    """
    if not shutil.which("curl"):
        log_err("curl not found — required for cloud enum.")
        return None

    names = _generate_names(target)
    log_info(f"Generated {len(names)} bucket name permutations for '{target}'")

    loot   = make_loot_dir(cfg.loot_path, target.replace(".", "_"), "cloud")
    output = loot / "cloud_findings.json"

    # Build task list
    tasks: list[tuple[str, callable]] = []
    for name in names:
        if check_s3:    tasks.append((name, _check_s3))
        if check_gcs:   tasks.append((name, _check_gcs))
        if check_azure: tasks.append((name, _check_azure))

    findings: list[dict] = []
    lock = threading.Lock()

    console.print(Panel(
        f"  Target:      [cyan]{target}[/cyan]\n"
        f"  Permutations: [white]{len(names)}[/white]\n"
        f"  Total checks: [white]{len(tasks)}[/white]  "
        f"(S3={check_s3}, GCS={check_gcs}, Azure={check_azure})\n"
        f"  Workers:      [white]{max_workers}[/white]",
        title="[bold bright_green]// Cloud Storage Enumeration[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    with Progress(
        SpinnerColumn(style="bright_green"),
        TextColumn("[bright_green]Checking buckets..."),
        BarColumn(style="bright_green"),
        TextColumn("[dim]{task.completed}/{task.total}"),
        TimeElapsedColumn(),
        console=console, transient=True,
    ) as prog:
        task_id = prog.add_task("cloud", total=len(tasks))

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {pool.submit(fn, name): (name, fn) for name, fn in tasks}
            for future in as_completed(futures):
                prog.advance(task_id)
                try:
                    result = future.result()
                    if result:
                        with lock:
                            findings.append(result)
                        severity = result["severity"]
                        color = "red" if "CRITICAL" in severity else "yellow"
                        console.print(
                            f"  [{color}][{severity}][/{color}] "
                            f"[cyan]{result['provider']}[/cyan] "
                            f"[white]{result['name']}[/white]  "
                            f"[dim]{result['status']}[/dim]"
                        )
                except Exception:
                    pass

    # Results table
    console.print()
    if findings:
        import json as _json
        tbl = Table(
            title=f"[bold bright_green]// Cloud Findings ({len(findings)})[/bold bright_green]",
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            header_style="bold bright_green", expand=False,
        )
        tbl.add_column("Severity", width=12)
        tbl.add_column("Provider", width=12, style="dim")
        tbl.add_column("Bucket",   width=30, style="cyan")
        tbl.add_column("Status",   width=20, style="dim")

        critical = [f for f in findings if "CRITICAL" in f["severity"]]
        info     = [f for f in findings if "INFO"     in f["severity"]]

        for i, f in enumerate(critical + info):
            color = "red" if "CRITICAL" in f["severity"] else "yellow"
            tbl.add_row(
                f"[{color}]{f['severity']}[/{color}]",
                f["provider"], f["name"], f["status"],
                style="on grey11" if i % 2 == 0 else "",
            )
        console.print(tbl)

        # Save JSON
        output.write_text(_json.dumps(findings, indent=2), encoding="utf-8")
        log_ok(f"Findings saved: {output}")
        log_ok(f"Critical: {len(critical)}  Info: {len(info)}")
    else:
        log_warn("No open or accessible cloud buckets found.")

    append_history({
        "ts": timestamp(), "action": "cloud_enum",
        "target": target, "checks": len(tasks), "findings": len(findings),
    })
    return output if findings else None


# ── Interactive menu ──────────────────────────────────────────────────────────

def run_cloud_menu(cfg: Config) -> None:
    """Interactive cloud enumeration entry point."""
    console.print()
    console.print(Panel(
        "  Enumerate cloud storage buckets (S3 / GCS / Azure) using\n"
        "  naming permutations derived from the target domain.\n\n"
        "  Checks for: public buckets (200) and existing private buckets (403).",
        title="[bold bright_green]// Cloud Storage Enum[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    try:
        target = input("\033[92m[?] Target domain or company name (0=back): \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if not target or target == "0":
        return

    try:
        providers = input(
            "\033[92m[?] Providers [s3,gcs,azure] (all=leave empty): \033[0m"
        ).strip().lower() or "s3,gcs,azure"
        workers = int(input("\033[92m[?] Workers [20]: \033[0m").strip() or "20")
    except (ValueError, EOFError, KeyboardInterrupt):
        providers, workers = "s3,gcs,azure", 20

    cloud_enum(
        target, cfg,
        check_s3    = "s3"    in providers,
        check_gcs   = "gcs"   in providers,
        check_azure = "azure" in providers,
        max_workers = workers,
    )
