#!/usr/bin/env python3
"""
CIRCUIT+ — CVE Correlator: match tech fingerprints to known CVEs.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional

from rich.panel import Panel
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import make_loot_dir, timestamp
from config import Config, append_history, get_ext

# ── Built-in high-impact advisory database ────────────────────────────────────
# Format: (tech_pattern, version_pattern, cve_id, severity, description, reference)
_ADVISORIES: list[tuple[str, str, str, str, str, str]] = [
    # Apache
    ("apache", r"2\.4\.(4[89]|5[01])",  "CVE-2021-41773", "CRITICAL",
     "Path traversal & RCE in Apache 2.4.49/2.4.50",
     "https://nvd.nist.gov/vuln/detail/CVE-2021-41773"),
    ("apache", r"2\.4\.(1[0-9]|2[0-9]|3[0-9]|4[0-8])", "CVE-2017-7679", "HIGH",
     "mod_mime buffer overread in Apache < 2.4.26",
     "https://nvd.nist.gov/vuln/detail/CVE-2017-7679"),
    # nginx
    ("nginx", r"1\.(1[0-7])\.", "CVE-2019-20372", "MEDIUM",
     "Request smuggling in nginx < 1.17.7 with HTTP/2",
     "https://nvd.nist.gov/vuln/detail/CVE-2019-20372"),
    # WordPress
    ("wordpress", r"[45]\.\d", "CVE-2022-21661", "HIGH",
     "WordPress < 5.8.3 SQLi via WP_Query",
     "https://nvd.nist.gov/vuln/detail/CVE-2022-21661"),
    ("wordpress", r"[1-5]\.\d", "CVE-2019-8942", "HIGH",
     "WordPress < 5.0.1 arbitrary file delete RCE",
     "https://nvd.nist.gov/vuln/detail/CVE-2019-8942"),
    # Drupal
    ("drupal", r"[78]\.", "CVE-2018-7600", "CRITICAL",
     "Drupalgeddon2 — RCE in Drupal 6/7/8 (SA-CORE-2018-002)",
     "https://nvd.nist.gov/vuln/detail/CVE-2018-7600"),
    ("drupal", r"[78]\.", "CVE-2018-7602", "CRITICAL",
     "Drupalgeddon3 — RCE (SA-CORE-2018-004)",
     "https://nvd.nist.gov/vuln/detail/CVE-2018-7602"),
    # Joomla
    ("joomla", r"[12]\.", "CVE-2015-8562", "CRITICAL",
     "Joomla PHP object injection → RCE",
     "https://nvd.nist.gov/vuln/detail/CVE-2015-8562"),
    ("joomla", r"3\.[0-7]", "CVE-2017-8917", "CRITICAL",
     "Joomla < 3.7.1 SQLi (CVE-2017-8917)",
     "https://nvd.nist.gov/vuln/detail/CVE-2017-8917"),
    # Struts
    ("struts", r"2\.(3|5)\.", "CVE-2017-5638", "CRITICAL",
     "Apache Struts 2 OGNL injection — Equifax breach vector",
     "https://nvd.nist.gov/vuln/detail/CVE-2017-5638"),
    # Log4j
    ("log4j", r"[12]\.", "CVE-2021-44228", "CRITICAL",
     "Log4Shell — JNDI injection RCE in Log4j 2.x (all apps using it)",
     "https://nvd.nist.gov/vuln/detail/CVE-2021-44228"),
    # Spring
    ("spring", r"5\.[012]\.", "CVE-2022-22965", "CRITICAL",
     "Spring4Shell — RCE via data binding in Spring Framework",
     "https://nvd.nist.gov/vuln/detail/CVE-2022-22965"),
    # PHP
    ("php", r"7\.[01234]\.", "CVE-2019-11043", "CRITICAL",
     "PHP-FPM RCE when nginx + fastcgi_split_path_info (CVE-2019-11043)",
     "https://nvd.nist.gov/vuln/detail/CVE-2019-11043"),
    # OpenSSL
    ("openssl", r"1\.0\.[12]", "CVE-2014-0160", "CRITICAL",
     "Heartbleed — OpenSSL 1.0.1–1.0.1f memory disclosure",
     "https://nvd.nist.gov/vuln/detail/CVE-2014-0160"),
    # ImageMagick
    ("imagemagick", r"[67]\.", "CVE-2016-3714", "CRITICAL",
     "ImageTragick — shell injection via policy.xml",
     "https://nvd.nist.gov/vuln/detail/CVE-2016-3714"),
    # Redis
    ("redis", r"[1234567]\.", "CVE-2022-0543", "CRITICAL",
     "Redis Lua sandbox escape → RCE (Debian/Ubuntu packages)",
     "https://nvd.nist.gov/vuln/detail/CVE-2022-0543"),
    # jQuery
    ("jquery", r"[12]\.", "CVE-2019-11358", "MEDIUM",
     "jQuery < 3.4.0 prototype pollution",
     "https://nvd.nist.gov/vuln/detail/CVE-2019-11358"),
    # Bootstrap
    ("bootstrap", r"[34]\.", "CVE-2019-8331", "MEDIUM",
     "Bootstrap XSS via data-template attribute",
     "https://nvd.nist.gov/vuln/detail/CVE-2019-8331"),
    # IIS
    ("iis", r"[67]\.", "CVE-2017-7269", "CRITICAL",
     "IIS 6.0 WebDAV buffer overflow → RCE",
     "https://nvd.nist.gov/vuln/detail/CVE-2017-7269"),
    # Magento
    ("magento", r"[12]\.", "CVE-2022-24086", "CRITICAL",
     "Magento improper input validation → RCE (pre-auth)",
     "https://nvd.nist.gov/vuln/detail/CVE-2022-24086"),
    # Node / Express
    ("express", r"[34]\.", "CVE-2022-24999", "HIGH",
     "Express qs prototype pollution",
     "https://nvd.nist.gov/vuln/detail/CVE-2022-24999"),
    # Elasticsearch
    ("elasticsearch", r"[1-7]\.", "CVE-2021-22145", "HIGH",
     "Elasticsearch heap memory disclosure via logging",
     "https://nvd.nist.gov/vuln/detail/CVE-2021-22145"),
]


# ── NVD API query ─────────────────────────────────────────────────────────────

def _nvd_search(keyword: str, api_key: Optional[str] = None,
                max_results: int = 5) -> list[dict]:
    """
    Query the NVD API for CVEs matching a keyword.
    Rate limit: 5 req/30s without key, 50 req/30s with key.

    Args:
        keyword:     Search keyword (e.g. "apache 2.4.49").
        api_key:     Optional NVD API key (set in extended config).
        max_results: Maximum CVEs to return.

    Returns:
        List of CVE dicts with id, severity, description.
    """
    if not shutil.which("curl"):
        return []

    url   = f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={keyword}&resultsPerPage={max_results}"
    cmd   = ["curl", "-s", "--max-time", "15", url]
    if api_key:
        cmd.extend(["--header", f"apiKey: {api_key}"])

    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        data = json.loads(r.stdout)
        results: list[dict] = []
        for item in data.get("vulnerabilities", []):
            cve = item.get("cve", {})
            cve_id   = cve.get("id", "")
            metrics  = cve.get("metrics", {})
            severity = "UNKNOWN"
            # Try CVSS v3.1 → v3.0 → v2
            for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                m = metrics.get(key, [])
                if m:
                    severity = m[0].get("cvssData",{}).get("baseSeverity",
                               m[0].get("baseSeverity", "UNKNOWN"))
                    break
            descriptions = cve.get("descriptions", [])
            desc = next((d["value"] for d in descriptions if d["lang"]=="en"), "")
            results.append({
                "id":          cve_id,
                "severity":    severity,
                "description": desc[:200],
            })
        return results
    except Exception:
        return []


# ── Correlation engine ────────────────────────────────────────────────────────

def correlate_tech(
    tech_list: list[str],
    cfg: Config,
    use_nvd: bool = True,
) -> list[dict]:
    """
    Cross-reference a list of detected technologies against CVE advisories.

    Args:
        tech_list: e.g. ["Apache 2.4.49", "WordPress 5.8", "jQuery 2.1.4"]
        cfg:       Config.
        use_nvd:   Whether to also query NVD API live.

    Returns:
        List of finding dicts sorted by severity.
    """
    findings: list[dict] = []
    api_key: Optional[str] = get_ext("nvd_api_key", None)

    for tech_str in tech_list:
        tech_lower = tech_str.lower()

        # ── Built-in advisory match ──────────────────────────────────────────
        for tech_pat, ver_pat, cve_id, severity, desc, ref in _ADVISORIES:
            if tech_pat not in tech_lower:
                continue
            # Try to match version if a version pattern is given
            ver_match = re.search(ver_pat, tech_lower)
            if ver_match:
                findings.append({
                    "tech":     tech_str,
                    "cve":      cve_id,
                    "severity": severity,
                    "desc":     desc,
                    "ref":      ref,
                    "source":   "built-in",
                })

        # ── NVD API lookup ────────────────────────────────────────────────────
        if use_nvd:
            nvd_results = _nvd_search(tech_str, api_key=api_key, max_results=3)
            for r in nvd_results:
                if r["severity"] in ("CRITICAL", "HIGH"):
                    findings.append({
                        "tech":     tech_str,
                        "cve":      r["id"],
                        "severity": r["severity"],
                        "desc":     r["description"],
                        "ref":      f"https://nvd.nist.gov/vuln/detail/{r['id']}",
                        "source":   "nvd-api",
                    })
            time.sleep(0.7)   # Stay within NVD rate limits

    # Sort: CRITICAL > HIGH > MEDIUM > LOW
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    findings.sort(key=lambda f: order.get(f["severity"], 9))

    # Deduplicate by CVE ID
    seen: set[str] = set()
    unique: list[dict] = []
    for f in findings:
        key = f["cve"] + f["tech"]
        if key not in seen:
            seen.add(key)
            unique.append(f)

    return unique


def print_cve_findings(findings: list[dict]) -> None:
    """Display CVE findings as a Rich table."""
    if not findings:
        log_warn("No known CVEs matched the detected technologies.")
        return

    tbl = Table(
        title=f"[bold bright_green]// CVE Correlation ({len(findings)} findings)[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    tbl.add_column("Severity", width=10)
    tbl.add_column("CVE",      width=18, style="bold cyan")
    tbl.add_column("Tech",     width=22, style="white")
    tbl.add_column("Description", width=50, style="dim")

    color_map = {"CRITICAL":"red","HIGH":"orange1","MEDIUM":"yellow","LOW":"green","UNKNOWN":"dim"}
    for i, f in enumerate(findings):
        color = color_map.get(f["severity"], "dim")
        tbl.add_row(
            f"[{color}]{f['severity']}[/{color}]",
            f["cve"], f["tech"][:21], f["desc"][:49],
            style="on grey11" if i % 2 == 0 else "",
        )
    console.print(tbl)

    critical = [f for f in findings if f["severity"] == "CRITICAL"]
    if critical:
        console.print(
            f"\n  [bold red][!] {len(critical)} CRITICAL CVEs found![/bold red]\n"
            f"  References:"
        )
        for f in critical[:5]:
            console.print(f"    [red]►[/red] {f['cve']} — {f['ref']}")


def run_cve_menu(cfg: Config) -> None:
    """Interactive CVE correlator entry point."""
    console.print()
    console.print(Panel(
        "  Match technology names/versions against known CVEs.\n"
        "  Checks built-in advisory database + NVD API (optional).\n\n"
        "  [1] Enter tech list manually\n"
        "  [2] Load from mass scan report JSON\n"
        "  [3] Set NVD API key (for higher rate limits)\n"
        "  [0] Back",
        title="[bold bright_green]// CVE Correlator[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    try:
        choice = input("\033[92m  cve> \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if choice == "0":
        return

    elif choice == "1":
        console.print("[dim]Enter technologies one per line (blank line to finish):[/dim]")
        console.print("[dim]Examples: Apache 2.4.49 | WordPress 5.8 | jQuery 2.1.4[/dim]")
        tech_list: list[str] = []
        while True:
            try:
                line = input("\033[92m  tech> \033[0m").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if not line:
                break
            tech_list.append(line)
        if tech_list:
            log_info(f"Correlating {len(tech_list)} technologies...")
            findings = correlate_tech(tech_list, cfg)
            print_cve_findings(findings)
            _save_cve_results(tech_list, findings, cfg)

    elif choice == "2":
        from utils.picker import pick_file
        path = pick_file(
            title="Select Mass Scan report.json",
            label="Report JSON",
            must_exist=True,
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if path:
            try:
                data = json.loads(Path(path).read_text(encoding="utf-8"))
                tech_list = []
                for phase in data.get("phases", []):
                    if phase.get("name") == "Tech Fingerprint":
                        for cat, techs in phase.get("data", {}).items():
                            if isinstance(techs, list):
                                tech_list.extend(techs)
                if tech_list:
                    log_info(f"Loaded {len(tech_list)} tech entries from report.")
                    findings = correlate_tech(tech_list, cfg)
                    print_cve_findings(findings)
                    _save_cve_results(tech_list, findings, cfg)
                else:
                    log_warn("No tech fingerprint data found in report.")
            except Exception as e:
                log_err(f"Failed to parse report: {e}")

    elif choice == "3":
        try:
            key = input("\033[92m[?] NVD API key (get free at nvd.nist.gov/developers): \033[0m").strip()
            if key:
                from config import set_ext
                set_ext("nvd_api_key", key)
                log_ok("NVD API key saved.")
        except (EOFError, KeyboardInterrupt):
            pass


def _save_cve_results(tech_list: list[str], findings: list[dict], cfg: Config) -> None:
    """Save CVE correlation results to loot."""
    if not findings:
        return
    loot = make_loot_dir(cfg.loot_path, "cve_correlation", "cve")
    out  = loot / f"cve_results_{timestamp()}.json"
    out.write_text(json.dumps({
        "technologies": tech_list,
        "findings": findings,
    }, indent=2), encoding="utf-8")
    log_ok(f"Results saved: {out}")
    append_history({
        "ts": timestamp(), "action": "cve_correlate",
        "tech_count": len(tech_list), "findings": len(findings),
    })
