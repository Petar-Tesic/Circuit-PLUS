#!/usr/bin/env python3
"""
CIRCUIT+ — Mod Runner  (v1.1)
Interpreter for .fscf (CIRCUIT+ Config/Flow) scripts.

Language spec:
  # comment lines start with hash
  var = input("prompt")          — prompt user, store result in var
  sys(command {var} ...)         — run shell command, {var} substituted
  print("message {var}")         — print text with optional variable substitution
  # blank lines are ignored

Variable substitution:
  {varname} inside sys() or print() is replaced with the stored value.
  If {varname} is not defined, the interpreter halts with a clear error.

Examples:
  ip = input("Enter target IP: ")
  sys(nmap -sV {ip})
  sys(curl -sI https://{ip})
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn

# ── Token types ───────────────────────────────────────────────────────────────

@dataclass
class FscfError(Exception):
    """Raised on any .fscf parse or runtime error."""
    message:  str
    line_num: int = 0
    line_src: str = ""

    def __str__(self) -> str:
        loc = f"line {self.line_num}: " if self.line_num else ""
        src = f"\n  Source: {self.line_src}" if self.line_src else ""
        return f"[FSCF Error] {loc}{self.message}{src}"


@dataclass
class Instruction:
    """One parsed instruction from a .fscf file."""
    kind:    str        # "assign" | "sys" | "print" | "comment" | "blank"
    line:    int        # 1-based source line number
    raw:     str        # original source text
    # assign fields
    var:     str = ""
    prompt:  str = ""
    # sys / print fields
    cmd:     str = ""   # raw command template (before substitution)


# ── Parser ────────────────────────────────────────────────────────────────────

# Patterns
_RE_ASSIGN = re.compile(r'^(\w+)\s*=\s*input\(\s*"([^"]*)"\s*\)\s*$')
_RE_SYS    = re.compile(r'^sys\((.+)\)\s*$', re.DOTALL)
_RE_PRINT  = re.compile(r'^print\(\s*"([^"]*)"\s*\)\s*$')
_RE_VARREF = re.compile(r'\{(\w+)\}')


def parse_fscf(source: str) -> list[Instruction]:
    """
    Parse a .fscf source string into a list of Instructions.

    Args:
        source: Full file contents.

    Returns:
        List of Instruction objects.

    Raises:
        FscfError: On any syntax error.
    """
    instructions: list[Instruction] = []

    for lineno, raw_line in enumerate(source.splitlines(), 1):
        line = raw_line.strip()

        # Blank line
        if not line:
            instructions.append(Instruction(kind="blank", line=lineno, raw=raw_line))
            continue

        # Comment
        if line.startswith("#"):
            instructions.append(Instruction(kind="comment", line=lineno, raw=raw_line))
            continue

        # Assignment: var = input("prompt")
        m = _RE_ASSIGN.match(line)
        if m:
            instructions.append(Instruction(
                kind="assign", line=lineno, raw=raw_line,
                var=m.group(1), prompt=m.group(2),
            ))
            continue

        # sys(command)
        m = _RE_SYS.match(line)
        if m:
            cmd_template = m.group(1).strip()
            if not cmd_template:
                raise FscfError("sys() called with empty command", lineno, raw_line)
            instructions.append(Instruction(
                kind="sys", line=lineno, raw=raw_line,
                cmd=cmd_template,
            ))
            continue

        # print("message")
        m = _RE_PRINT.match(line)
        if m:
            instructions.append(Instruction(
                kind="print", line=lineno, raw=raw_line,
                cmd=m.group(1),
            ))
            continue

        # Unknown syntax
        raise FscfError(
            f"Unrecognised syntax. Expected: assignment, sys(), or print()",
            lineno, raw_line,
        )

    return instructions


# ── Variable substitution ─────────────────────────────────────────────────────

def _substitute(template: str, variables: dict[str, str], line: int, raw: str) -> str:
    """
CIRCUIT+ — Mod Runner: FSCF scripting interpreter and editor.
    """
    def _replacer(m: re.Match) -> str:
        name = m.group(1)
        if name not in variables:
            defined = ", ".join(variables.keys()) or "(none)"
            raise FscfError(
                f"Undefined variable '{{{name}}}'. "
                f"Defined variables: {defined}",
                line, raw,
            )
        return variables[name]

    return _RE_VARREF.sub(_replacer, template)


# ── Executor ──────────────────────────────────────────────────────────────────

class FscfRunner:
    """
    Executes a parsed .fscf instruction list.

    Args:
        mod_name:    Display name of the mod (for UI).
        dry_run:     If True, print what would run but don't execute sys() calls.
        safe_mode:   If True, only allow whitelisted binaries.
    """

    # Binaries that sys() is allowed to call.
    # Users can always add more via their own .fscf files.
    _ALLOWED_BINARIES: set[str] = {
        # Network
        "nmap", "masscan", "rustscan", "naabu", "ping", "traceroute",
        "tracepath", "netcat", "nc", "socat", "tcpdump", "arp-scan",
        # Web
        "curl", "wget", "ffuf", "gobuster", "feroxbuster", "nikto",
        "nuclei", "httpx", "katana", "gau", "waybackurls",
        # DNS / OSINT
        "dig", "nslookup", "whois", "host", "subfinder", "dnsx",
        "amass", "alterx", "massdns",
        # Misc tools
        "openssl", "ssh", "scp", "ftp", "telnet",
        "sqlmap", "hydra", "medusa", "john", "hashcat",
        "binwalk", "exiftool", "strings", "file",
        "grep", "cat", "head", "tail", "wc", "sort", "uniq", "cut", "awk",
        "find", "ls",
    }

    def __init__(
        self,
        mod_name:  str  = "mod",
        dry_run:   bool = False,
        safe_mode: bool = True,
    ) -> None:
        self.mod_name  = mod_name
        self.dry_run   = dry_run
        self.safe_mode = safe_mode
        self.variables: dict[str, str] = {}
        self.output_log: list[str] = []   # all output lines for optional saving

    def run(self, instructions: list[Instruction]) -> bool:
        """
        Execute all instructions in order.

        Returns:
            True if all instructions ran successfully, False on error.
        """
        self._log_header()

        for instr in instructions:
            if instr.kind in ("blank", "comment"):
                continue

            try:
                if instr.kind == "assign":
                    self._exec_assign(instr)
                elif instr.kind == "sys":
                    self._exec_sys(instr)
                elif instr.kind == "print":
                    self._exec_print(instr)
            except FscfError as e:
                console.print(
                    Panel(
                        f"[bold red]{e}[/bold red]",
                        title="[bold red]// FSCF Runtime Error[/bold red]",
                        border_style="red",
                        expand=False,
                    )
                )
                return False
            except KeyboardInterrupt:
                console.print("\n[yellow][~] Mod interrupted (Ctrl+C)[/yellow]")
                return False

        log_ok(f"Mod '{self.mod_name}' completed successfully.")
        return True

    # ── Instruction handlers ──────────────────────────────────────────────────

    def _exec_assign(self, instr: Instruction) -> None:
        """Handle: var = input("prompt")"""
        console.print(f"\n[dim cyan]  [{instr.line}][/dim cyan] "
                      f"[white]input[/white]([cyan]\"{instr.prompt}\"[/cyan]) → "
                      f"[yellow]{instr.var}[/yellow]")
        try:
            value = input(f"\033[92m  {instr.prompt} \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            raise FscfError(
                "Input cancelled by user.", instr.line, instr.raw
            )
        if not value:
            log_warn(f"  Warning: '{instr.var}' is empty — continuing.")
        self.variables[instr.var] = value
        self.output_log.append(f"[input] {instr.var} = {value!r}")

    def _exec_sys(self, instr: Instruction) -> None:
        """Handle: sys(command {var} ...)"""
        # Substitute variables
        cmd_resolved = _substitute(
            instr.cmd, self.variables, instr.line, instr.raw
        )

        # Split into argv to extract the binary name
        import shlex
        try:
            argv = shlex.split(cmd_resolved)
        except ValueError as e:
            raise FscfError(f"Cannot parse command: {e}", instr.line, instr.raw)

        if not argv:
            raise FscfError("sys() command is empty after substitution.",
                            instr.line, instr.raw)

        binary = argv[0]

        # Safety check
        if self.safe_mode and binary not in self._ALLOWED_BINARIES:
            raise FscfError(
                f"Binary '{binary}' is not in the allowed list.\n"
                f"  Add it to the whitelist or run with safe_mode=False.",
                instr.line, instr.raw,
            )

        # Check binary exists
        if not shutil.which(binary):
            raise FscfError(
                f"Binary '{binary}' not found in PATH.\n"
                f"  Install it first via [7] Install Manager.",
                instr.line, instr.raw,
            )

        console.print(
            f"\n[dim cyan]  [{instr.line}][/dim cyan] "
            f"[white]sys[/white]([cyan]{cmd_resolved}[/cyan])"
        )

        if self.dry_run:
            log_info(f"  [dry-run] Would run: {cmd_resolved}")
            self.output_log.append(f"[dry-run] {cmd_resolved}")
            return

        # Execute — stream output live
        output_lines: list[str] = []
        try:
            proc = subprocess.Popen(
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                errors="replace",
            )
            assert proc.stdout
            for line in proc.stdout:
                line = line.rstrip()
                if line:
                    console.print(f"  {line}")
                    output_lines.append(line)
            proc.wait()

            if proc.returncode != 0:
                log_warn(f"  Command exited with code {proc.returncode}")

        except Exception as exc:
            raise FscfError(f"Execution failed: {exc}", instr.line, instr.raw)

        self.output_log.extend(output_lines)

    def _exec_print(self, instr: Instruction) -> None:
        """Handle: print("message {var}")"""
        msg = _substitute(instr.cmd, self.variables, instr.line, instr.raw)
        console.print(
            f"\n[dim cyan]  [{instr.line}][/dim cyan] "
            f"[bright_green]{msg}[/bright_green]"
        )
        self.output_log.append(f"[print] {msg}")

    # ── UI helpers ────────────────────────────────────────────────────────────

    def _log_header(self) -> None:
        console.print(Panel(
            f"  [bold white]Mod:[/bold white]  [cyan]{self.mod_name}[/cyan]\n"
            f"  [bold white]Mode:[/bold white] "
            + ("[yellow]dry-run[/yellow]" if self.dry_run else "[green]live[/green]")
            + ("  [dim](safe mode)[/dim]" if self.safe_mode else "  [yellow](unsafe)[/yellow]"),
            title="[bold bright_green]// FSCF Runner[/bold bright_green]",
            border_style="bright_green",
            expand=False,
        ))


# ══════════════════════════════════════════════════════════════════════════════
# FILE VIEWER
# ══════════════════════════════════════════════════════════════════════════════

def view_fscf(path: Path) -> None:
    """
    Display a .fscf file with syntax highlighting and parsed annotation.
    Shows source code on the left and parsed meaning on the right.
    """
    source = path.read_text(encoding="utf-8", errors="replace")

    console.print()
    console.print(Panel(
        Syntax(
            source,
            "bash",              # closest lexer — highlights strings and #comments
            theme="monokai",
            line_numbers=True,
            word_wrap=True,
        ),
        title=f"[bold bright_green]// {path.name}[/bold bright_green]  [dim]{path}[/dim]",
        border_style="bright_green",
    ))

    # Parse and show the instruction breakdown table
    try:
        instructions = parse_fscf(source)
    except FscfError as e:
        log_err(f"Parse error: {e}")
        return

    real = [i for i in instructions if i.kind not in ("blank","comment")]
    if not real:
        log_warn("No executable instructions found in this mod.")
        return

    tbl = Table(
        title="[bold bright_green]// Instruction Breakdown[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    tbl.add_column("Line", width=5, justify="right", style="dim")
    tbl.add_column("Type",     width=10, style="bold cyan")
    tbl.add_column("Variable", width=14, style="yellow")
    tbl.add_column("Details",  width=58, style="dim")

    for i, instr in enumerate(real):
        if instr.kind == "assign":
            tbl.add_row(
                str(instr.line), "input",
                instr.var,
                f'Prompt: "{instr.prompt}"',
                style="on grey11" if i % 2 == 0 else "",
            )
        elif instr.kind == "sys":
            tbl.add_row(
                str(instr.line), "sys",
                "",
                instr.cmd[:57],
                style="on grey11" if i % 2 == 0 else "",
            )
        elif instr.kind == "print":
            tbl.add_row(
                str(instr.line), "print",
                "",
                f'"{instr.cmd[:55]}"',
                style="on grey11" if i % 2 == 0 else "",
            )

    console.print(tbl)
    console.print(
        f"  [dim]Total: {len(instructions)} lines  |  "
        f"{len(real)} executable instructions  |  "
        f"{len([i for i in instructions if i.kind == 'assign'])} inputs  |  "
        f"{len([i for i in instructions if i.kind == 'sys'])} sys() calls[/dim]"
    )


# ══════════════════════════════════════════════════════════════════════════════
# MOD LOADER
# ══════════════════════════════════════════════════════════════════════════════

MODIFS_DIR = Path(__file__).parent.parent / "Modifs"


def discover_mods() -> list[Path]:
    """Return all .fscf files in Modifs/, sorted by name."""
    if not MODIFS_DIR.exists():
        return []
    return sorted(MODIFS_DIR.glob("*.fscf"))


def _mod_metadata(path: Path) -> dict:
    """Extract metadata comments from the top of a .fscf file."""
    meta = {"name": path.stem, "desc": "", "author": "", "version": ""}
    try:
        for line in path.read_text(encoding="utf-8").splitlines()[:10]:
            line = line.strip()
            if not line.startswith("#"):
                break
            content = line[1:].strip()
            for key in ("name", "desc", "description", "author", "version"):
                if content.lower().startswith(key + ":"):
                    val = content[len(key)+1:].strip()
                    field = "desc" if key == "description" else key
                    meta[field] = val
    except OSError:
        pass
    return meta


# ══════════════════════════════════════════════════════════════════════════════
# INTERACTIVE MENU
# ══════════════════════════════════════════════════════════════════════════════

def run_mods_menu(cfg=None) -> None:
    """
    Interactive Mods browser — list .fscf files, view or run them.
    """
    from rich.panel import Panel as _P

    while True:
        mods = discover_mods()
        console.print()

        # Build the mod list table
        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",       width=4,  justify="right", style="dim")
        tbl.add_column("Mod",     width=24, style="bold cyan")
        tbl.add_column("Version", width=8,  style="dim")
        tbl.add_column("Author",  width=16, style="dim")
        tbl.add_column("Description", width=44, style="dim")

        for i, path in enumerate(mods, 1):
            meta = _mod_metadata(path)
            tbl.add_row(
                str(i), meta["name"][:23],
                meta["version"] or "—",
                meta["author"][:15] or "—",
                meta["desc"][:43] or path.name,
                style="on grey11" if i % 2 == 0 else "",
            )

        if not mods:
            tbl.add_row("","[dim]No mods found in Modifs/[/dim]","","","",style="on grey11")

        console.print(_P(
            tbl,
            title=f"[bold bright_green]// Mods[/bold bright_green]  [dim]{MODIFS_DIR}[/dim]",
            subtitle="[dim][0] Back  [Ctrl+C] Cancel[/dim]",
            border_style="bright_green", expand=False,
        ))

        if mods:
            console.print(
                "  Type [cyan]<#>[/cyan] to select a mod, "
                "[cyan][n][/cyan] to create new, "
                "[cyan][0][/cyan] to go back."
            )
        else:
            console.print(
                f"  [dim]Drop .fscf files into [cyan]{MODIFS_DIR}[/cyan] to add mods.[/dim]\n"
                f"  [cyan][n][/cyan] Create a new mod    [cyan][0][/cyan] Back"
            )

        try:
            cmd = input("\033[92m  mods> \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0","back"):
            break

        if cmd == "n":
            _create_mod_wizard()
            continue

        if cmd.isdigit():
            idx = int(cmd) - 1
            if 0 <= idx < len(mods):
                _mod_action_menu(mods[idx])
            else:
                log_warn(f"No mod #{cmd}")
        else:
            log_warn(f"Unknown command: {cmd}")


def _mod_action_menu(path: Path) -> None:
    """Show the View / Run submenu for a specific mod."""
    meta = _mod_metadata(path)
    console.print()
    console.print(Panel(
        f"  [bold white]{meta['name']}[/bold white]\n"
        + (f"  [dim]{meta['desc']}[/dim]\n" if meta["desc"] else "")
        + (f"  Author: [dim]{meta['author']}[/dim]  " if meta["author"] else "")
        + (f"Version: [dim]{meta['version']}[/dim]" if meta["version"] else "")
        + f"\n  File: [dim]{path.name}[/dim]\n\n"
        "  [1] View source\n"
        "  [2] Run  (live)\n"
        "  [3] Dry-run  (preview — no commands executed)\n"
        "  [0] Back",
        title=f"[bold bright_green]// {meta['name']}[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    try:
        choice = input("\033[92m  action> \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if choice == "0":
        return

    elif choice == "1":
        view_fscf(path)
        try:
            input("\n\033[2mPress ENTER to continue...\033[0m")
        except (EOFError, KeyboardInterrupt):
            pass

    elif choice in ("2", "3"):
        dry = (choice == "3")
        source = path.read_text(encoding="utf-8", errors="replace")
        try:
            instructions = parse_fscf(source)
        except FscfError as e:
            log_err(str(e))
            return

        runner = FscfRunner(
            mod_name=meta["name"],
            dry_run=dry,
            safe_mode=True,
        )
        success = runner.run(instructions)

        if success and runner.output_log:
            console.print()
            try:
                save = input(
                    "\033[92m[?] Save output to file? [y/N]: \033[0m"
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                save = "n"
            if save in ("y","yes"):
                _save_output(meta["name"], runner.output_log)

    else:
        log_warn(f"Unknown choice: {choice}")


def _save_output(mod_name: str, lines: list[str]) -> None:
    """Save mod output to a file in loot/mods/."""
    from utils.helpers import timestamp
    from pathlib import Path as _Path
    import os

    out_dir = _Path("./loot/mods")
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_name = re.sub(r"[^\w\-]", "_", mod_name)
    out_file = out_dir / f"{safe_name}_{timestamp()}.txt"
    out_file.write_text("\n".join(lines), encoding="utf-8")
    log_ok(f"Output saved: {out_file}")


def _create_mod_wizard() -> None:
    """Interactive wizard to create a new .fscf mod from scratch."""
    console.print(Panel(
        "  Create a new FSCF mod.\n\n"
        "  [bold]FSCF Syntax Reference:[/bold]\n"
        "  [cyan]var = input(\"Prompt: \")[/cyan]   — ask user, store in var\n"
        "  [cyan]sys(command {var})[/cyan]          — run command with substitution\n"
        "  [cyan]print(\"message {var}\")[/cyan]     — print text to screen\n"
        "  [dim]# comment[/dim]                     — ignored lines\n\n"
        "  Variable refs: [cyan]{varname}[/cyan] inside sys() and print()\n"
        "  Error if variable not defined at time of use.",
        title="[bold bright_green]// New Mod[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    try:
        name = input("\033[92m[?] Mod name (no spaces, e.g. my_scan): \033[0m").strip()
        if not name:
            return
        name = re.sub(r"[^\w\-]","_", name)

        desc    = input("\033[92m[?] Description: \033[0m").strip()
        author  = input("\033[92m[?] Author: \033[0m").strip()
        version = input("\033[92m[?] Version [1.0]: \033[0m").strip() or "1.0"
    except (EOFError, KeyboardInterrupt):
        return

    dest = MODIFS_DIR / f"{name}.fscf"
    if dest.exists():
        try:
            ow = input(f"\033[92m[?] {dest.name} already exists. Overwrite? [y/N]: \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return
        if ow not in ("y","yes"):
            return

    console.print(
        "\n[dim]Enter your .fscf script below.[/dim]\n"
        "[dim]Type [bold]DONE[/bold] on an empty line when finished.[/dim]\n"
        "[dim]Type [bold]HELP[/bold] for syntax examples.[/dim]\n"
    )

    script_lines: list[str] = []
    while True:
        try:
            line = input("\033[92m  > \033[0m")
        except (EOFError, KeyboardInterrupt):
            break
        if line.strip().upper() == "DONE":
            break
        if line.strip().upper() == "HELP":
            _print_fscf_help()
            continue
        script_lines.append(line)

    if not script_lines:
        log_warn("No script entered — mod not created.")
        return

    # Validate before saving
    source = "\n".join(script_lines)
    try:
        parse_fscf(source)
    except FscfError as e:
        log_err(f"Syntax error — mod not saved: {e}")
        return

    # Write file
    header_lines = [
        f"# name: {name}",
        f"# desc: {desc}",
        f"# author: {author}",
        f"# version: {version}",
        "#",
    ]
    full_source = "\n".join(header_lines + [""] + script_lines + [""])
    dest.write_text(full_source, encoding="utf-8")
    log_ok(f"Mod saved: {dest}")
    view_fscf(dest)


def _print_fscf_help() -> None:
    """Print a quick FSCF syntax reference."""
    console.print(Panel(
        "  [bold]FSCF Quick Reference[/bold]\n\n"
        "  [cyan]# This is a comment[/cyan]\n\n"
        "  [yellow]ip[/yellow] = input([green]\"Enter target IP: \"[/green])\n"
        "    → Prints the prompt, waits for user input, stores in 'ip'\n\n"
        "  sys([green]nmap -sV {ip}[/green])\n"
        "    → Runs: nmap -sV <value of ip>\n\n"
        "  sys([green]curl -sI https://{ip}[/green])\n"
        "    → Runs: curl -sI https://<value of ip>\n\n"
        "  print([green]\"Scanning {ip} now\"[/green])\n"
        "    → Prints: Scanning <value of ip> now\n\n"
        "  [dim]Rules:[/dim]\n"
        "  • {var} inside sys() or print() → replaced with stored value\n"
        "  • {undefined_var} → runtime error\n"
        "  • sys() only runs whitelisted security tool binaries\n"
        "  • All lines are executed top-to-bottom, no loops or conditionals yet",
        border_style="bright_green",
        expand=False,
    ))
