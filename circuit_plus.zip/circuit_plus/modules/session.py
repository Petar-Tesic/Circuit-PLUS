#!/usr/bin/env python3
"""
CIRCUIT+ — Session Manager: save, resume, and track scan state.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import timestamp
from config import Config, CONFIG_DIR, get_ext, set_ext

# ── Session storage location ──────────────────────────────────────────────────
SESSIONS_DIR = CONFIG_DIR / "sessions"


# ── Session data model (plain dict, JSON-serialisable) ────────────────────────

def _new_session(target: str, cfg: Config) -> dict[str, Any]:
    """Create a fresh session dict."""
    return {
        "id":           str(uuid.uuid4())[:8],
        "target":       target,
        "created_at":   datetime.now().isoformat(),
        "updated_at":   datetime.now().isoformat(),
        "status":       "active",          # active | paused | complete
        "phases_done":  [],                # list of completed phase names
        "phases_skip":  [],                # list of skipped phases
        "loot_dir":     "",                # filled in after first phase
        "notes":        "",
        "config_snap":  {                  # snapshot of relevant config at start
            "operator": cfg.operator_name,
            "threads":  cfg.threads,
            "timeout":  cfg.timeout,
        },
        "findings": {                      # key findings logged during scan
            "open_ports":   [],
            "subdomains":   [],
            "tech":         [],
            "vulns":        [],
            "cves":         [],
        },
    }


# ── Persistence ───────────────────────────────────────────────────────────────

def _session_path(session_id: str) -> Path:
    return SESSIONS_DIR / f"{session_id}.json"


def save_session(session: dict[str, Any]) -> Path:
    """Write session to disk. Returns path written."""
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    session["updated_at"] = datetime.now().isoformat()
    path = _session_path(session["id"])
    path.write_text(json.dumps(session, indent=2), encoding="utf-8")
    return path


def load_session(session_id: str) -> Optional[dict[str, Any]]:
    """Load a session by ID. Returns None if not found."""
    path = _session_path(session_id)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def list_sessions() -> list[dict[str, Any]]:
    """Return all sessions sorted by updated_at descending."""
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    sessions: list[dict[str, Any]] = []
    for f in sorted(SESSIONS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            sessions.append(json.loads(f.read_text(encoding="utf-8")))
        except Exception:
            pass
    return sessions


def delete_session(session_id: str) -> bool:
    """Delete a session file. Returns True if deleted."""
    path = _session_path(session_id)
    if path.exists():
        path.unlink()
        return True
    return False


# ── Session context manager ───────────────────────────────────────────────────

class SessionContext:
    """
    Context manager for an active scan session.

    Usage:
        with SessionContext(target, cfg) as sess:
            sess.phase_done("DNS Records")
            sess.add_finding("open_ports", [80, 443])
    """

    def __init__(self, target: str, cfg: Config,
                 resume_id: Optional[str] = None) -> None:
        self.cfg    = cfg
        self._dirty = False

        if resume_id:
            existing = load_session(resume_id)
            if existing:
                self.session = existing
                self.session["status"] = "active"
                log_ok(f"Resumed session {resume_id}: {existing['target']}")
            else:
                log_warn(f"Session {resume_id} not found — starting new.")
                self.session = _new_session(target, cfg)
        else:
            self.session = _new_session(target, cfg)

        # Pin current session ID in extended config
        set_ext("last_session_id", self.session["id"])

    def __enter__(self) -> "SessionContext":
        save_session(self.session)
        return self

    def __exit__(self, *_: Any) -> None:
        self.session["status"] = "complete"
        save_session(self.session)

    @property
    def id(self) -> str:
        return self.session["id"]

    @property
    def target(self) -> str:
        return self.session["target"]

    def phase_done(self, phase_name: str) -> None:
        """Mark a phase as completed and persist."""
        if phase_name not in self.session["phases_done"]:
            self.session["phases_done"].append(phase_name)
        save_session(self.session)

    def phase_skip(self, phase_name: str) -> None:
        """Mark a phase as skipped."""
        if phase_name not in self.session["phases_skip"]:
            self.session["phases_skip"].append(phase_name)
        save_session(self.session)

    def is_done(self, phase_name: str) -> bool:
        """Return True if this phase was already completed (for resume logic)."""
        return phase_name in self.session["phases_done"]

    def add_finding(self, category: str, items: list[Any]) -> None:
        """Append items to a findings category and persist."""
        if category in self.session["findings"]:
            existing = self.session["findings"][category]
            for item in items:
                if item not in existing:
                    existing.append(item)
        save_session(self.session)

    def set_loot(self, loot_dir: str) -> None:
        self.session["loot_dir"] = loot_dir
        save_session(self.session)

    def note(self, text: str) -> None:
        """Append a freeform note to the session."""
        self.session["notes"] += f"\n[{datetime.now().strftime('%H:%M')}] {text}"
        save_session(self.session)

    def pause(self) -> None:
        """Mark session as paused (can be resumed later)."""
        self.session["status"] = "paused"
        save_session(self.session)
        log_ok(f"Session {self.id} paused. Resume with: [session resume {self.id}]")


# ── Interactive session menu ──────────────────────────────────────────────────

def run_session_menu(cfg: Config) -> None:
    """Interactive session browser and manager."""
    while True:
        sessions = list_sessions()
        console.print()

        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",       width=4,  justify="right", style="dim")
        tbl.add_column("ID",      width=10, style="bold cyan")
        tbl.add_column("Target",  width=28, style="white")
        tbl.add_column("Status",  width=10)
        tbl.add_column("Updated", width=18, style="dim")
        tbl.add_column("Phases ✓",width=8,  justify="right", style="green")

        for i, s in enumerate(sessions[:30], 1):
            status_map = {
                "active":   "[bold green]active[/bold green]",
                "paused":   "[yellow]paused[/yellow]",
                "complete": "[dim]done[/dim]",
            }
            status = status_map.get(s.get("status",""), s.get("status",""))
            updated = s.get("updated_at","")[:16].replace("T"," ")
            phases  = str(len(s.get("phases_done",[])))
            tbl.add_row(
                str(i), s["id"], s["target"][:27], status, updated, phases,
                style="on grey11" if i % 2 == 0 else "",
            )

        if not sessions:
            tbl.add_row("", "", "[dim]No sessions yet[/dim]", "", "", "", style="on grey11")

        console.print(Panel(
            tbl,
            title="[bold bright_green]// Session Manager[/bold bright_green]",
            border_style="bright_green", expand=False,
        ))
        console.print(
            "  [cyan][v] <#>[/cyan] View session     "
            "[cyan][d] <#>[/cyan] Delete     "
            "[cyan][n] <target>[/cyan] New session\n"
            "  [cyan][r] <#>[/cyan] Resume session   "
            "[cyan][0][/cyan] Back"
        )

        try:
            cmd = input("\033[92m  session> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0", "back"):
            break

        parts = cmd.split(None, 1)
        verb  = parts[0].lower()
        arg   = parts[1].strip() if len(parts) > 1 else ""

        # Resolve # → session id
        def _resolve(a: str) -> Optional[dict[str, Any]]:
            if a.isdigit():
                idx = int(a) - 1
                return sessions[idx] if 0 <= idx < len(sessions) else None
            return load_session(a)

        if verb == "v" and arg:
            s = _resolve(arg)
            if s:
                _print_session_detail(s)
            else:
                log_err(f"Session not found: {arg}")

        elif verb == "d" and arg:
            s = _resolve(arg)
            if s and delete_session(s["id"]):
                log_ok(f"Deleted session {s['id']}")
            else:
                log_err(f"Session not found: {arg}")

        elif verb == "n" and arg:
            new_s = _new_session(arg, cfg)
            save_session(new_s)
            log_ok(f"New session created: {new_s['id']} → {arg}")

        elif verb == "r" and arg:
            s = _resolve(arg)
            if s:
                log_info(f"Resuming session {s['id']} for target: {s['target']}")
                # Launch mass scan with resume
                try:
                    from modules.massscan import run_massscan
                    run_massscan(s["target"], cfg)
                except Exception as e:
                    log_err(f"Resume failed: {e}")
            else:
                log_err(f"Session not found: {arg}")

        else:
            log_warn(f"Unknown command: {cmd}")


def _print_session_detail(s: dict[str, Any]) -> None:
    """Print full session details."""
    tbl = Table(
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        show_header=False, expand=False,
    )
    tbl.add_column("Field",   style="bold cyan", width=18)
    tbl.add_column("Value",   style="white",     width=52)

    tbl.add_row("ID",        s["id"])
    tbl.add_row("Target",    s["target"])
    tbl.add_row("Status",    s.get("status","?"))
    tbl.add_row("Created",   s.get("created_at","")[:19].replace("T"," "))
    tbl.add_row("Updated",   s.get("updated_at","")[:19].replace("T"," "))
    tbl.add_row("Loot",      s.get("loot_dir","(not set)"))
    tbl.add_row("Phases ✓",  ", ".join(s.get("phases_done",[])) or "none")
    tbl.add_row("Phases ⊘",  ", ".join(s.get("phases_skip",[])) or "none")
    tbl.add_row("Notes",     (s.get("notes","") or "—")[:100])

    findings = s.get("findings",{})
    for cat, items in findings.items():
        if items:
            tbl.add_row(
                f"  {cat}",
                ", ".join(str(x) for x in items[:8])
                + (f" …+{len(items)-8}" if len(items) > 8 else ""),
            )

    console.print(Panel(
        tbl,
        title=f"[bold bright_green]// Session {s['id']}[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))
