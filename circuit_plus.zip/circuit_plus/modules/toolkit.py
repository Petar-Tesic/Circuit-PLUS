#!/usr/bin/env python3
"""
CIRCUIT+ — Network Toolkit: ping, dig, whois, curl, SSL, GeoIP.
"""
from __future__ import annotations

import json
import re
import shutil
import socket
import subprocess
import sys
from pathlib import Path
from typing import Optional
from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import (
    is_valid_domain, is_valid_ip, is_valid_cidr,
    make_loot_dir, timestamp, normalize_url,
)
from config import Config, append_history

# ── helpers ───────────────────────────────────────────────────────────────────

def _run(cmd: list[str], timeout: int = 30) -> tuple[int, str, str]:
    """Run a command, return (rc, stdout, stderr)."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, errors="replace")
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "TIMEOUT"
    except FileNotFoundError:
        return 127, "", f"command not found: {cmd[0]}"
    except Exception as e:
        return 1, "", str(e)


def _stream(cmd: list[str], label: str, timeout: int = 60) -> str:
    """Stream a command live to console, return combined output."""
    console.print(f"\n[dim cyan]  $ {' '.join(cmd)}[/dim cyan]")
    if not shutil.which(cmd[0]):
        log_err(f"'{cmd[0]}' not found in PATH. Install it first.")
        return ""
    buf: list[str] = []
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,
                                text=True, errors="replace")
        assert proc.stdout
        for line in proc.stdout:
            line = line.rstrip()
            if line:
                console.print(f"  {line}")
                buf.append(line)
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        log_warn(f"{label}: timed out after {timeout}s")
    except KeyboardInterrupt:
        proc.kill()
        log_warn(f"{label}: interrupted")
    return "\n".join(buf)


def _save(loot: Path, filename: str, content: str) -> Path:
    """Write content to loot directory."""
    out = loot / filename
    out.write_text(content, encoding="utf-8")
    return out


def _need(binary: str) -> bool:
    """Return True if binary is in PATH, else print error."""
    if shutil.which(binary):
        return True
    log_err(f"'{binary}' not found in PATH.")
    console.print(f"  [dim]Install: sudo apt install {binary}  |  sudo pacman -S {binary}[/dim]")
    return False


def _resolve_target(raw: str) -> str:
    """Strip scheme/path from a URL to get the hostname."""
    raw = raw.strip()
    for scheme in ("https://", "http://"):
        if raw.startswith(scheme):
            raw = raw[len(scheme):]
    return raw.split("/")[0].split(":")[0]


# ══════════════════════════════════════════════════════════════════════════════
# TOOLS
# ══════════════════════════════════════════════════════════════════════════════

def tool_ping(host: str, cfg: Config, count: int = 6) -> None:
    """
    ICMP ping — test connectivity and measure RTT.

    Args:
        host:  Hostname or IP.
        count: Number of packets.
        cfg:   Config.
    """
    host = _resolve_target(host)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")
    log_info(f"Ping → {host}  ({count} packets)")
    out = _stream(["ping", "-c", str(count), host], "ping", timeout=30)
    # Parse summary
    for line in out.splitlines():
        if "packets transmitted" in line or "min/avg/max" in line:
            console.print(f"\n  [bold bright_green]{line}[/bold bright_green]")
    _save(loot, "ping.txt", out)
    append_history({"ts": timestamp(), "action": "ping", "target": host})


def tool_dig(host: str, cfg: Config, record_type: str = "ALL") -> None:
    """
    DNS lookup with dig — queries A, MX, TXT, CNAME, NS, AAAA, SOA.

    Args:
        host:        Domain to query.
        record_type: Record type, or ALL to run common types.
        cfg:         Config.
    """
    if not _need("dig"):
        return
    host = _resolve_target(host)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")
    all_out: list[str] = []

    types = ["A","AAAA","MX","TXT","NS","CNAME","SOA"] if record_type.upper() == "ALL" else [record_type.upper()]
    for rtype in types:
        log_info(f"dig {host} {rtype}")
        rc, stdout, _ = _run(["dig", "+noall", "+answer", host, rtype], timeout=15)
        lines = [l for l in stdout.splitlines() if l.strip() and not l.startswith(";")]
        if lines:
            console.print(f"\n  [bold cyan]{rtype}:[/bold cyan]")
            for line in lines:
                console.print(f"    [green]{line}[/green]")
            all_out.extend([f"=== {rtype} ==="] + lines)
        else:
            console.print(f"  [dim]{rtype}: (no records)[/dim]")
    _save(loot, "dig.txt", "\n".join(all_out))
    append_history({"ts": timestamp(), "action": "dig", "target": host})


def tool_nslookup(host: str, cfg: Config, nameserver: str = "") -> None:
    """
    nslookup — resolve hostname to IP(s), optionally via custom nameserver.

    Args:
        host:        Domain to resolve.
        nameserver:  Optional DNS server (e.g. 8.8.8.8).
        cfg:         Config.
    """
    if not _need("nslookup"):
        return
    host = _resolve_target(host)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")
    cmd  = ["nslookup", host]
    if nameserver:
        cmd.append(nameserver)
    log_info(f"nslookup {host}" + (f" @{nameserver}" if nameserver else ""))
    out = _stream(cmd, "nslookup", timeout=15)
    _save(loot, "nslookup.txt", out)
    append_history({"ts": timestamp(), "action": "nslookup", "target": host})


def tool_whois(target: str, cfg: Config) -> None:
    """
    whois — domain/IP registration and ownership information.

    Args:
        target: Domain name or IP address.
        cfg:    Config.
    """
    if not _need("whois"):
        return
    host = _resolve_target(target)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")
    log_info(f"whois {host}")
    out = _stream(["whois", host], "whois", timeout=30)
    # Highlight key fields
    interesting = ["Registrant","Registrar","Creation Date","Registry Expiry",
                   "Name Server","CIDR","Organization","Country","NetRange",
                   "Updated Date","Admin Email","Tech Email"]
    console.print("\n[bold bright_green]  Key Fields:[/bold bright_green]")
    for line in out.splitlines():
        for field in interesting:
            if field.lower() in line.lower() and ":" in line:
                key, _, val = line.partition(":")
                console.print(f"  [cyan]{key.strip():22}[/cyan] {val.strip()}")
                break
    _save(loot, "whois.txt", out)
    append_history({"ts": timestamp(), "action": "whois", "target": host})


def tool_traceroute(host: str, cfg: Config) -> None:
    """
    traceroute — map the network path to a host (uses traceroute or tracepath).

    Args:
        host: Hostname or IP.
        cfg:  Config.
    """
    host = _resolve_target(host)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")
    binary = "traceroute" if shutil.which("traceroute") else "tracepath"
    if not shutil.which(binary):
        log_err("Neither 'traceroute' nor 'tracepath' found.")
        console.print("  [dim]Install: sudo apt install traceroute[/dim]")
        return
    log_info(f"{binary} → {host}")
    out = _stream([binary, host], binary, timeout=60)
    _save(loot, "traceroute.txt", out)
    append_history({"ts": timestamp(), "action": "traceroute", "target": host})


def tool_curl_headers(url: str, cfg: Config, follow: bool = True) -> None:
    """
    HTTP header inspection — shows status code, server, tech stack hints.

    Args:
        url:    Target URL.
        follow: Follow redirects.
        cfg:    Config.
    """
    if not _need("curl"):
        return
    url = normalize_url(url)
    host = _resolve_target(url)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")

    cmd = ["curl", "-sI", "--max-time", "20",
           "-A", "Mozilla/5.0 (compatible; CIRCUIT+/1.02)"]
    if follow:
        cmd.append("-L")
    cmd.append(url)

    log_info(f"HTTP headers → {url}")
    rc, stdout, stderr = _run(cmd, timeout=25)

    if rc != 0:
        log_err(f"curl failed (exit {rc}): {stderr.strip()[:120]}")
        return

    # Pretty-print headers as a table
    tbl = Table(
        title=f"[bold bright_green]// HTTP Headers — {host}[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        show_header=True, header_style="bold bright_green", expand=False,
    )
    tbl.add_column("Header",  style="bold cyan", width=28)
    tbl.add_column("Value",   style="white",     width=60)

    # Highlight security-relevant headers
    sec_headers = {
        "strict-transport-security", "content-security-policy",
        "x-frame-options", "x-xss-protection", "x-content-type-options",
        "referrer-policy", "permissions-policy", "access-control-allow-origin",
        "server", "x-powered-by", "set-cookie",
    }

    all_headers: list[str] = []
    for i, line in enumerate(stdout.splitlines()):
        if not line.strip():
            continue
        # Status line
        if line.startswith("HTTP/"):
            status = line.strip()
            color  = "green" if "200" in status else "yellow" if "3" in status.split()[1] else "red"
            tbl.add_row("Status", f"[{color}]{status}[/{color}]")
            all_headers.append(line)
            continue
        if ":" in line:
            key, _, val = line.partition(":")
            key_lower = key.strip().lower()
            val_str = val.strip()
            row_style = "on grey11" if i % 2 == 0 else ""
            if key_lower in sec_headers:
                tbl.add_row(f"[bold yellow]{key.strip()}[/bold yellow]",
                            f"[yellow]{val_str}[/yellow]", style=row_style)
            else:
                tbl.add_row(key.strip(), val_str, style=row_style)
            all_headers.append(line)

    console.print(tbl)
    _save(loot, "http_headers.txt", "\n".join(all_headers))
    append_history({"ts": timestamp(), "action": "http_headers", "target": url})


def tool_curl_request(url: str, cfg: Config,
                      method: str = "GET", data: str = "",
                      extra_headers: list[str] | None = None) -> None:
    """
    Full HTTP request with curl — shows response body.

    Args:
        url:            Target URL.
        method:         HTTP method.
        data:           POST body.
        extra_headers:  List of "Key: Value" header strings.
        cfg:            Config.
    """
    if not _need("curl"):
        return
    url = normalize_url(url)
    host = _resolve_target(url)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")

    cmd = ["curl", "-s", "--max-time", "30", "-L",
           "-X", method.upper(),
           "-A", "Mozilla/5.0 (compatible; CIRCUIT+/1.02)",
           "-w", "\n---HTTP_STATUS: %{http_code}---\n"]
    if data:
        cmd.extend(["-d", data])
    for h in (extra_headers or []):
        cmd.extend(["-H", h])
    cmd.append(url)

    log_info(f"curl {method.upper()} {url}")
    rc, stdout, stderr = _run(cmd, timeout=35)

    if rc != 0:
        log_err(f"curl failed: {stderr.strip()[:120]}")
        return

    # Split body from status line
    body_lines = stdout.splitlines()
    for line in body_lines[-3:]:
        if "HTTP_STATUS:" in line:
            code = line.strip().replace("---","").replace("HTTP_STATUS:","").strip()
            color = "green" if code.startswith("2") else "yellow" if code.startswith("3") else "red"
            console.print(f"\n  [bold]HTTP Status:[/bold] [{color}]{code}[/{color}]")
    # Show first 100 lines of body
    console.print("\n[dim]Response body (first 80 lines):[/dim]")
    for line in body_lines[:80]:
        if "HTTP_STATUS:" not in line:
            console.print(f"  [dim]{line}[/dim]")
    if len(body_lines) > 80:
        console.print(f"  [dim]... +{len(body_lines)-80} more lines[/dim]")
    _save(loot, "curl_response.txt", stdout)
    append_history({"ts": timestamp(), "action": "curl_request",
                    "target": url, "method": method})


def tool_ip_lookup(target: str, cfg: Config) -> None:
    """
    IP / hostname lookup — resolves host to IPs and checks geolocation
    via the ip-api.com JSON API (no key required).

    Args:
        target: Domain name or IP.
        cfg:    Config.
    """
    host = _resolve_target(target)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")

    # Local DNS resolution
    log_info(f"Resolving {host} …")
    try:
        info = socket.getaddrinfo(host, None)
        ips = sorted(set(r[4][0] for r in info))
    except socket.gaierror as e:
        log_err(f"DNS resolution failed: {e}")
        ips = [host] if is_valid_ip(host) else []

    if ips:
        console.print(f"\n  [bold cyan]Resolved IPs:[/bold cyan]")
        for ip in ips:
            console.print(f"    [green]{ip}[/green]")

    # GeoIP lookup via ip-api.com
    query_ip = ips[0] if ips else host
    if not shutil.which("curl"):
        log_warn("curl not found — skipping geolocation lookup.")
        return

    log_info(f"GeoIP lookup: {query_ip}")
    rc, stdout, _ = _run(
        ["curl", "-s", "--max-time", "10",
         f"http://ip-api.com/json/{query_ip}?fields=status,country,regionName,"
         "city,isp,org,as,query,proxy,hosting,mobile"],
        timeout=15,
    )

    result: dict = {}
    if rc == 0:
        try:
            result = json.loads(stdout)
        except json.JSONDecodeError:
            pass

    if result and result.get("status") == "success":
        tbl = Table(
            title=f"[bold bright_green]// IP Info — {query_ip}[/bold bright_green]",
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=False, expand=False,
        )
        tbl.add_column("Field", style="bold cyan", width=18)
        tbl.add_column("Value", style="white",     width=40)
        fields = [
            ("IP",       result.get("query","")),
            ("Country",  result.get("country","")),
            ("Region",   result.get("regionName","")),
            ("City",     result.get("city","")),
            ("ISP",      result.get("isp","")),
            ("Org",      result.get("org","")),
            ("AS",       result.get("as","")),
            ("Proxy/VPN",str(result.get("proxy", False))),
            ("Hosting",  str(result.get("hosting", False))),
            ("Mobile",   str(result.get("mobile", False))),
        ]
        for i, (k, v) in enumerate(fields):
            if v:
                tbl.add_row(k, v, style="on grey11" if i % 2 == 0 else "")
        console.print(tbl)
        _save(loot, "ip_lookup.json", json.dumps(result, indent=2))
    else:
        log_warn(f"GeoIP lookup failed or returned no data for {query_ip}")

    append_history({"ts": timestamp(), "action": "ip_lookup", "target": target})


def tool_ssl_info(host: str, cfg: Config, port: int = 443) -> None:
    """
    SSL/TLS certificate info — expiry, issuer, SANs, protocol version.

    Args:
        host: Hostname.
        port: Port (default 443).
        cfg:  Config.
    """
    host = _resolve_target(host)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")

    if not _need("openssl"):
        return

    log_info(f"SSL/TLS info for {host}:{port}")

    cmd = ["openssl", "s_client", "-connect", f"{host}:{port}",
           "-servername", host, "-brief"]

    # Pipe /dev/null as stdin so openssl doesn't wait for input
    try:
        proc = subprocess.run(
            cmd, input="", capture_output=True, text=True, timeout=15
        )
        output = proc.stdout + proc.stderr
    except subprocess.TimeoutExpired:
        log_warn("SSL handshake timed out.")
        return
    except FileNotFoundError:
        log_err("openssl not found.")
        return

    # Also grab the certificate details
    cert_cmd = ["openssl", "s_client", "-connect", f"{host}:{port}",
                "-servername", host, "-showcerts"]
    rc2, cert_out, _ = _run(cert_cmd, timeout=15)

    # Parse with openssl x509
    tbl = Table(
        title=f"[bold bright_green]// SSL Certificate — {host}:{port}[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        show_header=False, expand=False,
    )
    tbl.add_column("Field",  style="bold cyan", width=22)
    tbl.add_column("Value",  style="white",     width=55)

    # Extract cert block and parse
    if "-----BEGIN CERTIFICATE-----" in cert_out:
        cert_block_start = cert_out.index("-----BEGIN CERTIFICATE-----")
        cert_block_end   = cert_out.index("-----END CERTIFICATE-----") + len("-----END CERTIFICATE-----")
        cert_pem = cert_out[cert_block_start:cert_block_end]

        rc3, x509_out, _ = _run(
            ["openssl", "x509", "-noout",
             "-subject", "-issuer", "-dates", "-ext", "subjectAltName"],
            timeout=10,
        )
        # Parse via pipe
        proc3 = subprocess.run(
            ["openssl", "x509", "-noout", "-subject", "-issuer",
             "-dates", "-ext", "subjectAltName"],
            input=cert_pem, capture_output=True, text=True, timeout=10,
        )
        x509_out = proc3.stdout

        for line in x509_out.splitlines():
            line = line.strip()
            if not line:
                continue
            if "=" in line and not line.startswith("DNS:"):
                key, _, val = line.partition("=")
                tbl.add_row(key.strip(), val.strip())
            else:
                tbl.add_row("SAN", line)

    # Grab protocol/cipher from s_client output
    for line in output.splitlines():
        if any(kw in line for kw in ("Protocol","Cipher","Verify")):
            console.print(f"  [dim]{line.strip()}[/dim]")

    console.print(tbl)
    _save(loot, "ssl_info.txt", output + "\n" + cert_out[:4000])
    append_history({"ts": timestamp(), "action": "ssl_info",
                    "target": f"{host}:{port}"})


def tool_arp_scan(target: str, cfg: Config) -> None:
    """
    ARP scan — discover live hosts on a local network segment.
    Requires arp-scan (sudo) or uses nmap ARP ping as fallback.

    Args:
        target: CIDR range or interface (e.g. 192.168.1.0/24 or eth0).
        cfg:    Config.
    """
    loot = make_loot_dir(cfg.loot_path, target.replace("/","_"), "toolkit")

    if shutil.which("arp-scan"):
        log_info(f"arp-scan {target}")
        out = _stream(["sudo", "arp-scan", target], "arp-scan", timeout=60)
    elif shutil.which("nmap"):
        log_info(f"nmap ARP ping {target} (arp-scan fallback)")
        out = _stream(["sudo", "nmap", "-sn", "-PR", target], "nmap-arp", timeout=120)
    else:
        log_err("Neither arp-scan nor nmap found.")
        console.print("  [dim]Install: sudo apt install arp-scan[/dim]")
        return

    _save(loot, "arp_scan.txt", out)
    append_history({"ts": timestamp(), "action": "arp_scan", "target": target})


def tool_port_check(host: str, cfg: Config, ports: str = "80,443,22,21,25,3306,8080") -> None:
    """
    Quick TCP port connectivity check using Python sockets (no tools needed).
    Faster than nmap for a simple open/closed check.

    Args:
        host:  Hostname or IP.
        ports: Comma-separated port list.
        cfg:   Config.
    """
    host = _resolve_target(host)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")
    port_list = []
    for p in ports.split(","):
        p = p.strip()
        if p.isdigit():
            port_list.append(int(p))

    if not port_list:
        log_err("No valid ports provided.")
        return

    log_info(f"Port check: {host}  [{', '.join(str(p) for p in port_list)}]")

    tbl = Table(
        title=f"[bold bright_green]// Port Check — {host}[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    tbl.add_column("Port",    width=8,  justify="center")
    tbl.add_column("Status",  width=12)
    tbl.add_column("Service", style="dim", width=20)

    SERVICE_MAP = {
        21: "FTP",   22: "SSH",    23: "Telnet",   25: "SMTP",
        53: "DNS",   80: "HTTP",   110: "POP3",    143: "IMAP",
        443: "HTTPS", 445: "SMB",  3306: "MySQL",  3389: "RDP",
        5432: "PostgreSQL", 6379: "Redis", 8080: "HTTP-Alt",
        8443: "HTTPS-Alt", 27017: "MongoDB",
    }

    results: list[str] = []
    for i, port in enumerate(port_list):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            rc = sock.connect_ex((host, port))
            sock.close()
            open_ = rc == 0
        except Exception:
            open_ = False

        service = SERVICE_MAP.get(port, "")
        status  = "[bold green]OPEN[/bold green]" if open_ else "[dim red]CLOSED[/dim red]"
        tbl.add_row(str(port), status, service, style="on grey11" if i % 2 == 0 else "")
        results.append(f"{port}\t{'OPEN' if open_ else 'CLOSED'}\t{service}")

    console.print(tbl)
    _save(loot, "port_check.txt", "\n".join(results))
    append_history({"ts": timestamp(), "action": "port_check",
                    "target": host, "ports": ports})


def tool_http_tech(url: str, cfg: Config) -> None:
    """
    Quick HTTP tech-stack fingerprint using response headers + body keywords.
    No external tools needed beyond curl.

    Args:
        url: Target URL.
        cfg: Config.
    """
    if not _need("curl"):
        return
    url = normalize_url(url)
    host = _resolve_target(url)
    loot = make_loot_dir(cfg.loot_path, host, "toolkit")

    log_info(f"Tech fingerprint: {url}")
    rc, stdout, _ = _run(
        ["curl", "-sIL", "--max-time", "15", "-A",
         "Mozilla/5.0 (compatible; CIRCUIT+/1.02)", url],
        timeout=20,
    )
    rc2, body, _ = _run(
        ["curl", "-sL", "--max-time", "15", "-A",
         "Mozilla/5.0 (compatible; CIRCUIT+/1.02)", url],
        timeout=20,
    )

    combined = (stdout + body).lower()
    tech: dict[str, str] = {}

    # Header-based detection
    header_map: list[tuple[str, str, str]] = [
        ("server",          "Apache",       "apache"),
        ("server",          "nginx",        "nginx"),
        ("server",          "IIS",          "iis"),
        ("server",          "LiteSpeed",    "litespeed"),
        ("server",          "Caddy",        "caddy"),
        ("x-powered-by",    "PHP",          "php"),
        ("x-powered-by",    "ASP.NET",      "asp.net"),
        ("x-powered-by",    "Express",      "express"),
        ("x-generator",     "WordPress",    "wordpress"),
        ("x-drupal-cache",  "Drupal",       "drupal"),
        ("set-cookie",      "PHPSESSID",    "php"),
        ("set-cookie",      "JSESSIONID",   "java"),
        ("set-cookie",      "ASP.NET_SessionId", "asp.net"),
    ]
    for header, tech_name, key in header_map:
        if header in combined and tech_name.lower() in combined:
            tech[key] = tech_name

    # Body keyword detection
    body_map: list[tuple[str, str]] = [
        ("wp-content",   "WordPress"),
        ("wp-json",      "WordPress"),
        ("drupal",       "Drupal"),
        ("joomla",       "Joomla"),
        ("laravel",      "Laravel"),
        ("django",       "Django"),
        ("react",        "React"),
        ("angular",      "Angular"),
        ("vue.js",       "Vue.js"),
        ("jquery",       "jQuery"),
        ("bootstrap",    "Bootstrap"),
        ("font-awesome", "Font Awesome"),
        ("cloudflare",   "Cloudflare"),
        ("recaptcha",    "Google reCAPTCHA"),
        ("gtag",         "Google Analytics"),
        ("shopify",      "Shopify"),
        ("wix",          "Wix"),
    ]
    for keyword, tech_name in body_map:
        if keyword in combined:
            tech[tech_name.lower().replace(" ","-")] = tech_name

    if tech:
        tbl = Table(
            title=f"[bold bright_green]// Tech Stack — {host}[/bold bright_green]",
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=False, expand=False,
        )
        tbl.add_column("Tech", style="bold cyan", width=30)
        for i, name in enumerate(sorted(set(tech.values()))):
            tbl.add_row(name, style="on grey11" if i % 2 == 0 else "")
        console.print(tbl)
    else:
        log_warn("No known tech stack signatures detected in headers or body.")

    _save(loot, "tech_fingerprint.txt",
          "\n".join(sorted(set(tech.values()))))
    append_history({"ts": timestamp(), "action": "tech_fingerprint", "target": url})


# ══════════════════════════════════════════════════════════════════════════════
# INTERACTIVE MENU
# ══════════════════════════════════════════════════════════════════════════════

def run_toolkit_menu(cfg: Config) -> None:
    """
    Interactive loop for the Network Toolkit submenu.
    """
    while True:
        try:
            console.print()
            _show_toolkit_menu()
            try:
                choice = input("\n\033[92mtoolkit> \033[0m").strip()
            except (EOFError, KeyboardInterrupt):
                break

            if choice in ("0", "back"):
                break

            elif choice == "1":
                # Ping
                _divider()
                host = _ask("Target (host / IP)")
                if host:
                    try:
                        cnt = int(input("\033[92m[?] Packet count [6]: \033[0m").strip() or "6")
                    except (ValueError, EOFError, KeyboardInterrupt):
                        cnt = 6
                    tool_ping(host, cfg, count=cnt)

            elif choice == "2":
                # Dig
                _divider()
                host = _ask("Domain")
                if host:
                    try:
                        rtype = input("\033[92m[?] Record type [ALL / A / MX / TXT / NS]: \033[0m").strip().upper() or "ALL"
                    except (EOFError, KeyboardInterrupt):
                        rtype = "ALL"
                    tool_dig(host, cfg, record_type=rtype)

            elif choice == "3":
                # NSLookup
                _divider()
                host = _ask("Domain or IP")
                if host:
                    try:
                        ns = input("\033[92m[?] Nameserver (empty = default): \033[0m").strip()
                    except (EOFError, KeyboardInterrupt):
                        ns = ""
                    tool_nslookup(host, cfg, nameserver=ns)

            elif choice == "4":
                # Whois
                _divider()
                target = _ask("Domain or IP")
                if target:
                    tool_whois(target, cfg)

            elif choice == "5":
                # Traceroute
                _divider()
                host = _ask("Target (host / IP)")
                if host:
                    tool_traceroute(host, cfg)

            elif choice == "6":
                # HTTP Headers
                _divider()
                url = _ask("Target URL")
                if url:
                    tool_curl_headers(url, cfg)

            elif choice == "7":
                # Curl Request
                _divider()
                url = _ask("Target URL")
                if url:
                    try:
                        method = input("\033[92m[?] Method [GET]: \033[0m").strip().upper() or "GET"
                        data   = ""
                        if method in ("POST","PUT","PATCH"):
                            data = input("\033[92m[?] POST body (leave empty to skip): \033[0m").strip()
                        hdr_raw = input("\033[92m[?] Extra headers (e.g. Authorization: Bearer xxx), empty=none: \033[0m").strip()
                        extra_headers = [h.strip() for h in hdr_raw.split(",") if ":" in h] if hdr_raw else []
                    except (EOFError, KeyboardInterrupt):
                        method, data, extra_headers = "GET", "", []
                    tool_curl_request(url, cfg, method=method, data=data, extra_headers=extra_headers)

            elif choice == "8":
                # IP Lookup / GeoIP
                _divider()
                target = _ask("Domain or IP")
                if target:
                    tool_ip_lookup(target, cfg)

            elif choice == "9":
                # SSL Info
                _divider()
                host = _ask("Domain (e.g. example.com)")
                if host:
                    try:
                        port = int(input("\033[92m[?] Port [443]: \033[0m").strip() or "443")
                    except (ValueError, EOFError, KeyboardInterrupt):
                        port = 443
                    tool_ssl_info(host, cfg, port=port)

            elif choice == "10":
                # Quick port check
                _divider()
                host = _ask("Target (host / IP)")
                if host:
                    try:
                        ports = input("\033[92m[?] Ports [80,443,22,21,8080,3306]: \033[0m").strip() or "80,443,22,21,8080,3306"
                    except (EOFError, KeyboardInterrupt):
                        ports = "80,443,22,21,8080,3306"
                    tool_port_check(host, cfg, ports=ports)

            elif choice == "11":
                # ARP scan
                _divider()
                console.print("[yellow][~] Requires sudo. Use responsibly on authorized networks.[/yellow]")
                target = _ask("CIDR range or interface (e.g. 192.168.1.0/24)")
                if target:
                    tool_arp_scan(target, cfg)

            elif choice == "12":
                # HTTP tech fingerprint
                _divider()
                url = _ask("Target URL")
                if url:
                    tool_http_tech(url, cfg)

            elif choice == "99":
                break

            else:
                log_warn(f"Unknown option: '{choice}'")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break


def _show_toolkit_menu() -> None:
    tbl = Table(
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        show_header=True, header_style="bold bright_green",
        expand=False, min_width=62,
    )
    tbl.add_column("  Key",  style="bold cyan",  justify="center", width=6)
    tbl.add_column("Tool",   style="bold white",  width=20)
    tbl.add_column("Description", style="dim",   width=42)

    rows = [
        ("1",  "Ping",             "ICMP connectivity + RTT"),
        ("2",  "Dig",              "DNS records (A/MX/TXT/NS/SOA/…)"),
        ("3",  "NSLookup",         "Resolve hostname ↔ IP"),
        ("4",  "Whois",            "Domain / IP registration info"),
        ("5",  "Traceroute",       "Network path to host"),
        ("6",  "HTTP Headers",     "Inspect response headers"),
        ("7",  "Curl Request",     "GET / POST with custom headers"),
        ("8",  "IP / GeoIP Lookup","Resolve + geolocation (ip-api.com)"),
        ("9",  "SSL Info",         "Certificate, expiry, issuer, SANs"),
        ("10", "Port Check",       "Fast TCP open/closed check (no tools)"),
        ("11", "ARP Scan",         "Discover live hosts on local network"),
        ("12", "Tech Fingerprint", "Detect CMS, framework, CDN, JS libs"),
        ("0",  "← Back",          "Return to main menu"),
    ]
    for i, (key, tool, desc) in enumerate(rows):
        tbl.add_row(f"[{key}]", tool, desc, style="on grey11" if i % 2 == 0 else "")

    console.print(Panel(
        tbl,
        title="[bold bright_green]// Network Toolkit[/bold bright_green]",
        subtitle="[dim][0] Back  [99] Main Menu  [Ctrl+C] Cancel[/dim]",
        border_style="bright_green",
    ))


def _ask(prompt: str) -> str:
    """Small input helper that returns "" on cancel."""
    try:
        v = input(f"\033[92m[?] {prompt}: \033[0m").strip()
        return v
    except (EOFError, KeyboardInterrupt):
        return ""


def _divider() -> None:
    console.print("[bright_green]" + "─" * 62 + "[/bright_green]")
