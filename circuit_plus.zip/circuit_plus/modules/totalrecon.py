#!/usr/bin/env python3
"""
CIRCUIT+ — Total Recon  (v1.1)
The most comprehensive recon pipeline CIRCUIT+ can run.
Chains 16 phases against a single authorized domain target.

⚠️  AUTHORIZED USE ONLY — Only run against targets you own or have
    explicit written permission to test.

Phases:
  0.  Target resolution & scope check
  1.  Passive subdomain enumeration      (subfinder)
  2.  DNS brute-force                    (dnsx + wordlist)
  3.  Subdomain permutations             (alterx)
  4.  Active DNS resolution              (dnsx on all found subs)
  5.  Live host probing                  (httpx — tech, status, titles)
  6.  Full port scan                     (rustscan → nmap -sV -sC)
  7.  Web crawling                       (katana JS + gau URL harvest)
  8.  Content discovery                  (ffuf quick on all live hosts)
  9.  Vulnerability scan                 (nuclei critical+high+medium)
  10. Cloud storage enum                 (S3 / GCS / Azure)
  11. SSL/TLS audit                      (openssl — cert, SANs, expiry)
  12. Tech fingerprint + CVE correlation (curl + NVD API)
  13. Whois + GeoIP                      (whois + ip-api.com)
  14. Screenshots                        (gowitness gallery)
  15. Backup & sensitive file hunting    (gobuster dir with backup exts)
  16. Full report generation             (JSON + HTML + TXT)
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import (
    is_valid_domain, is_valid_ip, normalize_url,
    make_loot_dir, timestamp, read_lines, write_lines,
    count_lines,
)
from config import Config, append_history
from utils.notify import notify_scan_complete

# ══════════════════════════════════════════════════════════════════════════════
# PHASE TRACKING
# ══════════════════════════════════════════════════════════════════════════════

class TotalReconState:
    """Tracks progress, findings, and loot paths across all 16 phases."""

    TOTAL_PHASES = 16

    def __init__(self, domain: str, loot_root: Path) -> None:
        self.domain      = domain
        self.loot_root   = loot_root
        self.started_at  = datetime.now()
        self.findings: dict[str, Any] = {
            "subdomains":    [],
            "live_hosts":    [],
            "open_ports":    {},   # {host: [port_list]}
            "urls":          [],
            "vulns":         [],
            "cloud_buckets": [],
            "tech":          [],
            "cves":          [],
            "screenshots":   [],
        }
        self.phase_log: list[dict] = []
        self.skipped:   list[str]  = []
        self.failed:    list[str]  = []

        # Key file paths (set as phases complete)
        self.subs_file:         Optional[Path] = None
        self.live_hosts_file:   Optional[Path] = None
        self.live_hosts_txt:    Optional[Path] = None
        self.ports_xml:         Optional[Path] = None
        self.urls_file:         Optional[Path] = None
        self.vuln_file:         Optional[Path] = None
        self.screenshots_dir:   Optional[Path] = None

    def log_phase(self, name: str, ok: bool, skipped: bool = False,
                  summary: str = "") -> None:
        self.phase_log.append({
            "name":    name,
            "ok":      ok,
            "skipped": skipped,
            "summary": summary,
            "time":    datetime.now().isoformat(),
        })
        if skipped:
            self.skipped.append(name)
        elif not ok:
            self.failed.append(name)

    def add_findings(self, key: str, items: list) -> None:
        if key in self.findings:
            existing = set(str(x) for x in self.findings[key])
            for item in items:
                if str(item) not in existing:
                    self.findings[key].append(item)
                    existing.add(str(item))

    def elapsed(self) -> str:
        secs = int((datetime.now() - self.started_at).total_seconds())
        return f"{secs//60}m {secs%60}s"

    def to_dict(self) -> dict:
        return {
            "domain":     self.domain,
            "loot":       str(self.loot_root),
            "started":    self.started_at.isoformat(),
            "finished":   datetime.now().isoformat(),
            "elapsed":    self.elapsed(),
            "findings":   self.findings,
            "phases":     self.phase_log,
            "skipped":    self.skipped,
            "failed":     self.failed,
        }


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _run(cmd: list[str], cwd: Optional[Path] = None,
         timeout: int = 300, env: Optional[dict] = None) -> tuple[int, str, str]:
    """Run a command, return (rc, stdout, stderr)."""
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, errors="replace",
            cwd=str(cwd) if cwd else None,
            env=env,
        )
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "TIMEOUT"
    except FileNotFoundError:
        return 127, "", f"not found: {cmd[0]}"
    except Exception as e:
        return 1, "", str(e)


def _stream(cmd: list[str], cwd: Optional[Path] = None,
            timeout: int = 600) -> str:
    """Stream a command live, return combined output."""
    console.print(f"  [dim cyan]$ {' '.join(str(c) for c in cmd)}[/dim cyan]")
    buf: list[str] = []
    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, errors="replace",
            cwd=str(cwd) if cwd else None,
        )
        assert proc.stdout
        for line in proc.stdout:
            line = line.rstrip()
            if line:
                console.print(f"  {line}")
                buf.append(line)
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        log_warn("Command timed out.")
    except KeyboardInterrupt:
        proc.kill()
        raise
    return "\n".join(buf)


def _has(binary: str) -> bool:
    return bool(shutil.which(binary))


def _phase_banner(n: int, total: int, title: str, desc: str = "") -> None:
    console.print()
    console.print(Rule(
        f"[bold bright_green]Phase {n}/{total} — {title}[/bold bright_green]",
        style="bright_green",
    ))
    if desc:
        console.print(f"  [dim]{desc}[/dim]")


def _dns_wordlist(cfg: Config) -> Optional[str]:
    """Find best available DNS wordlist."""
    wl_root = Path(cfg.wordlist_path)
    candidates = [
        "SecLists/Discovery/DNS/subdomains-top1million-5000.txt",
        "SecLists/Discovery/DNS/subdomains-top1million-20000.txt",
        "SecLists/Discovery/DNS/namelist.txt",
        "dns-names.txt",
    ]
    for rel in candidates:
        p = wl_root / rel
        if p.exists() and p.stat().st_size > 100:
            return str(p)
    return None


def _web_wordlist_quick(cfg: Config) -> Optional[str]:
    wl_root = Path(cfg.wordlist_path)
    for rel in ["SecLists/Discovery/Web-Content/small.txt",
                "SecLists/Discovery/Web-Content/common.txt", "small.txt"]:
        p = wl_root / rel
        if p.exists() and p.stat().st_size > 100:
            return str(p)
    return None


def _backup_wordlist(cfg: Config) -> Optional[str]:
    wl_root = Path(cfg.wordlist_path)
    for rel in ["SecLists/Discovery/Web-Content/raft-medium-files.txt",
                "SecLists/Discovery/Web-Content/common.txt"]:
        p = wl_root / rel
        if p.exists() and p.stat().st_size > 100:
            return str(p)
    return None


# ══════════════════════════════════════════════════════════════════════════════
# PHASE IMPLEMENTATIONS
# ══════════════════════════════════════════════════════════════════════════════

def _p1_subfinder(state: TotalReconState, cfg: Config) -> None:
    """Phase 1: Passive subdomain enumeration."""
    if not _has("subfinder"):
        state.log_phase("Passive Subdomain Enum", False, skipped=True,
                        summary="subfinder not installed")
        _skip("subfinder not found"); return

    out_file = state.loot_root / "phase1_subfinder.txt"
    rc, stdout, _ = _run(
        ["subfinder", "-d", state.domain, "-silent", "-o", str(out_file)],
        timeout=120,
    )
    subs = read_lines(out_file) if out_file.exists() else []
    # Also capture stdout
    if stdout.strip():
        for s in stdout.strip().splitlines():
            if s.strip() and s.strip() not in subs:
                subs.append(s.strip())
    write_lines(out_file, subs)
    state.subs_file = out_file
    state.add_findings("subdomains", subs)
    _ok(f"subfinder: {len(subs)} subdomains")
    state.log_phase("Passive Subdomain Enum", True, summary=f"{len(subs)} found")


def _p2_dns_brute(state: TotalReconState, cfg: Config) -> None:
    """Phase 2: DNS brute-force."""
    wl = _dns_wordlist(cfg)
    if not wl:
        state.log_phase("DNS Brute-Force", False, skipped=True,
                        summary="no DNS wordlist found"); _skip("No DNS wordlist"); return
    if not _has("dnsx"):
        state.log_phase("DNS Brute-Force", False, skipped=True,
                        summary="dnsx not installed"); _skip("dnsx not found"); return

    out_file = state.loot_root / "phase2_dnsbrute.txt"
    # Generate FQDN list
    fqdn_file = state.loot_root / "phase2_fqdn.txt"
    fqdns = [f"{w}.{state.domain}" for w in read_lines(Path(wl))[:5000]]
    write_lines(fqdn_file, fqdns)

    rc, stdout, _ = _run(
        ["dnsx", "-l", str(fqdn_file), "-o", str(out_file), "-silent", "-a"],
        timeout=180,
    )
    subs = read_lines(out_file)
    state.add_findings("subdomains", subs)
    _ok(f"DNS brute: {len(subs)} more subdomains")
    state.log_phase("DNS Brute-Force", True, summary=f"{len(subs)} found")


def _p3_alterx(state: TotalReconState, cfg: Config) -> None:
    """Phase 3: Subdomain permutations."""
    if not _has("alterx") or not state.subs_file or not state.subs_file.exists():
        state.log_phase("Subdomain Permutations", False, skipped=True,
                        summary="alterx not installed or no subs"); _skip("alterx/subs unavailable"); return

    out_file = state.loot_root / "phase3_alterx.txt"
    rc, stdout, _ = _run(
        ["alterx", "-l", str(state.subs_file), "-o", str(out_file), "-silent"],
        timeout=60,
    )
    perms = read_lines(out_file)
    _ok(f"alterx: {len(perms)} permutations generated")

    # Resolve permutations
    if perms and _has("dnsx"):
        resolved_file = state.loot_root / "phase3_alterx_resolved.txt"
        rc2, _, _ = _run(
            ["dnsx", "-l", str(out_file), "-o", str(resolved_file), "-silent", "-a"],
            timeout=120,
        )
        resolved = read_lines(resolved_file)
        state.add_findings("subdomains", resolved)
        _ok(f"alterx resolved: {len(resolved)} live permutation subdomains")
    state.log_phase("Subdomain Permutations", True, summary=f"{len(perms)} perms")


def _p4_dns_resolve(state: TotalReconState, cfg: Config) -> None:
    """Phase 4: Resolve ALL found subdomains."""
    if not _has("dnsx"):
        state.log_phase("DNS Resolution", False, skipped=True, summary="dnsx not installed")
        _skip("dnsx not found"); return

    all_subs = state.findings["subdomains"]
    if not all_subs:
        state.log_phase("DNS Resolution", False, skipped=True, summary="no subs to resolve")
        _skip("No subdomains to resolve"); return

    combined = state.loot_root / "phase4_all_subs.txt"
    write_lines(combined, all_subs)
    resolved_file = state.loot_root / "phase4_resolved.txt"

    rc, _, _ = _run(
        ["dnsx", "-l", str(combined), "-o", str(resolved_file), "-silent", "-a"],
        timeout=300,
    )
    resolved = read_lines(resolved_file)
    state.subs_file = resolved_file
    _ok(f"DNS resolution: {len(resolved)} live subdomains from {len(all_subs)} total")
    state.log_phase("DNS Resolution", True, summary=f"{len(resolved)}/{len(all_subs)} resolved")


def _p5_httpx(state: TotalReconState, cfg: Config) -> None:
    """Phase 5: HTTP probing."""
    if not _has("httpx"):
        state.log_phase("HTTP Probing", False, skipped=True, summary="httpx not installed")
        _skip("httpx not found"); return
    if not state.subs_file or count_lines(state.subs_file) == 0:
        state.log_phase("HTTP Probing", False, skipped=True, summary="no hosts to probe")
        _skip("No hosts to probe"); return

    out_json = state.loot_root / "phase5_httpx.json"
    out_txt  = state.loot_root / "phase5_live_urls.txt"

    rc, stdout, _ = _run([
        "httpx", "-l", str(state.subs_file),
        "-status-code", "-tech-detect", "-title",
        "-json", "-o", str(out_json),
        "-silent", "-threads", "50", "-timeout", "10",
    ], timeout=300)

    # Parse JSON output
    live_urls: list[str] = []
    if out_json.exists():
        for line in out_json.read_text(errors="ignore").splitlines():
            try:
                d = json.loads(line)
                url = d.get("url","")
                if url:
                    live_urls.append(url)
            except Exception:
                pass
    write_lines(out_txt, live_urls)
    state.live_hosts_file = out_json
    state.live_hosts_txt  = out_txt
    state.add_findings("live_hosts", live_urls)
    _ok(f"httpx: {len(live_urls)} live web hosts")
    state.log_phase("HTTP Probing", True, summary=f"{len(live_urls)} live")


def _p6_ports(state: TotalReconState, cfg: Config) -> None:
    """Phase 6: Full port scan."""
    if not _has("nmap"):
        state.log_phase("Port Scan", False, skipped=True, summary="nmap not installed")
        _skip("nmap not found"); return

    out_xml  = state.loot_root / "phase6_nmap"
    cmd: list[str]

    if _has("rustscan"):
        _info("Running RustScan → nmap...")
        rc, rs_out, _ = _run([
            "rustscan", "-a", state.domain,
            "--ulimit", "5000", "--", "-sV", "-sC", "--open",
        ], timeout=300)
        # Extract open ports
        import re
        ports = re.findall(r':(\d+)', rs_out)
        ports = sorted(set(int(p) for p in ports if p.isdigit()))
        if ports:
            port_str = ",".join(str(p) for p in ports[:200])
            cmd = ["nmap", "-sV", "-sC", "-T4", "--open",
                   "-p", port_str, "-oA", str(out_xml), state.domain]
        else:
            cmd = ["nmap", "-sV", "-sC", "-T4", "--open", "--top-ports", "1000",
                   "-oA", str(out_xml), state.domain]
    else:
        _info("Running nmap (all common ports)...")
        cmd = ["nmap", "-sV", "-sC", "-T4", "--open", "--top-ports", "1000",
               "-oA", str(out_xml), state.domain]

    rc, _, _ = _run(cmd, timeout=600)
    nmap_out = Path(str(out_xml) + ".xml")
    state.ports_xml = nmap_out

    # Parse for summary
    if nmap_out.exists():
        import re
        xml_src = nmap_out.read_text(errors="ignore")
        open_p  = re.findall(r'portid="(\d+)".*?state="open"', xml_src)
        state.add_findings("open_ports", {state.domain: open_p})
        _ok(f"Port scan: {len(open_p)} open ports")
        state.log_phase("Port Scan", True, summary=f"{len(open_p)} open ports")
    else:
        state.log_phase("Port Scan", False, summary="nmap produced no XML")


def _p7_crawl(state: TotalReconState, cfg: Config) -> None:
    """Phase 7: Web crawling."""
    if not state.live_hosts_txt or count_lines(state.live_hosts_txt) == 0:
        state.log_phase("Web Crawling", False, skipped=True, summary="no live hosts")
        _skip("No live hosts to crawl"); return

    all_urls: list[str] = []
    target_url = normalize_url(state.domain)

    if _has("katana"):
        _info("Running katana JS crawler...")
        out_k = state.loot_root / "phase7_katana.txt"
        rc, stdout, _ = _run([
            "katana", "-u", target_url, "-jc", "-d", "3",
            "-silent", "-o", str(out_k), "-timeout", "10",
        ], timeout=180)
        k_urls = read_lines(out_k)
        all_urls.extend(k_urls)
        _ok(f"katana: {len(k_urls)} URLs")

    if _has("gau"):
        _info("Running gau URL harvester...")
        out_g = state.loot_root / "phase7_gau.txt"
        rc, stdout, _ = _run(["gau", "--o", str(out_g), state.domain], timeout=120)
        g_urls = read_lines(out_g)
        all_urls.extend(g_urls)
        _ok(f"gau: {len(g_urls)} URLs from archives")

    if _has("waybackurls"):
        _info("Running waybackurls...")
        rc, stdout, _ = _run(["waybackurls", state.domain], timeout=60)
        wb = [l.strip() for l in stdout.splitlines() if l.strip()]
        all_urls.extend(wb)
        _ok(f"waybackurls: {len(wb)} historical URLs")

    out_all = state.loot_root / "phase7_all_urls.txt"
    write_lines(out_all, all_urls)
    state.urls_file = out_all
    state.add_findings("urls", all_urls[:500])  # cap for JSON
    _ok(f"Total URLs collected: {len(all_urls)}")
    state.log_phase("Web Crawling", True, summary=f"{len(all_urls)} URLs")


def _p8_content_discovery(state: TotalReconState, cfg: Config) -> None:
    """Phase 8: Content discovery with ffuf on all live hosts."""
    if not _has("ffuf"):
        state.log_phase("Content Discovery", False, skipped=True, summary="ffuf not installed")
        _skip("ffuf not found"); return

    wl = _web_wordlist_quick(cfg)
    if not wl:
        state.log_phase("Content Discovery", False, skipped=True, summary="no wordlist")
        _skip("No wordlist for content discovery"); return

    hosts = state.findings["live_hosts"][:10]  # cap at 10
    if not hosts:
        state.log_phase("Content Discovery", False, skipped=True, summary="no live hosts")
        _skip("No live hosts for content discovery"); return

    total_found = 0
    for host_url in hosts:
        host_name = host_url.replace("https://","").replace("http://","").split("/")[0]
        out_json  = state.loot_root / f"phase8_ffuf_{host_name.replace('.','_')}.json"
        _info(f"ffuf → {host_url}/FUZZ")
        rc, _, _ = _run([
            "ffuf", "-u", f"{host_url}/FUZZ",
            "-w", wl,
            "-mc", "200,201,301,302,401,403,405",
            "-t", "30", "-timeout", "10",
            "-of", "json", "-o", str(out_json),
            "-s",
        ], timeout=120)
        if out_json.exists():
            try:
                data = json.loads(out_json.read_text(errors="ignore"))
                found = len(data.get("results",[]))
                total_found += found
            except Exception:
                pass

    _ok(f"Content discovery: {total_found} paths found across {len(hosts)} hosts")
    state.log_phase("Content Discovery", True,
                    summary=f"{total_found} paths, {len(hosts)} hosts")


def _p9_nuclei(state: TotalReconState, cfg: Config) -> None:
    """Phase 9: Vulnerability scanning."""
    if not _has("nuclei"):
        state.log_phase("Vulnerability Scan", False, skipped=True, summary="nuclei not installed")
        _skip("nuclei not found"); return

    if not state.live_hosts_txt or count_lines(state.live_hosts_txt) == 0:
        state.log_phase("Vulnerability Scan", False, skipped=True, summary="no live hosts")
        _skip("No live hosts to scan"); return

    out_json = state.loot_root / "phase9_vulns.json"
    _info(f"Running nuclei ({cfg.nuclei_severity}) on {count_lines(state.live_hosts_txt)} hosts...")

    rc, stdout, _ = _run([
        "nuclei", "-l", str(state.live_hosts_txt),
        "-severity", cfg.nuclei_severity,
        "-json-export", str(out_json),
        "-silent", "-stats", "-retries", "2",
        "-timeout", "10", "-c", "20",
    ], timeout=900)

    # Parse findings
    vulns: list[dict] = []
    if out_json.exists():
        try:
            data = json.loads(out_json.read_text(errors="ignore"))
            if isinstance(data, list):
                vulns = data
        except Exception:
            for line in out_json.read_text(errors="ignore").splitlines():
                try:
                    vulns.append(json.loads(line))
                except Exception:
                    pass

    state.vuln_file = out_json
    state.add_findings("vulns", [
        f"{v.get('template-id','?')} @ {v.get('host','?')}"
        for v in vulns[:50]
    ])
    critical = sum(1 for v in vulns
                   if v.get("info",{}).get("severity","").lower() == "critical")
    high     = sum(1 for v in vulns
                   if v.get("info",{}).get("severity","").lower() == "high")
    _ok(f"nuclei: {len(vulns)} findings "
        f"({critical} critical, {high} high)")
    state.log_phase("Vulnerability Scan", True,
                    summary=f"{len(vulns)} total, {critical} crit, {high} high")

    # Fire notification for critical findings
    if critical > 0:
        try:
            notify_scan_complete(state.domain,
                                 f"{critical} CRITICAL vulnerabilities found!",
                                 str(state.loot_root))
        except Exception:
            pass


def _p10_cloud(state: TotalReconState, cfg: Config) -> None:
    """Phase 10: Cloud storage enumeration."""
    try:
        from modules.cloudenum import cloud_enum
        cloud_enum(state.domain, cfg, max_workers=15)
        state.log_phase("Cloud Enum", True, summary="S3/GCS/Azure checked")
    except Exception as e:
        state.log_phase("Cloud Enum", False, summary=str(e)[:60])


def _p11_ssl(state: TotalReconState, cfg: Config) -> None:
    """Phase 11: SSL/TLS audit."""
    if not _has("openssl"):
        state.log_phase("SSL Audit", False, skipped=True, summary="openssl not installed")
        _skip("openssl not found"); return

    try:
        proc = subprocess.run(
            ["openssl", "s_client", "-connect", f"{state.domain}:443",
             "-servername", state.domain, "-showcerts"],
            input="", capture_output=True, text=True, timeout=15,
        )
        raw = proc.stdout + proc.stderr
        # Extract expiry
        import re
        expiry_m = re.search(r"notAfter=(.+)", raw)
        if expiry_m:
            expiry_str = expiry_m.group(1).strip()
            console.print(f"  [cyan]SSL Expiry:[/cyan] {expiry_str}")

        # SANs
        san_m = re.findall(r"DNS:([^,\s]+)", raw)
        if san_m:
            state.add_findings("subdomains", san_m)
            _ok(f"SSL SANs: {len(san_m)} hostnames leaked in certificate")

        out = state.loot_root / "phase11_ssl.txt"
        out.write_text(raw[:10000], encoding="utf-8")
        state.log_phase("SSL Audit", True, summary=f"{len(san_m)} SANs found")
    except Exception as e:
        state.log_phase("SSL Audit", False, summary=str(e)[:60])


def _p12_tech_cve(state: TotalReconState, cfg: Config) -> None:
    """Phase 12: Tech fingerprint + CVE correlation."""
    if not _has("curl"):
        state.log_phase("Tech + CVE", False, skipped=True, summary="curl not installed")
        _skip("curl not found"); return

    target_url = normalize_url(state.domain)
    rc, hdrs, _ = _run(
        ["curl", "-sIL", "--max-time", "12", "-A",
         "Mozilla/5.0 (compatible; CIRCUIT+/1.1)", target_url],
        timeout=15,
    )
    rc2, body, _ = _run(
        ["curl", "-sL", "--max-time", "12", "-A",
         "Mozilla/5.0 (compatible; CIRCUIT+/1.1)", target_url],
        timeout=15,
    )
    combined = (hdrs + body).lower()

    # Quick signature scan
    sigs = [
        ("wordpress","WordPress"),("drupal","Drupal"),("joomla","Joomla"),
        ("shopify","Shopify"),("laravel","Laravel"),("django","Django"),
        ("react","React"),("angular","Angular"),("vue.js","Vue.js"),
        ("apache","Apache"),("nginx","nginx"),("iis","IIS"),
        ("cloudflare","Cloudflare"),("php","PHP"),("asp.net","ASP.NET"),
    ]
    tech_found = list({name for kw, name in sigs if kw in combined})
    state.add_findings("tech", tech_found)
    if tech_found:
        _ok(f"Tech detected: {', '.join(tech_found)}")

    # CVE correlation
    if tech_found:
        try:
            from modules.cve import correlate_tech
            cve_findings = correlate_tech(tech_found, cfg, use_nvd=False)
            state.add_findings("cves", [
                f"{f['cve']} ({f['severity']}) — {f['tech']}"
                for f in cve_findings[:20]
            ])
            critical_cves = [f for f in cve_findings if f["severity"] == "CRITICAL"]
            if critical_cves:
                _warn(f"CVE matches: {len(cve_findings)} total, "
                      f"{len(critical_cves)} CRITICAL")
            else:
                _ok(f"CVE check: {len(cve_findings)} potential matches")
        except Exception:
            pass

    state.log_phase("Tech + CVE", True, summary=f"{len(tech_found)} tech detected")


def _p13_whois_geoip(state: TotalReconState, cfg: Config) -> None:
    """Phase 13: Whois + GeoIP."""
    import socket as _socket

    # Resolve IP
    ip = ""
    try:
        ip = _socket.gethostbyname(state.domain)
        _ok(f"Resolved: {state.domain} → {ip}")
    except Exception:
        pass

    if _has("whois"):
        rc, whois_out, _ = _run(["whois", state.domain], timeout=30)
        out = state.loot_root / "phase13_whois.txt"
        out.write_text(whois_out, encoding="utf-8")
        _ok(f"Whois: {len(whois_out.splitlines())} lines saved")

    if ip and _has("curl"):
        rc, geo_raw, _ = _run([
            "curl", "-s", "--max-time", "10",
            f"http://ip-api.com/json/{ip}?fields=status,country,city,isp,org,as,proxy,hosting",
        ], timeout=15)
        try:
            geo = json.loads(geo_raw)
            if geo.get("status") == "success":
                console.print(
                    f"  [cyan]Location:[/cyan] {geo.get('city','')} {geo.get('country','')}\n"
                    f"  [cyan]ISP:[/cyan]      {geo.get('isp','')}\n"
                    f"  [cyan]Org:[/cyan]      {geo.get('org','')}\n"
                    f"  [cyan]AS:[/cyan]       {geo.get('as','')}"
                )
                if geo.get("hosting"):
                    _warn("IP is in a datacenter/hosting range — may be behind CDN")
        except Exception:
            pass

    state.log_phase("Whois + GeoIP", True, summary=f"IP: {ip}")


def _p14_screenshots(state: TotalReconState, cfg: Config) -> None:
    """Phase 14: Screenshots."""
    if not _has("gowitness"):
        state.log_phase("Screenshots", False, skipped=True, summary="gowitness not installed")
        _skip("gowitness not found — install via Install Manager"); return

    if not state.live_hosts_txt or count_lines(state.live_hosts_txt) == 0:
        state.log_phase("Screenshots", False, skipped=True, summary="no live hosts")
        _skip("No live hosts to screenshot"); return

    screens_dir = state.loot_root / "screenshots"
    screens_dir.mkdir(exist_ok=True)

    try:
        from modules.screenshots import screenshot_hosts
        gallery = screenshot_hosts(str(state.live_hosts_txt), cfg, threads=4)
        if gallery:
            state.screenshots_dir = screens_dir
            _ok(f"Screenshots saved → {gallery}")
            state.log_phase("Screenshots", True, summary=str(gallery))
        else:
            state.log_phase("Screenshots", False, summary="gowitness produced no output")
    except Exception as e:
        state.log_phase("Screenshots", False, summary=str(e)[:60])


def _p15_backup_files(state: TotalReconState, cfg: Config) -> None:
    """Phase 15: Backup & sensitive file hunting."""
    if not _has("gobuster"):
        state.log_phase("Backup File Hunt", False, skipped=True, summary="gobuster not installed")
        _skip("gobuster not found"); return

    wl = _backup_wordlist(cfg)
    if not wl:
        state.log_phase("Backup File Hunt", False, skipped=True, summary="no wordlist")
        _skip("No wordlist for backup hunting"); return

    target_url = normalize_url(state.domain)
    out_file   = state.loot_root / "phase15_backups.txt"
    _info(f"Hunting backup/config files on {target_url}...")

    rc, _, _ = _run([
        "gobuster", "dir",
        "-u", target_url,
        "-w", wl,
        "-x", "bak,backup,old,orig,swp,gz,tar,zip,7z,sql,env,.env,cfg,conf,config,ini,log,key,pem",
        "-o", str(out_file),
        "-t", "30", "--timeout", "10s",
        "-q", "--no-error",
    ], timeout=300)

    found = read_lines(out_file)
    if found:
        _warn(f"Backup/sensitive files: {len(found)} hits!")
        for f in found[:10]:
            console.print(f"  [red]►[/red] {f}")
        state.log_phase("Backup File Hunt", True, summary=f"{len(found)} found")
    else:
        _ok("No backup/sensitive files found")
        state.log_phase("Backup File Hunt", True, summary="none found")


def _p16_report(state: TotalReconState, cfg: Config) -> Path:
    """Phase 16: Generate full report."""
    report_data = state.to_dict()

    # JSON
    json_file = state.loot_root / "totalrecon_report.json"
    json_file.write_text(json.dumps(report_data, indent=2, default=str),
                         encoding="utf-8")

    # Text
    txt_file = state.loot_root / "totalrecon_report.txt"
    lines: list[str] = [
        "=" * 72,
        "  CIRCUIT+ — TOTAL RECON REPORT",
        f"  Domain:  {state.domain}",
        f"  Started: {state.started_at.strftime('%Y-%m-%d %H:%M')}",
        f"  Elapsed: {state.elapsed()}",
        f"  Loot:    {state.loot_root}",
        "=" * 72, "",
        "FINDINGS SUMMARY",
        "-" * 40,
        f"  Subdomains found:    {len(state.findings['subdomains'])}",
        f"  Live web hosts:      {len(state.findings['live_hosts'])}",
        f"  URLs collected:      {len(state.findings['urls'])}",
        f"  Vulnerabilities:     {len(state.findings['vulns'])}",
        f"  Cloud buckets:       {len(state.findings['cloud_buckets'])}",
        f"  Technologies:        {len(state.findings['tech'])}",
        f"  CVE matches:         {len(state.findings['cves'])}",
        "",
        "PHASE LOG",
        "-" * 40,
    ]
    for p in state.phase_log:
        status = "SKIP" if p["skipped"] else ("OK" if p["ok"] else "FAIL")
        lines.append(f"  [{status:4}]  {p['name']:<30} {p.get('summary','')}")
    lines += ["", "SUBDOMAINS", "-" * 40]
    lines += [f"  {s}" for s in state.findings["subdomains"][:200]]
    lines += ["", "LIVE HOSTS", "-" * 40]
    lines += [f"  {h}" for h in state.findings["live_hosts"][:100]]
    lines += ["", "VULNERABILITIES", "-" * 40]
    lines += [f"  {v}" for v in state.findings["vulns"][:100]]
    lines += ["", "CVE MATCHES", "-" * 40]
    lines += [f"  {c}" for c in state.findings["cves"][:50]]
    lines += ["", f"Generated by CIRCUIT+ v1.1 — Authorized Use Only"]

    txt_file.write_text("\n".join(lines), encoding="utf-8")

    # HTML
    html_file = state.loot_root / "totalrecon_report.html"
    _write_html_report(state, html_file)

    log_ok(f"Reports saved:")
    log_ok(f"  JSON → {json_file}")
    log_ok(f"  TXT  → {txt_file}")
    log_ok(f"  HTML → {html_file}")

    state.log_phase("Report Generation", True,
                    summary=f"JSON + TXT + HTML in {state.loot_root}")
    return html_file


def _write_html_report(state: TotalReconState, path: Path) -> None:
    """Generate a self-contained HTML report."""
    d  = state.findings
    ts = state.started_at.strftime("%Y-%m-%d %H:%M")

    rows_phases = "".join(
        f"<tr><td class='ph'>{p['name']}</td>"
        f"<td class='{'ok' if p['ok'] and not p['skipped'] else ('sk' if p['skipped'] else 'fl')}'>"
        f"{'SKIP' if p['skipped'] else ('OK' if p['ok'] else 'FAIL')}</td>"
        f"<td>{p.get('summary','')}</td></tr>"
        for p in state.phase_log
    )
    rows_subs  = "".join(f"<tr><td>{s}</td></tr>" for s in d["subdomains"][:300])
    rows_hosts = "".join(f"<tr><td><a href='{h}' target='_blank'>{h}</a></td></tr>"
                         for h in d["live_hosts"][:100])
    rows_vulns = "".join(f"<tr><td>{v}</td></tr>" for v in d["vulns"][:100])
    rows_cves  = "".join(f"<tr><td>{c}</td></tr>" for c in d["cves"][:50])
    rows_tech  = "".join(f"<tr><td>{t}</td></tr>" for t in d["tech"])

    html = (
        "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>"
        f"<title>CIRCUIT+ Total Recon — {state.domain}</title>"
        "<style>"
        "body{background:#0a0a0a;color:#00ff41;font-family:monospace;padding:2rem}"
        "h1{color:#00ff41;border-bottom:1px solid #003300;padding-bottom:.5rem}"
        "h2{color:#00cc33;margin-top:2rem}"
        ".summary{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin:1.5rem 0}"
        ".card{background:#111;border:1px solid #003300;border-radius:4px;padding:1rem;text-align:center}"
        ".card .n{font-size:2rem;color:#00ff41;font-weight:bold}"
        ".card .l{font-size:.8rem;color:#444;margin-top:.3rem}"
        "table{border-collapse:collapse;width:100%;margin:.5rem 0}"
        "td,th{border:1px solid #003300;padding:.4rem .8rem;text-align:left;font-size:.85rem}"
        "th{background:#002200;color:#00ff41}"
        "tr:nth-child(even){background:#0a0a0a}"
        ".ok{color:#00ff41;font-weight:bold}.fl{color:#ff4444;font-weight:bold}.sk{color:#888}"
        ".ph{color:#00cc33}"
        "a{color:#00aa33}"
        "</style></head><body>"
        f"<h1>CIRCUIT+ Total Recon — {state.domain}</h1>"
        f"<p style='color:#444'>Scan started: {ts} | Elapsed: {state.elapsed()}"
        f" | Loot: <code>{state.loot_root}</code></p>"
        "<div class='summary'>"
        f"<div class='card'><div class='n'>{len(d['subdomains'])}</div><div class='l'>Subdomains</div></div>"
        f"<div class='card'><div class='n'>{len(d['live_hosts'])}</div><div class='l'>Live Hosts</div></div>"
        f"<div class='card'><div class='n'>{len(d['vulns'])}</div><div class='l'>Vulns</div></div>"
        f"<div class='card'><div class='n'>{len(d['cves'])}</div><div class='l'>CVE Matches</div></div>"
        f"<div class='card'><div class='n'>{len(d['urls'])}</div><div class='l'>URLs</div></div>"
        f"<div class='card'><div class='n'>{len(d['tech'])}</div><div class='l'>Technologies</div></div>"
        f"<div class='card'><div class='n'>{len(d['cloud_buckets'])}</div><div class='l'>Cloud Buckets</div></div>"
        f"<div class='card'><div class='n'>{len(state.phase_log)}</div><div class='l'>Phases Run</div></div>"
        "</div>"
        "<h2>Phase Summary</h2><table><tr><th>Phase</th><th>Status</th><th>Summary</th></tr>"
        + rows_phases + "</table>"
        "<h2>Subdomains</h2><table><tr><th>Hostname</th></tr>" + rows_subs + "</table>"
        "<h2>Live Hosts</h2><table><tr><th>URL</th></tr>" + rows_hosts + "</table>"
        "<h2>Vulnerabilities</h2><table><tr><th>Finding</th></tr>" + rows_vulns + "</table>"
        "<h2>CVE Matches</h2><table><tr><th>CVE</th></tr>" + rows_cves + "</table>"
        "<h2>Technology</h2><table><tr><th>Tech</th></tr>" + rows_tech + "</table>"
        "<p style='color:#333;margin-top:3rem;font-size:.75rem'>"
        "Generated by CIRCUIT+ v1.1 — Authorized Use Only</p>"
        "</body></html>"
    )
    path.write_text(html, encoding="utf-8")


def _ok(msg: str) -> None:
    console.print(f"  [green]✓[/green] {msg}")

def _warn(msg: str) -> None:
    console.print(f"  [yellow]△[/yellow] {msg}")

def _info(msg: str) -> None:
    console.print(f"  [cyan]»[/cyan] {msg}")

def _skip(msg: str) -> None:
    console.print(f"  [dim]⊘  {msg} — skipped[/dim]")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

PHASES = [
    (1,  "Passive Subdomain Enum",    "subfinder",        _p1_subfinder),
    (2,  "DNS Brute-Force",           "dnsx + wordlist",  _p2_dns_brute),
    (3,  "Subdomain Permutations",    "alterx",           _p3_alterx),
    (4,  "DNS Resolution",            "dnsx",             _p4_dns_resolve),
    (5,  "HTTP Probing",              "httpx",            _p5_httpx),
    (6,  "Full Port Scan",            "rustscan + nmap",  _p6_ports),
    (7,  "Web Crawling",              "katana + gau",     _p7_crawl),
    (8,  "Content Discovery",         "ffuf",             _p8_content_discovery),
    (9,  "Vulnerability Scan",        "nuclei",           _p9_nuclei),
    (10, "Cloud Storage Enum",        "curl checks",      _p10_cloud),
    (11, "SSL/TLS Audit",             "openssl",          _p11_ssl),
    (12, "Tech + CVE Correlation",    "curl + NVD",       _p12_tech_cve),
    (13, "Whois + GeoIP",             "whois + curl",     _p13_whois_geoip),
    (14, "Screenshots",               "gowitness",        _p14_screenshots),
    (15, "Backup File Hunt",          "gobuster",         _p15_backup_files),
    (16, "Report Generation",         "built-in",         None),
]


def run_total_recon(domain: str, cfg: Config) -> Optional[Path]:
    """
    Run the full 16-phase Total Recon against a domain.
    AUTHORIZED USE ONLY.

    Args:
        domain: Target domain (e.g. example.com).
        cfg:    CIRCUIT+ config.

    Returns:
        Path to HTML report, or None on early abort.
    """
    if not (is_valid_domain(domain) or is_valid_ip(domain)):
        log_err(f"Invalid target: '{domain}'")
        return None

    # Scope check
    try:
        from modules.scope import load_scope, assert_in_scope
        scope = load_scope()
        if not assert_in_scope(domain, scope):
            return None
    except Exception:
        pass

    ts       = timestamp()
    loot_dir = cfg.loot_path / domain.replace(".", "_") / ts
    loot_dir.mkdir(parents=True, exist_ok=True)
    state    = TotalReconState(domain, loot_dir)

    console.print()
    console.print(Panel(
        f"  [bold white]Target:[/bold white]   [cyan]{domain}[/cyan]\n"
        f"  [bold white]Phases:[/bold white]   {len(PHASES)}\n"
        f"  [bold white]Loot:[/bold white]     [dim]{loot_dir}[/dim]\n\n"
        "  [bold yellow]⚠  AUTHORIZED USE ONLY[/bold yellow]\n"
        "  [dim]Only run against targets you own or have written permission to test.[/dim]\n\n"
        "  [dim]Ctrl+C skips the current phase and continues.[/dim]",
        title="[bold bright_green]// CIRCUIT+ — Total Recon[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    try:
        confirm = input("\033[92m[?] Confirm authorized target and proceed? [y/N]: \033[0m").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return None
    if confirm not in ("y","yes"):
        log_warn("Total Recon aborted.")
        return None

    # Run all phases
    for phase_n, phase_name, phase_tools, phase_fn in PHASES:
        if phase_fn is None:
            break  # report phase handled separately

        _phase_banner(phase_n, len(PHASES), phase_name, f"Tools: {phase_tools}")
        try:
            phase_fn(state, cfg)
        except KeyboardInterrupt:
            console.print(f"\n  [yellow][~] Phase {phase_n} skipped (Ctrl+C)[/yellow]")
            state.log_phase(phase_name, False, skipped=True, summary="Skipped by user")
        except Exception as exc:
            log_err(f"Phase {phase_n} error: {exc}")
            state.log_phase(phase_name, False, summary=str(exc)[:80])

    # Phase 16: Report
    _phase_banner(16, len(PHASES), "Report Generation", "JSON + TXT + HTML")
    html_report = _p16_report(state, cfg)

    # Final summary
    console.print()
    console.print(Rule("[bold bright_green]// Total Recon Complete[/bold bright_green]",
                       style="bright_green"))

    stbl = Table(
        title=f"[bold bright_green]// Results — {domain}[/bold bright_green]",
        box=box.DOUBLE_EDGE, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    stbl.add_column("Metric",   style="bold cyan", width=24)
    stbl.add_column("Count",    width=8,  justify="right")
    stbl.add_column("Detail",   style="dim",       width=40)

    rows = [
        ("Subdomains found",  len(state.findings["subdomains"]),
         f"saved to phase4_resolved.txt"),
        ("Live web hosts",    len(state.findings["live_hosts"]),
         "httpx probed"),
        ("URLs collected",    len(state.findings["urls"]),
         "katana + gau + waybackurls"),
        ("Vulnerabilities",   len(state.findings["vulns"]),
         f"nuclei {cfg.nuclei_severity}"),
        ("Cloud buckets",     len(state.findings["cloud_buckets"]),
         "S3 / GCS / Azure"),
        ("Technologies",      len(state.findings["tech"]),
         "fingerprinted"),
        ("CVE matches",       len(state.findings["cves"]),
         "built-in + NVD"),
        ("Phases completed",  sum(1 for p in state.phase_log if p["ok"]),
         f"of {len(PHASES)} total"),
        ("Phases skipped",    len(state.skipped),
         "tool not installed or no data"),
        ("Elapsed time",      0, state.elapsed()),
    ]
    for i, (label, count, detail) in enumerate(rows):
        val = state.elapsed() if label == "Elapsed time" else str(count)
        color = "red" if label == "Vulnerabilities" and count > 0 else \
                "yellow" if label == "CVE matches" and count > 0 else \
                "green" if count > 0 else "dim"
        stbl.add_row(label, f"[{color}]{val}[/{color}]", detail,
                     style="on grey11" if i % 2 == 0 else "")
    console.print(stbl)

    log_ok(f"HTML report: {html_report}")
    append_history({
        "ts": ts, "action": "total_recon", "target": domain,
        "subdomains": len(state.findings["subdomains"]),
        "hosts": len(state.findings["live_hosts"]),
        "vulns": len(state.findings["vulns"]),
        "elapsed": state.elapsed(),
    })

    # Notification
    try:
        notify_scan_complete(domain, len(state.phase_log), str(loot_dir))
    except Exception:
        pass

    # Export menu
    try:
        from modules.massscan import _export_menu
        class _FakeReport:
            def to_text(self):
                return open(loot_dir/"totalrecon_report.txt").read()
            def to_dict(self):
                return state.to_dict()
        _export_menu(_FakeReport(), loot_dir)
    except Exception:
        pass

    # Open HTML report?
    try:
        ans = input("\033[92m[?] Open HTML report in browser? [y/N]: \033[0m").strip().lower()
        if ans in ("y","yes") and shutil.which("xdg-open"):
            subprocess.Popen(["xdg-open", str(html_report)])
    except (EOFError, KeyboardInterrupt):
        pass

    return html_report


def run_total_recon_menu(cfg: Config) -> None:
    """Interactive entry point for Total Recon."""
    console.print()
    console.print(Panel(
        "  [bold bright_green]Total Recon[/bold bright_green] — the most comprehensive scan CIRCUIT+ offers.\n\n"
        "  Chains [bold]16 phases[/bold] against a single domain target:\n"
        "    Passive enum → DNS brute → permutations → host probe\n"
        "    Port scan → web crawl → content discovery → vuln scan\n"
        "    Cloud enum → SSL audit → tech fingerprint → CVE check\n"
        "    Whois/GeoIP → screenshots → backup hunt → full report\n\n"
        "  Estimated time: [yellow]15–60 minutes[/yellow] depending on target size.\n\n"
        "  [bold red]⚠  AUTHORIZED TARGETS ONLY[/bold red]",
        title="[bold bright_green]// Total Recon[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    while True:
        try:
            domain = input("\033[92m[?] Target domain (0=back): \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            return

        if domain in ("0","back",""):
            return

        domain = domain.lstrip("https://").lstrip("http://").split("/")[0]
        if not (is_valid_domain(domain) or is_valid_ip(domain)):
            log_err(f"'{domain}' is not a valid domain or IP.")
            log_info("Examples: example.com | 192.168.1.1")
            continue

        run_total_recon(domain, cfg)

        try:
            again = input("\n\033[92m[?] Run on another target? [y/N]: \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return
        if again not in ("y","yes"):
            return
