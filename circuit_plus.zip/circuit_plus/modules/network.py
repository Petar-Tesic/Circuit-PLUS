#!/usr/bin/env python3
"""
CIRCUIT+ — Network scanning: rustscan, nmap, masscan, naabu.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

try:
    from rich.console import Console
    from rich.panel import Panel
except ImportError:
    pass

from config import Config, append_history
from core.engine import run_tool, run_with_progress, stream_lines
from core.validator import assert_tool
from core.parser import (
    parse_rustscan_ports, parse_nmap_xml, print_nmap_results,
)
from utils.helpers import (
    is_valid_ip, is_valid_domain, is_valid_cidr,
    make_loot_dir, timestamp, write_lines, count_lines, confirm
)
from utils.logger import console, log_ok, log_err, log_info, log_warn, LootLogger


# ── Port Scan (RustScan → Nmap) ───────────────────────────────────────────────

def port_scan(target: str, cfg: Config) -> Optional[Path]:
    """
    Fast port scan using RustScan, then detailed nmap service scan on open ports.

    Workflow:
        rustscan -a target --ulimit 5000 → extract open ports
        nmap -sV -sC -p {ports} -oX output.xml

    Args:
        target: IP address or hostname.
        cfg:    CIRCUIT+ config.

    Returns:
        Path to nmap XML output file, or None on failure.
    """
    if not (is_valid_ip(target) or is_valid_domain(target)):
        from rich.panel import Panel as _P
        _msg = (
            "[bold red][!] Invalid Target[/bold red]\n\n"
            "  Provided: [cyan]" + str(target) + "[/cyan]\n\n"
            "  Expected formats:\n"
            "    \u2022 IPv4 address:   [green]192.168.1.1[/green]\n"
            "    \u2022 Domain name:    [green]example.com[/green]\n"
            "    \u2022 Subdomain:      [green]api.example.com[/green]"
        )
        console.print(_P(_msg, border_style="red", expand=False))
        return None

    if not assert_tool("rustscan") and not assert_tool("nmap"):
        log_err("Neither rustscan nor nmap found.")
        return None

    loot = make_loot_dir(cfg.loot_path, target, "network")
    logger = LootLogger(loot, "port_scan")
    nmap_xml = loot / "nmap_detailed.xml"
    nmap_base = loot / "nmap_detailed"  # nmap -oA prefix

    open_ports: list[int] = []

    # ── Step 1: RustScan ──────────────────────────────────────────
    if assert_tool("rustscan"):
        log_info(f"RustScan fast sweep: {target}")
        rustscan_cmd = [
            "rustscan",
            "-a", target,
            "--ulimit", "5000",
            "--", "-sV", "-sC",
            "--open",
        ]
        rc, stdout, stderr = run_with_progress(
            rustscan_cmd,
            description=f"RustScanning {target}...",
        )
        logger.command(rustscan_cmd, rc, 0)
        open_ports = parse_rustscan_ports(stdout)

        if open_ports:
            log_ok(f"RustScan open ports: {', '.join(str(p) for p in open_ports)}")
        else:
            log_warn("RustScan found no open ports (or failed to parse output).")
            # Fall back: scan all common ports with nmap
            open_ports = []
    else:
        log_warn("rustscan not found — running nmap directly on common ports")

    # ── Step 2: Nmap detailed scan ────────────────────────────────
    if assert_tool("nmap"):
        nmap_cmd = [
            "nmap",
            "-sV",          # service version
            "-sC",          # default scripts
            "-T4",          # aggressive timing
            "--open",       # only show open ports
            "-oA", str(nmap_base),
        ]

        if open_ports:
            port_str = ','.join(str(p) for p in open_ports)
            nmap_cmd.extend(["-p", port_str])
        else:
            nmap_cmd.extend(["-p-", "--min-rate", "1000"])  # all ports fallback

        nmap_cmd.append(target)

        rc2, stdout2, _ = run_with_progress(
            nmap_cmd,
            description=f"Nmap detailed scan: {target}...",
        )
        logger.command(nmap_cmd, rc2, 0)

        # Parse XML results
        results = parse_nmap_xml(nmap_xml)
        print_nmap_results(results)

        if results:
            total_ports = sum(len(h['ports']) for h in results)
            log_ok(f"Nmap complete: {total_ports} open services → {nmap_base}.(xml|nmap|gnmap)")
        else:
            log_warn("No open ports in nmap output.")
    else:
        log_warn("nmap not found — cannot run detailed scan.")

    logger.flush()
    append_history({
        "ts": timestamp(), "action": "port_scan",
        "target": target, "open_ports": open_ports
    })

    return nmap_xml if nmap_xml.exists() else None


# ── Nmap Direct ───────────────────────────────────────────────────────────────

def nmap_direct(target: str, cfg: Config, flags: str = "-sV -sC -T4") -> Optional[Path]:
    """
    Run nmap directly with custom flags.

    Args:
        target: IP, hostname, or CIDR range.
        cfg:    Config object.
        flags:  Raw nmap flag string.

    Returns:
        Path to nmap output directory/file, or None.
    """
    if not assert_tool("nmap"):
        return None

    loot = make_loot_dir(cfg.loot_path, target.replace('/', '_'), "network")
    logger = LootLogger(loot, "nmap_direct")
    nmap_base = loot / "nmap_custom"

    cmd_parts = ["nmap"] + flags.split() + [
        "-oA", str(nmap_base), target
    ]

    log_info(f"nmap: {' '.join(cmd_parts)}")
    rc, stdout, _ = run_with_progress(
        cmd_parts,
        description=f"Running nmap on {target}...",
    )
    logger.command(cmd_parts, rc, 0)

    nmap_xml = Path(str(nmap_base) + ".xml")
    results = parse_nmap_xml(nmap_xml)
    print_nmap_results(results)

    logger.flush()
    return nmap_xml if nmap_xml.exists() else None


# ── Massive CIDR Scan (masscan) ───────────────────────────────────────────────

def massive_scan(cidr: str, cfg: Config) -> Optional[Path]:
    """
    Mass-scan a CIDR range with masscan. Shows loud warning + confirmation.

    Args:
        cidr: CIDR range to scan (e.g. 10.0.0.0/24).
        cfg:  Config object.

    Returns:
        Path to masscan XML output, or None.
    """
    if not is_valid_cidr(cidr):
        from rich.panel import Panel as _P
        _msg = (
            "[bold red][!] Invalid CIDR Range[/bold red]\\n\\n"
            "  Provided: [cyan]" + str(cidr) + "[/cyan]\\n\\n"
            "  Expected format: [green]192.168.1.0/24[/green]\\n"
            "  Examples:\\n"
            "    \\u2022 [green]10.0.0.0/8[/green]       (Class A)\\n"
            "    \\u2022 [green]172.16.0.0/16[/green]    (Class B)\\n"
            "    \\u2022 [green]192.168.1.0/24[/green]   (Class C)"
        )
        console.print(_P(_msg, border_style="red", expand=False))
        return None

    # ⚠️  Loud warning
    console.print(Panel(
        f"[bold red]⚠  WARNING[/bold red]\n\n"
        f"  masscan on [cyan]{cidr}[/cyan] is VERY LOUD.\n"
        f"  Rate: [yellow]{cfg.rate_limit:,} packets/sec[/yellow]\n"
        f"  This will trigger IDS/IPS and alerts.\n"
        f"  Only proceed on targets you are authorized to test.\n",
        border_style="red",
        title="[bold red]// LOUD SCAN[/bold red]",
    ))

    if not confirm("Confirm you are authorized to scan this range", default=False):
        log_warn("masscan aborted.")
        return None

    if not assert_tool("masscan"):
        return None

    loot = make_loot_dir(cfg.loot_path, cidr.replace('/', '_'), "network")
    logger = LootLogger(loot, "masscan")
    output_xml = loot / "masscan.xml"
    output_txt = loot / "masscan_open.txt"

    cmd = [
        "masscan",
        cidr,
        "-p0-65535",
        "--rate", str(cfg.rate_limit),
        "-oX", str(output_xml),
    ]

    log_info(f"masscan: {cidr} at {cfg.rate_limit:,} pps")
    rc, stdout, stderr = run_with_progress(
        cmd,
        description=f"masscan {cidr}...",
    )
    logger.command(cmd, rc, 0)

    if output_xml.exists():
        # Parse XML and extract open ports
        results = parse_nmap_xml(output_xml)  # masscan XML is nmap-compatible
        print_nmap_results(results)
        log_ok(f"masscan complete → {output_xml}")
    else:
        log_warn("No masscan output generated.")

    logger.flush()
    append_history({
        "ts": timestamp(), "action": "masscan",
        "target": cidr, "rate": cfg.rate_limit
    })
    return output_xml if output_xml.exists() else None


# ── Naabu Scan ────────────────────────────────────────────────────────────────

def naabu_scan(target: str, cfg: Config, ports: str = "top-100") -> Optional[Path]:
    """
    Port scan with naabu (ProjectDiscovery).

    Args:
        target: IP, domain, or CIDR.
        cfg:    Config.
        ports:  Port spec: 'top-100', 'top-1000', or '80,443,8080-8090'.

    Returns:
        Path to output file, or None.
    """
    if not assert_tool("naabu"):
        return None

    loot = make_loot_dir(cfg.loot_path, target.replace('/', '_'), "network")
    logger = LootLogger(loot, "naabu")
    output = loot / "naabu_results.txt"

    cmd = [
        "naabu",
        "-host", target,
        "-o", str(output),
        "-silent",
        "-c", str(min(cfg.threads, 25)),
    ]

    if ports.startswith("top-"):
        count = ports.split("-")[1]
        cmd.extend(["-top-ports", count])
    else:
        cmd.extend(["-p", ports])

    rc, _, _ = run_with_progress(cmd, description=f"naabu: {target}...")
    logger.command(cmd, rc, count_lines(output))

    if output.exists():
        lines = [l for l in output.read_text().splitlines() if l.strip()]
        if lines:
            log_ok(f"naabu: {len(lines)} open ports")
            for line in lines:
                console.print(f"  [cyan]{line}[/cyan]")
        else:
            log_warn("naabu: no open ports found.")

    logger.flush()
    return output if output.exists() else None


# ── Interactive Network Menu Handler ──────────────────────────────────────────

def run_network_menu(cfg: Config) -> None:
    """Interactive loop for the Network module submenu."""
    from ui.menus import show_network_menu, get_choice, divider

    while True:
        try:
            console.print()
            show_network_menu()
            choice = get_choice("network> ")

            if choice == "0":
                break

            elif choice == "1":
                # RustScan + Nmap
                divider()
                try:
                    target = input("\033[92m[?] Target (IP/domain): \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if not target:
                    log_warn("No target entered.")
                    continue
                if not (is_valid_ip(target) or is_valid_domain(target)):
                    log_err(f"'{target}' is not a valid IP or domain.")
                    log_info("Examples: 192.168.1.1  |  example.com  |  api.target.io")
                    continue
                port_scan(target, cfg)

            elif choice == "2":
                # Nmap Direct
                divider()
                try:
                    target = input("\033[92m[?] Target (IP/domain/CIDR): \033[0m").strip()
                    flags  = input("\033[92m[?] nmap flags [-sV -sC -T4]: \033[0m").strip() or "-sV -sC -T4"
                except (KeyboardInterrupt, EOFError):
                    continue
                if target:
                    nmap_direct(target, cfg, flags=flags)

            elif choice == "3":
                # Masscan
                divider()
                try:
                    cidr = input("\033[92m[?] CIDR range (e.g. 192.168.1.0/24): \033[0m").strip()
                except (KeyboardInterrupt, EOFError):
                    continue
                if cidr:
                    massive_scan(cidr, cfg)

            elif choice == "4":
                # Naabu
                divider()
                try:
                    target = input("\033[92m[?] Target (IP/domain): \033[0m").strip()
                    ports  = input("\033[92m[?] Ports [top-100]: \033[0m").strip() or "top-100"
                except (KeyboardInterrupt, EOFError):
                    continue
                if target:
                    naabu_scan(target, cfg, ports=ports)

            elif choice == "99":
                break

            else:
                log_warn(f"Unknown option: {choice}")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break
