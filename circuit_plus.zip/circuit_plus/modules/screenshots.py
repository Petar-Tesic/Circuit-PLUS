#!/usr/bin/env python3
"""
CIRCUIT+ — Screenshots: gowitness gallery for visual host triage.
"""
from __future__ import annotations

import shutil
import subprocess
import textwrap
from pathlib import Path
from typing import Optional

from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import make_loot_dir, timestamp, count_lines, read_lines
from config import Config, append_history


# ── gowitness runner ──────────────────────────────────────────────────────────

def _run_gowitness(cmd: list[str], loot: Path) -> tuple[int, str]:
    """Run gowitness, stream output, return (rc, stderr)."""
    console.print(f"\n[dim cyan]  $ {' '.join(cmd)}[/dim cyan]")
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=600, cwd=str(loot),
        )
        return r.returncode, r.stderr
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT"
    except FileNotFoundError:
        return 127, "gowitness not found"
    except Exception as e:
        return 1, str(e)


# ── Screenshot functions ──────────────────────────────────────────────────────

def screenshot_hosts(
    hosts_file: str,
    cfg: Config,
    threads: int = 5,
    resolution: str = "1280,720",
    timeout_secs: int = 15,
) -> Optional[Path]:
    """
    Screenshot all URLs/hosts in a file using gowitness.

    Args:
        hosts_file:    Path to file containing URLs (one per line).
        cfg:           CIRCUIT+ config.
        threads:       Concurrent screenshot threads (keep low — CPU bound).
        resolution:    Screenshot resolution as "WxH".
        timeout_secs:  Per-page timeout.

    Returns:
        Path to the gallery HTML file, or None on failure.
    """
    if not shutil.which("gowitness"):
        console.print(Panel(
            "[bold red][!] gowitness not found[/bold red]\n\n"
            "  Install via Go:\n"
            "  [cyan]go install github.com/sensepost/gowitness@latest[/cyan]\n\n"
            "  Or use [bold][7] Install Manager[/bold] to install it.",
            border_style="red", expand=False,
        ))
        return None

    hosts_path = Path(hosts_file)
    if not hosts_path.exists():
        log_err(f"Hosts file not found: {hosts_file}")
        return None

    count = count_lines(hosts_path)
    if count == 0:
        log_warn("Hosts file is empty.")
        return None

    target_name = hosts_path.stem
    loot = make_loot_dir(cfg.loot_path, target_name, "screenshots")
    screenshots_dir = loot / "screenshots"
    screenshots_dir.mkdir(parents=True, exist_ok=True)
    db_path = loot / "gowitness.db"

    log_info(f"Screenshotting {count} hosts → {loot}")
    log_info(f"Threads: {threads}  Resolution: {resolution}  Timeout: {timeout_secs}s")

    cmd = [
        "gowitness", "file",
        "-f", str(hosts_path),
        "--screenshot-path", str(screenshots_dir),
        "--db-path", str(db_path),
        "--threads", str(threads),
        "--timeout", str(timeout_secs),
        "--resolution", resolution,
        "--disable-logging",
    ]

    with Progress(
        SpinnerColumn(style="bright_green"),
        TextColumn(f"[bright_green]Screenshotting {count} hosts..."),
        TimeElapsedColumn(),
        console=console, transient=True,
    ) as prog:
        task = prog.add_task("screenshots", total=None)
        rc, stderr = _run_gowitness(cmd, loot)
        prog.update(task, completed=True)

    if rc not in (0, 1):   # gowitness exits 1 if some pages fail — that's OK
        log_err(f"gowitness failed (exit {rc}): {stderr[:200]}")
        return None

    # Count screenshots taken
    png_files = list(screenshots_dir.glob("*.png"))
    log_ok(f"Captured {len(png_files)} screenshots → {screenshots_dir}")

    # Generate HTML gallery
    gallery = _build_html_gallery(png_files, target_name, hosts_file)
    gallery_path = loot / "gallery.html"
    gallery_path.write_text(gallery, encoding="utf-8")
    log_ok(f"Gallery: {gallery_path}")

    append_history({
        "ts": timestamp(), "action": "screenshots",
        "target": hosts_file, "count": len(png_files),
        "gallery": str(gallery_path),
    })

    # Offer to open gallery
    try:
        ans = input("\033[92m[?] Open gallery in browser? [y/N]: \033[0m").strip().lower()
        if ans in ("y", "yes") and shutil.which("xdg-open"):
            subprocess.Popen(["xdg-open", str(gallery_path)])
    except (EOFError, KeyboardInterrupt):
        pass

    return gallery_path


def screenshot_single(url: str, cfg: Config) -> Optional[Path]:
    """
    Screenshot a single URL.

    Args:
        url: Target URL.
        cfg: Config.

    Returns:
        Path to screenshot PNG, or None.
    """
    if not shutil.which("gowitness"):
        log_err("gowitness not found. Install: go install github.com/sensepost/gowitness@latest")
        return None

    from utils.helpers import normalize_url
    url = normalize_url(url)
    host = url.replace("https://","").replace("http://","").split("/")[0].replace(":","_")
    loot = make_loot_dir(cfg.loot_path, host, "screenshots")
    out_png = loot / f"{host}.png"

    cmd = [
        "gowitness", "single",
        "--url", url,
        "--screenshot-path", str(loot),
        "--disable-logging",
    ]

    rc, stderr = _run_gowitness(cmd, loot)
    if rc not in (0, 1):
        log_err(f"gowitness failed: {stderr[:100]}")
        return None

    pngs = list(loot.glob("*.png"))
    if pngs:
        log_ok(f"Screenshot saved: {pngs[0]}")
        return pngs[0]
    return None


# ── HTML gallery builder ──────────────────────────────────────────────────────

def _build_html_gallery(png_files: list[Path], title: str, source: str) -> str:
    """Generate a self-contained HTML screenshot gallery."""
    from datetime import datetime
    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    cards = ""
    for png in sorted(png_files):
        label = png.stem[:60]
        cards += (
            '<div class="card">' +
            '<img src="screenshots/' + png.name + '" loading="lazy" />' +
            '<div class="label">' + label + '</div>' +
            '</div>\n'
        )

    html_parts = [
        "<!DOCTYPE html>\n",
        "<html lang=\"en\">\n",
        "<head>\n",
        "  <meta charset=\"UTF-8\">\n",
        "  <title>CIRCUIT+ Screenshots - " + title + "</title>\n",
        "  <style>\n",
        "    * { box-sizing: border-box; margin: 0; padding: 0; }\n",
        "    body { background: #0a0a0a; color: #00ff41; font-family: monospace; padding: 1.5rem; }\n",
        "    h1   { font-size: 1.4rem; margin-bottom: .3rem; color: #00ff41; }\n",
        "    .meta { color: #444; font-size: .8rem; margin-bottom: 1.5rem; }\n",
        "    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 1rem; }\n",
        "    .card { background: #111; border: 1px solid #003300; border-radius: 4px; overflow: hidden; transition: border-color .2s; }\n",
        "    .card:hover { border-color: #00ff41; }\n",
        "    .card img { width: 100%; height: 180px; object-fit: cover; display: block; cursor: zoom-in; }\n",
        "    .label { padding: .4rem .6rem; font-size: .7rem; color: #00aa33; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }\n",
        "    input[type=text] { background: #111; border: 1px solid #003300; color: #00ff41; padding: .4rem .8rem; border-radius: 3px; width: 100%; margin-bottom: 1rem; font-family: monospace; font-size: .9rem; }\n",
        "    #lb { display:none; position:fixed; inset:0; background:rgba(0,0,0,.95); z-index:999; align-items:center; justify-content:center; cursor:zoom-out; }\n",
        "    #lb.open { display:flex; }\n",
        "    #lb img { max-width:95vw; max-height:95vh; border:1px solid #00ff41; }\n",
        "  </style>\n",
        "</head>\n",
        "<body>\n",
        "  <h1>CIRCUIT+ - Screenshot Gallery</h1>\n",
        "  <div class=\"meta\">Target: " + title + " | " + str(len(png_files)) + " screenshots | " + source + " | " + date_str + "</div>\n",
        "  <input type=\"text\" id=\"filter\" placeholder=\"Filter by name...\" oninput=\"filterCards(this.value)\">\n",
        "  <div class=\"grid\" id=\"grid\">\n",
        cards,
        "  </div>\n",
        "  <div id=\"lb\" onclick=\"closeLb()\"><img id=\"lb-img\" src=\"\" alt=\"\"></div>\n",
        "  <script>\n",
        "    document.querySelectorAll('.card img').forEach(img => {\n",
        "      img.onclick = e => { e.stopPropagation(); document.getElementById('lb-img').src = img.src; document.getElementById('lb').classList.add('open'); };\n",
        "    });\n",
        "    function closeLb() { document.getElementById('lb').classList.remove('open'); }\n",
        "    function filterCards(q) { q = q.toLowerCase(); document.querySelectorAll('.card').forEach(c => { c.style.display = c.querySelector('.label').textContent.toLowerCase().includes(q) ? '' : 'none'; }); }\n",
        "  </script>\n",
        "</body>\n",
        "</html>\n",
    ]
    return "".join(html_parts)


def run_screenshot_menu(cfg: Config) -> None:
    """Interactive screenshot module entry point."""
    from utils.picker import pick_file
    console.print()
    console.print(Panel(
        "  Screenshot live web hosts using [bold]gowitness[/bold].\n"
        "  Generates a searchable HTML gallery for visual triage.\n\n"
        "  [1] Screenshot from hosts file\n"
        "  [2] Screenshot single URL\n"
        "  [0] Back",
        title="[bold bright_green]// Screenshots[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    try:
        choice = input("\033[92m  screenshots> \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if choice == "1":
        console.print("\n[dim]Select hosts file (URLs, one per line):[/dim]")
        console.print("  [1] Browse  [2] Type path")
        try:
            pm = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
        except (EOFError, KeyboardInterrupt):
            return
        if pm == "2":
            try:
                path = input("\033[92m[?] Hosts file: \033[0m").strip()
            except (EOFError, KeyboardInterrupt):
                return
        else:
            path = pick_file(
                title="Select Hosts / URLs File",
                label="Hosts file",
                must_exist=True,
                filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            )
        if path:
            try:
                threads = int(input("\033[92m[?] Threads [5]: \033[0m").strip() or "5")
            except (ValueError, EOFError, KeyboardInterrupt):
                threads = 5
            screenshot_hosts(path, cfg, threads=threads)

    elif choice == "2":
        try:
            url = input("\033[92m[?] Target URL: \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            return
        if url:
            screenshot_single(url, cfg)
