#!/usr/bin/env python3
"""
CIRCUIT+ — Mass Target Scanner  v1.1
Runs every available recon & intel technique against a single target
(IP, domain, or URL) and produces a structured report.

Phases:
  0. Target normalisation & basic resolution
  1. DNS  — A / AAAA / MX / TXT / NS / SOA / CNAME
  2. Whois — registrar, owner, dates, AS info
  3. GeoIP  — country, city, ISP, proxy/hosting flags
  4. HTTP   — status, headers, redirect chain, security headers
  5. SSL/TLS — cert validity, expiry, issuer, SANs, weak ciphers
  6. Tech   — CMS, framework, CDN, analytics fingerprint
  7. Ports  — top-25 TCP quick-check (pure Python, no tools needed)
  8. Subdomain enum — subfinder / passive only (fast, no bruteforce)
  9. Traceroute — network path (if traceroute/tracepath available)
 10. Shodan-style banner grab on open ports (via nmap -sV on found ports)
 11. CVE / vuln hints — match detected tech against known issue list

Output:
  • Colour-coded live Rich output as each phase runs
  • Structured dict saved to loot/{target}/massscan/report.json
  • Plain text summary saved to loot/{target}/massscan/report.txt
  • After completion: copy to clipboard OR save to chosen .txt file
"""
from __future__ import annotations

import json
import re
import shutil
import socket
import subprocess
import sys
import textwrap
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.rule import Rule
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import (
    is_valid_ip, is_valid_domain, normalize_url,
    make_loot_dir, timestamp,
)
from config import Config, append_history

# ══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class PhaseResult:
    name:    str
    ok:      bool   = True
    data:    dict   = field(default_factory=dict)
    lines:   list   = field(default_factory=list)   # human-readable summary lines
    skipped: bool   = False
    reason:  str    = ""


@dataclass
class MassScanReport:
    target_raw:  str
    target_host: str
    target_url:  str
    target_ip:   str
    started_at:  str
    finished_at: str   = ""
    phases:      list[PhaseResult] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "target":      self.target_raw,
            "host":        self.target_host,
            "url":         self.target_url,
            "ip":          self.target_ip,
            "started":     self.started_at,
            "finished":    self.finished_at,
            "phases":      [
                {
                    "name":    p.name,
                    "ok":      p.ok,
                    "skipped": p.skipped,
                    "data":    p.data,
                }
                for p in self.phases
            ],
        }

    def to_text(self) -> str:
        lines = [
            "=" * 72,
            f"  CIRCUIT+ Mass Scan Report",
            f"  Target  : {self.target_raw}",
            f"  Host    : {self.target_host}",
            f"  IP      : {self.target_ip}",
            f"  Started : {self.started_at}",
            f"  Finished: {self.finished_at}",
            "=" * 72,
            "",
        ]
        for phase in self.phases:
            lines.append(f"{'─' * 60}")
            status = "SKIP" if phase.skipped else ("OK" if phase.ok else "FAIL")
            lines.append(f"  [{status}]  {phase.name}")
            lines.append(f"{'─' * 60}")
            if phase.skipped:
                lines.append(f"  Skipped: {phase.reason}")
            else:
                for k, v in phase.data.items():
                    if isinstance(v, list):
                        lines.append(f"  {k}:")
                        for item in v[:30]:
                            lines.append(f"    {item}")
                        if len(v) > 30:
                            lines.append(f"    ... +{len(v)-30} more")
                    elif v:
                        lines.append(f"  {k}: {v}")
            lines.append("")
        return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
# INTERNALS
# ══════════════════════════════════════════════════════════════════════════════

def _run(cmd: list[str], timeout: int = 20) -> tuple[int, str, str]:
    """Run a command and return (rc, stdout, stderr)."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, errors="replace")
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "TIMEOUT"
    except FileNotFoundError:
        return 127, "", f"not found: {cmd[0]}"
    except Exception as e:
        return 1, "", str(e)


def _phase_header(n: int, total: int, name: str) -> None:
    console.print(
        f"\n[bold bright_green]┌─ Phase {n}/{total}:[/bold bright_green]"
        f" [white]{name}[/white]"
    )


def _kv(data: dict, key: str, label: str, color: str = "cyan") -> None:
    """Print a key-value pair if value is non-empty."""
    v = data.get(key, "")
    if v:
        console.print(f"  [bold {color}]{label:<22}[/bold {color}] {v}")


def _ok(msg: str) -> None:
    console.print(f"  [green]✓[/green] {msg}")


def _warn(msg: str) -> None:
    console.print(f"  [yellow]△[/yellow] {msg}")


def _skip(msg: str) -> None:
    console.print(f"  [dim]⊘  {msg}[/dim]")


# ══════════════════════════════════════════════════════════════════════════════
# PHASE IMPLEMENTATIONS
# ══════════════════════════════════════════════════════════════════════════════

def _phase_resolve(target_raw: str) -> tuple[str, str, str, str]:
    """
CIRCUIT+ — Mass Scan: 10-phase intel dump on any IP/domain/URL.
    """
    raw = target_raw.strip()

    # Strip scheme
    if raw.startswith(("http://", "https://")):
        protocol = "https" if raw.startswith("https") else "http"
        host = raw.split("//", 1)[1].split("/")[0].split(":")[0]
    else:
        host = raw.split("/")[0].split(":")[0]
        protocol = "https"

    base_url = f"{protocol}://{host}"

    # Resolve
    ip = ""
    try:
        ip = socket.gethostbyname(host)
    except socket.gaierror:
        if is_valid_ip(host):
            ip = host

    return host, base_url, ip, protocol


def _phase_dns(host: str) -> PhaseResult:
    """Phase 1 — DNS records."""
    p = PhaseResult("DNS Records")
    if not shutil.which("dig"):
        p.skipped = True
        p.reason  = "'dig' not in PATH (install dnsutils)"
        _skip(p.reason)
        return p

    rtypes = ["A", "AAAA", "MX", "TXT", "NS", "SOA", "CNAME"]
    for rtype in rtypes:
        rc, out, _ = _run(["dig", "+noall", "+answer", host, rtype], timeout=12)
        lines = [l.strip() for l in out.splitlines()
                 if l.strip() and not l.startswith(";")]
        if lines:
            p.data[rtype] = lines
            console.print(f"  [bold cyan]{rtype:<8}[/bold cyan] "
                          + "  ".join(l.split()[-1] for l in lines[:3]))
        else:
            p.data[rtype] = []
    p.lines = [f"{k}: {' | '.join(v[:3])}" for k, v in p.data.items() if v]
    return p


def _phase_whois(host: str) -> PhaseResult:
    """Phase 2 — Whois lookup."""
    p = PhaseResult("Whois")
    if not shutil.which("whois"):
        p.skipped = True; p.reason = "'whois' not in PATH"; _skip(p.reason); return p

    target = host if is_valid_ip(host) else host
    rc, out, err = _run(["whois", target], timeout=30)
    if rc != 0:
        p.ok = False; return p

    interesting = {
        "Registrant": r"Registrant(?:\s+Name)?:\s*(.+)",
        "Registrar":  r"Registrar:\s*(.+)",
        "Created":    r"(?:Creation Date|Created):\s*(.+)",
        "Expires":    r"(?:Registry Expiry Date|Expir).*?:\s*(.+)",
        "Updated":    r"Updated Date:\s*(.+)",
        "Name Server":r"Name Server:\s*(.+)",
        "CIDR":       r"CIDR:\s*(.+)",
        "Org":        r"(?:OrgName|Organisation|org-name):\s*(.+)",
        "Country":    r"(?:country|Country):\s*(.+)",
        "ASN":        r"(?:OriginAS|origin):\s*(.+)",
        "NetRange":   r"NetRange:\s*(.+)",
        "Admin Email":r"Admin Email:\s*(.+)",
    }

    for label, pattern in interesting.items():
        m = re.search(pattern, out, re.IGNORECASE)
        if m:
            val = m.group(1).strip()[:80]
            p.data[label] = val
            console.print(f"  [cyan]{label:<18}[/cyan] {val}")

    p.data["_raw_lines"] = len(out.splitlines())
    p.lines = [f"{k}: {v}" for k, v in p.data.items() if v and not k.startswith("_")]
    return p


def _phase_geoip(ip: str) -> PhaseResult:
    """Phase 3 — GeoIP / ASN lookup via ip-api.com."""
    p = PhaseResult("GeoIP / ASN")
    if not ip:
        p.skipped = True; p.reason = "IP not resolved"; _skip(p.reason); return p
    if not shutil.which("curl"):
        p.skipped = True; p.reason = "'curl' not in PATH"; _skip(p.reason); return p

    rc, out, _ = _run([
        "curl", "-s", "--max-time", "10",
        f"http://ip-api.com/json/{ip}?fields=status,country,regionName,city,"
        "isp,org,as,query,proxy,hosting,mobile,timezone",
    ], timeout=15)

    if rc != 0:
        p.ok = False; log_warn("GeoIP request failed."); return p

    try:
        geo = json.loads(out)
    except json.JSONDecodeError:
        p.ok = False; return p

    if geo.get("status") == "success":
        fields = [
            ("IP",       "query"),
            ("Country",  "country"),
            ("Region",   "regionName"),
            ("City",     "city"),
            ("Timezone", "timezone"),
            ("ISP",      "isp"),
            ("Org",      "org"),
            ("AS",       "as"),
        ]
        for label, key in fields:
            v = geo.get(key, "")
            if v:
                p.data[label] = str(v)
                console.print(f"  [cyan]{label:<18}[/cyan] {v}")

        flags = []
        if geo.get("proxy"):    flags.append("[yellow]PROXY/VPN[/yellow]")
        if geo.get("hosting"):  flags.append("[red]HOSTING/DC[/red]")
        if geo.get("mobile"):   flags.append("[blue]MOBILE[/blue]")
        if flags:
            p.data["Flags"] = " | ".join(f.replace("[yellow]","").replace("[/yellow]","")
                                         .replace("[red]","").replace("[/red]","")
                                         .replace("[blue]","").replace("[/blue]","")
                                         for f in flags)
            console.print(f"  [cyan]{'Flags':<18}[/cyan] " + "  ".join(flags))

    p.lines = [f"{k}: {v}" for k, v in p.data.items() if v]
    return p


def _phase_http(url: str) -> PhaseResult:
    """Phase 4 — HTTP headers, redirect chain, security headers."""
    p = PhaseResult("HTTP Headers")
    if not shutil.which("curl"):
        p.skipped = True; p.reason = "'curl' not in PATH"; _skip(p.reason); return p

    rc, out, err = _run([
        "curl", "-sIL", "--max-time", "15",
        "-A", "Mozilla/5.0 (compatible; CIRCUIT+/1.1)",
        "-D", "-",   # dump headers
        url,
    ], timeout=20)

    if rc != 0 and not out:
        p.ok = False
        log_warn(f"HTTP request failed: {err[:80]}")
        return p

    # Parse headers from possibly multi-hop response
    security_headers = {
        "strict-transport-security": ("HSTS", "green"),
        "content-security-policy":   ("CSP",  "green"),
        "x-frame-options":           ("X-Frame", "green"),
        "x-xss-protection":          ("XSS-Protect", "yellow"),
        "x-content-type-options":    ("No-Sniff", "green"),
        "referrer-policy":           ("Ref-Policy", "green"),
        "permissions-policy":        ("Perm-Policy", "green"),
    }
    missing_sec: list[str] = []
    found_sec:   list[str] = []

    status_code  = ""
    server       = ""
    powered_by   = ""
    location     = ""
    content_type = ""

    all_hdrs: list[str] = []
    for line in out.splitlines():
        line_s = line.strip()
        if not line_s:
            continue
        if line_s.startswith("HTTP/"):
            status_code = line_s
            console.print(f"  [bold]Status chain: [/bold][green]{line_s}[/green]")
        if ":" in line_s:
            k, _, v = line_s.partition(":")
            k_low = k.strip().lower()
            v_s   = v.strip()
            all_hdrs.append(f"{k.strip()}: {v_s}")
            if k_low == "server":        server       = v_s
            if k_low == "x-powered-by": powered_by   = v_s
            if k_low == "location":     location     = v_s
            if k_low == "content-type": content_type = v_s
            # Security header check
            if k_low in security_headers:
                label, _ = security_headers[k_low]
                found_sec.append(label)

    for k_low, (label, _) in security_headers.items():
        if label not in found_sec:
            missing_sec.append(label)

    p.data["Status"]         = status_code
    p.data["Server"]         = server
    p.data["X-Powered-By"]   = powered_by
    p.data["Location"]       = location
    p.data["Content-Type"]   = content_type
    p.data["Security Present"]  = found_sec
    p.data["Security Missing"]  = missing_sec
    p.data["All Headers"]    = all_hdrs

    if server:      console.print(f"  [cyan]{'Server':<18}[/cyan] {server}")
    if powered_by:  console.print(f"  [cyan]{'X-Powered-By':<18}[/cyan] {powered_by}")
    if found_sec:   _ok(f"Security headers present: {', '.join(found_sec)}")
    if missing_sec: _warn(f"Security headers missing: {', '.join(missing_sec)}")

    p.lines = [
        f"Status: {status_code}",
        f"Server: {server}",
        f"Security OK: {', '.join(found_sec) or 'none'}",
        f"Security MISSING: {', '.join(missing_sec) or 'none'}",
    ]
    return p


def _phase_ssl(host: str, port: int = 443) -> PhaseResult:
    """Phase 5 — SSL/TLS certificate info."""
    p = PhaseResult("SSL/TLS Certificate")
    if not shutil.which("openssl"):
        p.skipped = True; p.reason = "'openssl' not in PATH"; _skip(p.reason); return p

    # Try connection
    proc = subprocess.run(
        ["openssl", "s_client", "-connect", f"{host}:{port}",
         "-servername", host, "-showcerts"],
        input="", capture_output=True, text=True, timeout=15,
        errors="replace",
    )
    raw = proc.stdout + proc.stderr

    # Extract first cert
    cert_pem = ""
    if "-----BEGIN CERTIFICATE-----" in raw:
        start = raw.index("-----BEGIN CERTIFICATE-----")
        end   = raw.index("-----END CERTIFICATE-----") + len("-----END CERTIFICATE-----")
        cert_pem = raw[start:end]

    if not cert_pem:
        p.ok = False
        log_warn(f"No SSL certificate returned from {host}:{port}")
        return p

    # Parse with openssl x509
    proc2 = subprocess.run(
        ["openssl", "x509", "-noout", "-subject", "-issuer",
         "-dates", "-ext", "subjectAltName", "-fingerprint"],
        input=cert_pem, capture_output=True, text=True, timeout=10,
    )
    x509 = proc2.stdout

    for line in x509.splitlines():
        line = line.strip()
        if not line:
            continue
        if "=" in line and "DNS:" not in line:
            key, _, val = line.partition("=")
            k = key.strip().replace("notBefore","Valid From").replace("notAfter","Expires").replace("subject","Subject").replace("issuer","Issuer")
            console.print(f"  [cyan]{k:<22}[/cyan] {val.strip()}")
            p.data[k] = val.strip()
        elif "DNS:" in line:
            sans = [s.strip() for s in line.split(",") if "DNS:" in s]
            p.data["SANs"] = [s.replace("DNS:","") for s in sans]
            console.print(f"  [cyan]{'SANs':<22}[/cyan] {', '.join(p.data['SANs'][:6])}")

    # Expiry check
    expiry_str = p.data.get("Expires", "")
    if expiry_str:
        try:
            expiry = datetime.strptime(expiry_str.split(" GMT")[0].strip(),
                                       "%b %d %H:%M:%S %Y")
            days_left = (expiry - datetime.utcnow()).days
            if days_left < 30:
                _warn(f"Certificate expires in {days_left} days!")
                p.data["Days Until Expiry"] = days_left
            else:
                _ok(f"Certificate valid for {days_left} more days")
                p.data["Days Until Expiry"] = days_left
        except Exception:
            pass

    # Grab protocol/cipher line
    for line in raw.splitlines():
        if "Protocol" in line or "Cipher" in line:
            p.data[line.split(":")[0].strip()] = line.split(":",1)[-1].strip()

    p.lines = [f"{k}: {v}" for k, v in p.data.items() if v and k != "SANs"]
    if p.data.get("SANs"):
        p.lines.append(f"SANs: {', '.join(p.data['SANs'][:6])}")
    return p


def _phase_tech(url: str) -> PhaseResult:
    """Phase 6 — Technology fingerprinting."""
    p = PhaseResult("Tech Fingerprint")
    if not shutil.which("curl"):
        p.skipped = True; p.reason = "'curl' not in PATH"; _skip(p.reason); return p

    rc, hdrs, _ = _run(
        ["curl", "-sIL", "--max-time", "12",
         "-A", "Mozilla/5.0 (compatible; CIRCUIT+/1.1)", url], timeout=15)
    rc2, body, _ = _run(
        ["curl", "-sL", "--max-time", "12",
         "-A", "Mozilla/5.0 (compatible; CIRCUIT+/1.1)", url], timeout=15)

    combined = (hdrs + body).lower()

    # Signature database
    sigs: list[tuple[str, str, str]] = [
        # (keyword, tech_name, category)
        ("wp-content",        "WordPress",       "CMS"),
        ("wp-json",           "WordPress",       "CMS"),
        ("drupal",            "Drupal",          "CMS"),
        ("joomla",            "Joomla",          "CMS"),
        ("shopify",           "Shopify",         "E-Commerce"),
        ("magento",           "Magento",         "E-Commerce"),
        ("woocommerce",       "WooCommerce",     "E-Commerce"),
        ("squarespace",       "Squarespace",     "Website Builder"),
        ("wix.com",           "Wix",             "Website Builder"),
        ("webflow",           "Webflow",         "Website Builder"),
        ("ghost",             "Ghost",           "CMS"),
        ("laravel",           "Laravel",         "PHP Framework"),
        ("symfony",           "Symfony",         "PHP Framework"),
        ("django",            "Django",          "Python Framework"),
        ("flask",             "Flask",           "Python Framework"),
        ("express",           "Express.js",      "Node Framework"),
        ("next.js",           "Next.js",         "React Framework"),
        ("nuxt",              "Nuxt.js",         "Vue Framework"),
        ("react",             "React",           "Frontend"),
        ("angular",           "Angular",         "Frontend"),
        ("vue.js",            "Vue.js",          "Frontend"),
        ("jquery",            "jQuery",          "Frontend"),
        ("bootstrap",         "Bootstrap",       "CSS Framework"),
        ("tailwind",          "Tailwind CSS",    "CSS Framework"),
        ("cloudflare",        "Cloudflare",      "CDN/Proxy"),
        ("cdn.jsdelivr",      "jsDelivr CDN",    "CDN"),
        ("cdn.jsdelivr.net",  "jsDelivr CDN",    "CDN"),
        ("amazonaws.com",     "AWS",             "Cloud"),
        ("azure",             "Azure",           "Cloud"),
        ("googleusercontent", "Google Cloud",    "Cloud"),
        ("gtag(",             "Google Analytics","Analytics"),
        ("ga.js",             "Google Analytics","Analytics"),
        ("matomo",            "Matomo",          "Analytics"),
        ("recaptcha",         "Google reCAPTCHA","Security"),
        ("hcaptcha",          "hCaptcha",        "Security"),
        ("php",               "PHP",             "Language"),
        ("asp.net",           "ASP.NET",         "Language"),
        ("jsessionid",        "Java",            "Language"),
        ("apache",            "Apache",          "Web Server"),
        ("nginx",             "nginx",           "Web Server"),
        ("iis",               "IIS",             "Web Server"),
        ("litespeed",         "LiteSpeed",       "Web Server"),
        ("caddy",             "Caddy",           "Web Server"),
        ("cloudfront",        "AWS CloudFront",  "CDN"),
        ("fastly",            "Fastly",          "CDN"),
        ("akamai",            "Akamai",          "CDN"),
        ("font-awesome",      "Font Awesome",    "Assets"),
        ("intercom",          "Intercom",        "Chat"),
        ("zendesk",           "Zendesk",         "Support"),
        ("stripe.com/v3",     "Stripe",          "Payment"),
        ("paypal",            "PayPal",          "Payment"),
    ]

    found: dict[str, list[str]] = {}  # category → [tech names]
    for keyword, tech_name, category in sigs:
        if keyword in combined:
            found.setdefault(category, [])
            if tech_name not in found[category]:
                found[category].append(tech_name)

    if found:
        tbl = Table(box=box.SIMPLE_HEAVY, border_style="bright_green",
                    show_header=True, header_style="bold bright_green",
                    expand=False)
        tbl.add_column("Category", style="bold cyan",  width=18)
        tbl.add_column("Detected", style="white",      width=50)
        for i, (cat, techs) in enumerate(sorted(found.items())):
            tbl.add_row(cat, ", ".join(techs),
                        style="on grey11" if i % 2 == 0 else "")
        console.print(tbl)
        p.data = {cat: techs for cat, techs in found.items()}
    else:
        _warn("No known technology signatures detected.")

    all_tech = [t for techs in found.values() for t in techs]
    p.lines = [f"{cat}: {', '.join(techs)}" for cat, techs in found.items()]

    # CVE / advisory hints based on detected tech
    vuln_hints: list[str] = []
    tech_lower = " ".join(all_tech).lower()
    if "wordpress" in tech_lower:
        vuln_hints.append("WordPress: Check /wp-admin, xmlrpc.php, outdated plugins")
    if "drupal" in tech_lower:
        vuln_hints.append("Drupal: Drupalgeddon vulns SA-CORE-2018-002, -004")
    if "joomla" in tech_lower:
        vuln_hints.append("Joomla: Check /administrator, CVE-2015-8562 (RCE)")
    if "magento" in tech_lower:
        vuln_hints.append("Magento: SUPEE patches, /downloader, /admin paths")
    if "php" in tech_lower:
        vuln_hints.append("PHP: Test for phpinfo.php, php-fpm misconfig, LFI")
    if "apache" in tech_lower:
        vuln_hints.append("Apache: CVE-2021-41773 (path traversal), mod_status")
    if "nginx" in tech_lower:
        vuln_hints.append("nginx: Off-by-slash misconfig, merge_slashes bypass")
    if "iis" in tech_lower:
        vuln_hints.append("IIS: HTTP.sys vulns, /.aspx handlers, WebDAV")
    if vuln_hints:
        p.data["Vuln Hints"] = vuln_hints
        console.print()
        console.print("  [bold yellow]Vuln Hints:[/bold yellow]")
        for h in vuln_hints:
            console.print(f"    [yellow]⚑[/yellow] {h}")

    return p


def _phase_ports(host: str) -> PhaseResult:
    """Phase 7 — Quick TCP port check (pure Python, no tools needed)."""
    p = PhaseResult("Port Check (top-25)")
    top_ports = [
        21,22,23,25,53,80,110,135,139,143,443,445,
        993,995,1433,1521,3306,3389,5432,5900,6379,
        8080,8443,8888,27017,
    ]
    service_names = {
        21:"FTP",22:"SSH",23:"Telnet",25:"SMTP",53:"DNS",
        80:"HTTP",110:"POP3",135:"RPC",139:"NetBIOS",143:"IMAP",
        443:"HTTPS",445:"SMB",993:"IMAPS",995:"POP3S",1433:"MSSQL",
        1521:"Oracle",3306:"MySQL",3389:"RDP",5432:"PostgreSQL",
        5900:"VNC",6379:"Redis",8080:"HTTP-Alt",8443:"HTTPS-Alt",
        8888:"Alt",27017:"MongoDB",
    }

    open_ports:   list[int] = []
    closed_ports: list[int] = []

    with Progress(
        SpinnerColumn(style="bright_green"),
        TextColumn("[bright_green]Checking {task.description}"),
        TimeElapsedColumn(),
        console=console, transient=True,
    ) as prog:
        task = prog.add_task("ports...", total=len(top_ports))
        for port in top_ports:
            prog.update(task, description=f"port {port}...")
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1.5)
                rc = s.connect_ex((host, port))
                s.close()
                if rc == 0:
                    open_ports.append(port)
                else:
                    closed_ports.append(port)
            except Exception:
                closed_ports.append(port)
            prog.advance(task)

    tbl = Table(
        title=f"[bold bright_green]// Open Ports ({len(open_ports)} of {len(top_ports)})[/bold bright_green]",
        box=box.SIMPLE_HEAVY, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    tbl.add_column("Port",    width=7, justify="center")
    tbl.add_column("Service", width=14, style="cyan")
    tbl.add_column("Status",  width=10)

    for i, port in enumerate(sorted(open_ports)):
        tbl.add_row(str(port), service_names.get(port,"?"),
                    "[bold green]OPEN[/bold green]",
                    style="on grey11" if i % 2 == 0 else "")
    console.print(tbl)

    p.data["open"]   = open_ports
    p.data["closed"] = closed_ports
    p.lines = [
        f"Open: {', '.join(str(p) for p in open_ports) or 'none'}",
        f"Checked: {len(top_ports)} ports",
    ]
    return p


def _phase_subdomains(host: str, cfg: Config) -> PhaseResult:
    """Phase 8 — Passive subdomain enumeration (subfinder, no brute-force)."""
    p = PhaseResult("Subdomain Enumeration")
    if is_valid_ip(host):
        p.skipped = True; p.reason = "Target is an IP (no subdomains)"; _skip(p.reason); return p

    if not shutil.which("subfinder"):
        p.skipped = True; p.reason = "'subfinder' not in PATH (install via [7] Install Manager)"; _skip(p.reason); return p

    rc, out, _ = _run(
        ["subfinder", "-d", host, "-silent", "-timeout", "30"],
        timeout=60,
    )
    subs = [l.strip() for l in out.splitlines() if l.strip()]
    if subs:
        console.print(f"  [green]Found {len(subs)} subdomains[/green]")
        for s in subs[:20]:
            console.print(f"    [cyan]{s}[/cyan]")
        if len(subs) > 20:
            console.print(f"    [dim]... +{len(subs)-20} more[/dim]")
    else:
        _warn("No subdomains found via passive enum.")

    p.data["subdomains"] = subs
    p.data["count"]      = len(subs)
    p.lines = [f"Subdomains ({len(subs)}): " + ", ".join(subs[:10])]
    return p


def _phase_traceroute(host: str) -> PhaseResult:
    """Phase 9 — Traceroute (optional)."""
    p = PhaseResult("Traceroute")
    binary = next((b for b in ("traceroute", "tracepath") if shutil.which(b)), None)
    if not binary:
        p.skipped = True; p.reason = "'traceroute'/'tracepath' not in PATH"; _skip(p.reason); return p

    rc, out, _ = _run([binary, "-m", "20", host], timeout=45)
    hops = [l.strip() for l in out.splitlines() if l.strip()]
    for hop in hops:
        console.print(f"  [dim]{hop}[/dim]")

    p.data["hops"]       = hops
    p.data["hop_count"]  = len(hops)
    p.lines = [f"Hops: {len(hops)}"]
    return p


def _phase_banner_grab(host: str, open_ports: list[int]) -> PhaseResult:
    """Phase 10 — Service banner grab via nmap -sV on open ports."""
    p = PhaseResult("Service Banner Grab")
    if not open_ports:
        p.skipped = True; p.reason = "No open ports detected"; _skip(p.reason); return p
    if not shutil.which("nmap"):
        p.skipped = True; p.reason = "'nmap' not in PATH"; _skip(p.reason); return p

    ports_str = ",".join(str(port) for port in open_ports[:15])
    rc, out, _ = _run(
        ["nmap", "-sV", "--open", "-T4",
         "--version-intensity", "5",
         "-p", ports_str, host],
        timeout=90,
    )
    services: list[str] = []
    for line in out.splitlines():
        if "/tcp" in line or "/udp" in line:
            services.append(line.strip())
            console.print(f"  [cyan]{line.strip()}[/cyan]")

    p.data["services"] = services
    p.lines = services
    return p


# ══════════════════════════════════════════════════════════════════════════════
# OUTPUT / EXPORT
# ══════════════════════════════════════════════════════════════════════════════

def _copy_to_clipboard(text: str) -> bool:
    """
    Copy text to system clipboard.
    Tries xclip → xsel → wl-copy (Wayland) in order.
    """
    for cmd in (
        ["xclip",  "-selection", "clipboard"],
        ["xsel",   "--clipboard", "--input"],
        ["wl-copy"],
    ):
        if shutil.which(cmd[0]):
            try:
                proc = subprocess.run(cmd, input=text, text=True,
                                      capture_output=True, timeout=10)
                if proc.returncode == 0:
                    return True
            except Exception:
                pass
    return False


def _export_menu(report: MassScanReport, loot: Path) -> None:
    """
    Post-scan export menu — clipboard, save to file, or both.
    """
    text   = report.to_text()
    json_s = json.dumps(report.to_dict(), indent=2)

    console.print()
    console.print(Panel(
        "  [1] Copy plain-text summary to clipboard\n"
        "  [2] Copy JSON report to clipboard\n"
        "  [3] Save plain-text to a custom .txt file\n"
        "  [4] Save JSON to a custom .json file\n"
        "  [5] Do all of the above\n"
        "  [0] Skip — already saved to loot directory",
        title="[bold bright_green]// Export Results[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))
    console.print(f"  [dim]Auto-saved: {loot / 'report.txt'}[/dim]")

    try:
        choice = input("\033[92m  export> \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        return

    def _clip(content: str, label: str) -> None:
        if _copy_to_clipboard(content):
            log_ok(f"{label} copied to clipboard.")
        else:
            log_err("Clipboard copy failed. Install xclip: sudo apt install xclip")

    def _save_custom(content: str, ext: str) -> None:
        try:
            path = input(f"\033[92m[?] Save path [{loot}/custom_report{ext}]: \033[0m").strip()
            if not path:
                path = str(loot / f"custom_report{ext}")
            dest = Path(path)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content, encoding="utf-8")
            log_ok(f"Saved → {dest}")
        except (EOFError, KeyboardInterrupt, OSError) as e:
            log_err(f"Save failed: {e}")

    if choice == "1" or choice == "5":
        _clip(text, "Plain-text summary")
    if choice == "2" or choice == "5":
        _clip(json_s, "JSON report")
    if choice == "3" or choice == "5":
        _save_custom(text,   ".txt")
    if choice == "4" or choice == "5":
        _save_custom(json_s, ".json")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def run_massscan(target_raw: str, cfg: Config) -> Optional[MassScanReport]:
    """
    Run the full mass scan against a target (IP, domain, or URL).

    Args:
        target_raw: Raw user input — IP, domain, or full URL.
        cfg:        CIRCUIT+ Config.

    Returns:
        Completed MassScanReport or None on early abort.
    """
    # ── Phase 0: resolve & normalise ─────────────────────────────────────────
    host, base_url, ip, protocol = _phase_resolve(target_raw)

    if not host:
        log_err(f"Cannot parse target: {target_raw}")
        return None

    started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    loot = make_loot_dir(cfg.loot_path, host.replace(".", "_"), "massscan")

    report = MassScanReport(
        target_raw=target_raw,
        target_host=host,
        target_url=base_url,
        target_ip=ip,
        started_at=started,
    )

    # Banner
    console.print()
    console.print(Panel(
        f"  [bold white]Target[/bold white]  :  [cyan]{target_raw}[/cyan]\n"
        f"  [bold white]Host[/bold white]    :  [cyan]{host}[/cyan]\n"
        f"  [bold white]IP[/bold white]      :  [cyan]{ip or '(unresolved)'}[/cyan]\n"
        f"  [bold white]URL[/bold white]     :  [cyan]{base_url}[/cyan]\n"
        f"  [bold white]Loot[/bold white]    :  [dim]{loot}[/dim]\n\n"
        f"  [dim]Running 10 phases. Ctrl+C skips the current phase.[/dim]",
        title="[bold bright_green]// CIRCUIT+ — Mass Scan[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    # ── Phases ────────────────────────────────────────────────────────────────
    TOTAL = 10

    phases_to_run = [
        (1,  "DNS Records",          lambda: _phase_dns(host)),
        (2,  "Whois",                lambda: _phase_whois(host)),
        (3,  "GeoIP / ASN",          lambda: _phase_geoip(ip)),
        (4,  "HTTP Headers",         lambda: _phase_http(base_url)),
        (5,  "SSL/TLS Certificate",  lambda: _phase_ssl(host)),
        (6,  "Tech Fingerprint",     lambda: _phase_tech(base_url)),
        (7,  "Port Check",           lambda: _phase_ports(host)),
        (8,  "Subdomain Enum",       lambda: _phase_subdomains(host, cfg)),
        (9,  "Traceroute",           lambda: _phase_traceroute(host)),
        (10, "Service Banner Grab",  lambda: None),  # depends on phase 7
    ]

    port_phase_result: Optional[PhaseResult] = None

    for n, name, fn in phases_to_run:
        _phase_header(n, TOTAL, name)
        try:
            if n == 10:
                # Needs open ports from phase 7
                open_ports = port_phase_result.data.get("open", []) if port_phase_result else []
                result = _phase_banner_grab(host, open_ports)
            else:
                result = fn()

            if result is None:
                result = PhaseResult(name, skipped=True, reason="No result")

            if n == 7:
                port_phase_result = result

            report.phases.append(result)

        except KeyboardInterrupt:
            console.print(f"\n  [yellow][~] Phase {n} skipped (Ctrl+C)[/yellow]")
            report.phases.append(PhaseResult(name, skipped=True,
                                             reason="Skipped by user"))
        except Exception as exc:
            log_err(f"Phase {n} error: {exc}")
            report.phases.append(PhaseResult(name, ok=False,
                                             data={"error": str(exc)}))

    # ── Finalise ──────────────────────────────────────────────────────────────
    report.finished_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Save to loot
    try:
        (loot / "report.json").write_text(
            json.dumps(report.to_dict(), indent=2), encoding="utf-8")
        (loot / "report.txt").write_text(
            report.to_text(), encoding="utf-8")
    except OSError as e:
        log_warn(f"Could not save report: {e}")

    # ── Summary table ─────────────────────────────────────────────────────────
    console.print()
    console.print(Rule("[bold bright_green]// Scan Complete[/bold bright_green]",
                       style="bright_green"))

    stbl = Table(
        title=f"[bold bright_green]// Mass Scan Summary — {host}[/bold bright_green]",
        box=box.DOUBLE_EDGE, border_style="bright_green",
        header_style="bold bright_green", expand=False,
    )
    stbl.add_column("Phase",   style="bold cyan", width=24)
    stbl.add_column("Status",  width=10)
    stbl.add_column("Summary", style="dim",       width=50)

    for i, phase in enumerate(report.phases):
        if phase.skipped:
            status = "[dim]SKIP[/dim]"
        elif phase.ok:
            status = "[green]OK[/green]"
        else:
            status = "[red]FAIL[/red]"
        summary_line = phase.lines[0][:48] if phase.lines else phase.reason[:48]
        stbl.add_row(phase.name, status, summary_line,
                     style="on grey11" if i % 2 == 0 else "")

    console.print(stbl)
    log_ok(f"Reports saved to: {loot}")

    append_history({
        "ts": timestamp(), "action": "massscan",
        "target": target_raw, "host": host, "ip": ip,
        "phases": len(report.phases),
    })

    # ── Export menu ───────────────────────────────────────────────────────────
    _export_menu(report, loot)

    return report


# ══════════════════════════════════════════════════════════════════════════════
# INTERACTIVE MENU
# ══════════════════════════════════════════════════════════════════════════════

def run_massscan_menu(cfg: Config) -> None:
    """Interactive entry point for Mass Scan from the main menu."""
    console.print()
    console.print(Panel(
        "  Runs [bold]10 recon phases[/bold] against any IP, domain, or URL:\n\n"
        "  DNS · Whois · GeoIP · HTTP Headers · SSL/TLS\n"
        "  Tech Fingerprint · Port Check · Subdomains\n"
        "  Traceroute · Service Banner Grab\n\n"
        "  [dim]Results exported as JSON + TXT, with clipboard option.[/dim]",
        title="[bold bright_green]// Mass Scan[/bold bright_green]",
        border_style="bright_green",
        expand=False,
    ))

    while True:
        try:
            target = input("\033[92m[?] Target (IP / domain / URL, 0=back): \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            return

        if target in ("0", "back", ""):
            return

        # Minimal validation
        host = target.lstrip("https://").lstrip("http://").split("/")[0]
        if not (is_valid_ip(host) or is_valid_domain(host) or "." in host):
            log_err(f"'{target}' doesn't look like a valid IP, domain, or URL.")
            log_info("Examples: 192.168.1.1  |  example.com  |  https://target.io")
            continue

        run_massscan(target, cfg)

        try:
            again = input("\n\033[92m[?] Scan another target? [y/N]: \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return
        if again not in ("y", "yes"):
            return
