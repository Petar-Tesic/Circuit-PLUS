#!/usr/bin/env python3
"""
CIRCUIT+ — Plugin System: auto-load .py plugins from plugins/.
"""
from __future__ import annotations

import importlib.util
import sys
import traceback
from pathlib import Path
from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich import box

from utils.logger import console, log_ok, log_err, log_info, log_warn
from config import Config

# ── Plugin directory ──────────────────────────────────────────────────────────
PLUGINS_DIR = Path(__file__).parent.parent / "plugins"


# ── Plugin loader ─────────────────────────────────────────────────────────────

def _load_plugin(path: Path) -> Optional[dict[str, Any]]:
    """
    Load a single plugin file and return its metadata + module.

    Args:
        path: Path to the .py plugin file.

    Returns:
        Dict with name, desc, version, author, module — or None on error.
    """
    try:
        spec   = importlib.util.spec_from_file_location(path.stem, path)
        module = importlib.util.module_from_spec(spec)      # type: ignore
        spec.loader.exec_module(module)                      # type: ignore

        # Validate required attributes
        required = ("PLUGIN_NAME", "PLUGIN_DESC", "PLUGIN_VERSION",
                    "PLUGIN_AUTHOR")
        for attr in required:
            if not hasattr(module, attr):
                log_warn(f"Plugin {path.name} missing {attr} — skipped.")
                return None

        if not hasattr(module, "run") or not callable(module.run):
            log_warn(f"Plugin {path.name} has no run() function — skipped.")
            return None

        return {
            "name":    module.PLUGIN_NAME,
            "desc":    module.PLUGIN_DESC,
            "version": module.PLUGIN_VERSION,
            "author":  module.PLUGIN_AUTHOR,
            "module":  module,
            "file":    path.name,
        }
    except Exception as e:
        log_warn(f"Failed to load plugin {path.name}: {e}")
        return None


def discover_plugins() -> list[dict[str, Any]]:
    """
    Scan the plugins/ directory and return all valid plugins.

    Returns:
        List of plugin metadata dicts, sorted by name.
    """
    if not PLUGINS_DIR.exists():
        return []

    plugins: list[dict[str, Any]] = []
    for py_file in sorted(PLUGINS_DIR.glob("*.py")):
        if py_file.name.startswith("_"):
            continue
        plugin = _load_plugin(py_file)
        if plugin:
            plugins.append(plugin)

    return plugins


# ── Interactive menu ──────────────────────────────────────────────────────────

def run_plugin_menu(cfg: Config) -> None:
    """Interactive plugin browser and launcher."""
    plugins = discover_plugins()
    console.print()

    if not plugins:
        console.print(Panel(
            f"  No plugins found in [cyan]{PLUGINS_DIR}[/cyan]\n\n"
            "  To create a plugin:\n"
            "  1. Copy [cyan]plugins/example_plugin.py[/cyan] as a template\n"
            "  2. Set PLUGIN_NAME, PLUGIN_DESC, PLUGIN_VERSION, PLUGIN_AUTHOR\n"
            "  3. Implement [bold]run(cfg: Config) -> None[/bold]\n"
            "  4. Drop the .py file into the [cyan]plugins/[/cyan] directory\n"
            "  5. It appears here automatically — no registration needed.",
            title="[bold bright_green]// Plugin System[/bold bright_green]",
            border_style="bright_green", expand=False,
        ))
        return

    while True:
        console.print()
        tbl = Table(
            box=box.SIMPLE_HEAVY, border_style="bright_green",
            show_header=True, header_style="bold bright_green", expand=False,
        )
        tbl.add_column("#",       width=4,  justify="right", style="dim")
        tbl.add_column("Plugin",  width=30, style="bold cyan")
        tbl.add_column("Version", width=8,  style="dim")
        tbl.add_column("Author",  width=16, style="dim")
        tbl.add_column("Description", width=44, style="dim")

        for i, p in enumerate(plugins, 1):
            tbl.add_row(
                str(i), p["name"][:29], p["version"],
                p["author"][:15], p["desc"][:43],
                style="on grey11" if i % 2 == 0 else "",
            )

        console.print(Panel(
            tbl,
            title=f"[bold bright_green]// Plugins ({len(plugins)} loaded)[/bold bright_green]  "
                  f"[dim]{PLUGINS_DIR}[/dim]",
            border_style="bright_green", expand=False,
        ))
        console.print("  [cyan]<#>[/cyan] Run plugin    [cyan][r][/cyan] Reload    [cyan][0][/cyan] Back")

        try:
            cmd = input("\033[92m  plugins> \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd or cmd in ("0", "back"):
            break

        if cmd.lower() == "r":
            plugins = discover_plugins()
            log_ok(f"Reloaded — {len(plugins)} plugin(s) found.")
            continue

        if cmd.isdigit():
            idx = int(cmd) - 1
            if 0 <= idx < len(plugins):
                plugin = plugins[idx]
                log_info(f"Running plugin: {plugin['name']} v{plugin['version']}")
                try:
                    plugin["module"].run(cfg)
                except KeyboardInterrupt:
                    console.print("\n[yellow][~] Plugin interrupted.[/yellow]")
                except Exception as exc:
                    log_err(f"Plugin error: {exc}")
                    traceback.print_exc()
            else:
                log_warn(f"No plugin #{cmd}")
        else:
            log_warn(f"Unknown: {cmd}")
