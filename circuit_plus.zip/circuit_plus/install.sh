#!/usr/bin/env bash
# ============================================================
#  CIRCUIT+ — Installer
#  Detects distro, installs Python deps & security tooling
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()    { echo -e "${CYAN}[*] $1${NC}"; }
success() { echo -e "${GREEN}[+] $1${NC}"; }
warn()    { echo -e "${YELLOW}[!] $1${NC}"; }
error()   { echo -e "${RED}[X] $1${NC}"; exit 1; }

if [[ "$(uname -s)" != "Linux" ]]; then
    error "CIRCUIT+ requires Linux. Detected: $(uname -s)"
fi

PYTHON=$(command -v python3.11 || command -v python3.10 || command -v python3 || true)
if [[ -z "$PYTHON" ]]; then
    error "Python 3.10+ not found."
fi

PY_VERSION=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PY_MAJOR=$(echo "$PY_VERSION" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VERSION" | cut -d. -f2)

if [[ "$PY_MAJOR" -lt 3 || ("$PY_MAJOR" -eq 3 && "$PY_MINOR" -lt 10) ]]; then
    error "Python 3.10+ required. Found: $PY_VERSION"
fi
success "Python $PY_VERSION at $PYTHON"

detect_distro() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        echo "${ID_LIKE:-$ID}"
    elif command -v lsb_release &>/dev/null; then
        lsb_release -si | tr '[:upper:]' '[:lower:]'
    else
        echo "unknown"
    fi
}

DISTRO=$(detect_distro)
info "Distro family: $DISTRO"

install_pkg() {
    # Accepts one or more package names
    case "$DISTRO" in
        *debian*|*ubuntu*|*kali*|*parrot*|*mint*)
            sudo apt-get install -y "$@" 2>/dev/null || warn "apt: could not install $*";;
        *arch*|*manjaro*|*blackarch*)
            sudo pacman -S --noconfirm "$@" 2>/dev/null || warn "pacman: could not install $*";;
        *fedora*|*rhel*|*centos*)
            sudo dnf install -y "$@" 2>/dev/null || warn "dnf: could not install $*";;
        *opensuse*|*suse*)
            sudo zypper install -y "$@" 2>/dev/null || warn "zypper: could not install $*";;
        *)
            warn "Unknown distro. Install '$*' manually.";;
    esac
}

info "Checking system dependencies..."
for dep in python3-pip python3-venv nmap masscan curl wget git; do
    if ! dpkg -l "$dep" &>/dev/null && ! rpm -q "$dep" &>/dev/null && ! pacman -Q "$dep" &>/dev/null 2>&1; then
        info "Installing $dep..."
        install_pkg "$dep"
    else
        success "$dep present"
    fi
done

install_go_tools() {
    if ! command -v go &>/dev/null; then
        warn "Go not found. Attempting install..."
        case "$DISTRO" in
            *debian*|*ubuntu*|*kali*|*parrot*) sudo apt-get install -y golang-go 2>/dev/null || true;;
            *arch*|*manjaro*) sudo pacman -S --noconfirm go 2>/dev/null || true;;
            *fedora*) sudo dnf install -y golang 2>/dev/null || true;;
        esac
    fi

    if command -v go &>/dev/null; then
        success "Go $(go version | awk '{print $3}') found"
        export GOPATH="$HOME/go"
        export PATH="$PATH:$GOPATH/bin"

        declare -A GO_TOOLS=(
            [subfinder]="github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
            [httpx]="github.com/projectdiscovery/httpx/cmd/httpx@latest"
            [dnsx]="github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
            [nuclei]="github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
            [katana]="github.com/projectdiscovery/katana/cmd/katana@latest"
            [naabu]="github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"
            [alterx]="github.com/projectdiscovery/alterx/cmd/alterx@latest"
            [ffuf]="github.com/ffuf/ffuf/v2@latest"
            [gau]="github.com/lc/gau/v2/cmd/gau@latest"
        )

        for tool in "${!GO_TOOLS[@]}"; do
            if command -v "$tool" &>/dev/null; then
                success "$tool already installed"
            else
                read -rp "[?] Install $tool? [Y/n]: " ans
                ans="${ans:-Y}"
                if [[ "$ans" =~ ^[Yy]$ ]]; then
                    go install "${GO_TOOLS[$tool]}" 2>/dev/null && success "$tool installed" || warn "Failed: $tool"
                fi
            fi
        done
    else
        warn "Go unavailable. Install from https://go.dev/doc/install"
    fi
}

install_rustscan() {
    if command -v rustscan &>/dev/null; then
        success "rustscan present"; return
    fi
    read -rp "[?] Install rustscan? [Y/n]: " ans
    ans="${ans:-Y}"
    if [[ "$ans" =~ ^[Yy]$ ]]; then
        if command -v cargo &>/dev/null; then
            cargo install rustscan && success "rustscan installed"
        else
            LATEST=$(curl -s https://api.github.com/repos/RustScan/RustScan/releases/latest | grep tag_name | cut -d'"' -f4)
            URL="https://github.com/RustScan/RustScan/releases/download/${LATEST}/rustscan_${LATEST//v/}_amd64.deb"
            if command -v dpkg &>/dev/null; then
                TMP=$(mktemp /tmp/rustscan.XXXXXX.deb)
                curl -sL "$URL" -o "$TMP" && sudo dpkg -i "$TMP" && success "rustscan installed"
                rm -f "$TMP"
            else
                warn "Install rustscan from: https://github.com/RustScan/RustScan/releases"
            fi
        fi
    fi
}

echo ""
echo -e "${GREEN}"
cat << 'BANNER'
   ██████╗██╗██████╗  ██████╗██╗   ██╗██╗████████╗ ██╗
  ██╔════╝██║██╔══██╗██╔════╝██║   ██║██║╚══██╔══╝ ╚═╝
  ██║     ██║██████╔╝██║     ██║   ██║██║   ██║
  ██║     ██║██╔══██╗██║     ██║   ██║██║   ██║
  ╚██████╗██║██║  ██║╚██████╗╚██████╔╝██║   ██║  ██╗
   ╚═════╝╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝   ╚═╝  ╚═╝
  CIRCUIT+ v1.1 — Installer
BANNER
echo -e "${NC}"

info "Installing Python packages..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Read packages from requirements.txt ─────────────────────────────────────
REQS_FILE="$SCRIPT_DIR/requirements.txt"
PYPI_PKGS=()
while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -z "$line" || "$line" == \#* ]] && continue
    PYPI_PKGS+=("$line")
done < "$REQS_FILE"

# Map PyPI names → distro package names
declare -A DISTRO_PKG_MAP_APT=(
    ["rich"]="python3-rich"
    ["pydantic"]="python3-pydantic"
    ["platformdirs"]="python3-platformdirs"
    ["requests"]="python3-requests"
)
declare -A DISTRO_PKG_MAP_DNF=(
    ["rich"]="python3-rich"
    ["pydantic"]="python3-pydantic"
    ["platformdirs"]="python3-platformdirs"
    ["requests"]="python3-requests"
)
declare -A DISTRO_PKG_MAP_PAC=(
    ["rich"]="python-rich"
    ["pydantic"]="python-pydantic"
    ["platformdirs"]="python-platformdirs"
    ["requests"]="python-requests"
)

get_distro_pkg() {
    # get_distro_pkg <pypi_name>  → prints distro package name
    local name
    name=$(echo "$1" | sed 's/[><=].*//')   # strip version specifier
    case "$DISTRO" in
        *debian*|*ubuntu*|*kali*|*parrot*|*mint*)
            echo "${DISTRO_PKG_MAP_APT[$name]:-python3-$name}" ;;
        *fedora*|*rhel*|*centos*)
            echo "${DISTRO_PKG_MAP_DNF[$name]:-python3-$name}" ;;
        *arch*|*manjaro*|*blackarch*)
            echo "${DISTRO_PKG_MAP_PAC[$name]:-python-$name}" ;;
        *opensuse*|*suse*)
            echo "python3-$name" ;;
        *)
            echo "python3-$name" ;;
    esac
}

INSTALLED_VIA=""

# ── Strategy 1: plain pip ────────────────────────────────────────────────────
info "Strategy 1 — pip install (standard)..."
PIP_OUT=$("$PYTHON" -m pip install --quiet "${PYPI_PKGS[@]}" 2>&1)
PIP_RC=$?

if [[ $PIP_RC -eq 0 ]]; then
    success "Python packages installed via pip."
    INSTALLED_VIA="pip"

# ── Strategy 2: PEP 668 / externally-managed detected ───────────────────────
elif echo "$PIP_OUT" | grep -qiE "externally.managed|pep.668|break-system-packages|external.*managed"; then
    echo ""
    warn "Detected: externally-managed Python environment (PEP 668)"
    warn "Your OS locks system pip to prevent breaking OS packages."
    echo -e "${CYAN}    → Will try 3 fallback strategies automatically.${NC}"
    echo ""

    # Strategy 2a: system package manager
    info "Strategy 2a — Install via system package manager (${DISTRO})..."
    SYS_PKGS=()
    for pkg in "${PYPI_PKGS[@]}"; do
        SYS_PKGS+=("$(get_distro_pkg "$pkg")")
    done

    SYS_INSTALL_OK=false
    if install_pkg "${SYS_PKGS[@]}" 2>/dev/null; then
        # Verify the key imports actually work now
        if "$PYTHON" -c "import rich, pydantic, platformdirs, requests" 2>/dev/null; then
            success "Python packages installed via system package manager."
            INSTALLED_VIA="system"
            SYS_INSTALL_OK=true
        else
            warn "System packages installed but imports still failing (may need different package names)."
        fi
    else
        warn "System package manager install failed or packages not in repos."
    fi

    # Strategy 2b: pip --break-system-packages
    if [[ -z "$INSTALLED_VIA" ]]; then
        info "Strategy 2b — pip with --break-system-packages..."
        if "$PYTHON" -m pip install --quiet --break-system-packages "${PYPI_PKGS[@]}" 2>/dev/null; then
            success "Packages installed via pip --break-system-packages."
            INSTALLED_VIA="pip-bsp"
        else
            warn "--break-system-packages failed (may need sudo or is restricted)."
        fi
    fi

    # Strategy 2c: virtual environment
    if [[ -z "$INSTALLED_VIA" ]]; then
        VENV_DIR="${HOME}/.local/share/circuit_plus/venv"
        echo ""
        info "Strategy 2c — Create virtual environment at ${VENV_DIR}..."
        read -rp "$(echo -e ${YELLOW}[?]${NC} Create venv and install there? [Y/n]: )" VENV_ANS
        VENV_ANS="${VENV_ANS:-Y}"

        if [[ "$VENV_ANS" =~ ^[Yy]$ ]]; then
            # Ensure venv module is available
            case "$DISTRO" in
                *debian*|*ubuntu*|*kali*|*parrot*|*mint*)
                    sudo apt-get install -y python3-venv python3-full 2>/dev/null || true ;;
                *fedora*|*rhel*|*centos*)
                    sudo dnf install -y python3-virtualenv 2>/dev/null || true ;;
                *arch*|*manjaro*|*blackarch*)
                    sudo pacman -S --noconfirm python-virtualenv 2>/dev/null || true ;;
            esac

            mkdir -p "$(dirname "$VENV_DIR")"
            if "$PYTHON" -m venv "$VENV_DIR"; then
                if "${VENV_DIR}/bin/pip" install --quiet "${PYPI_PKGS[@]}"; then
                    success "Packages installed in venv: ${VENV_DIR}"
                    INSTALLED_VIA="venv"

                    # Create run.sh wrapper so user doesn't have to remember venv path
                    cat > "$SCRIPT_DIR/run.sh" << RUNWRAP
#!/usr/bin/env bash
# Auto-generated by install.sh — launches CIRCUIT+ inside its venv
exec "${VENV_DIR}/bin/python3" "\$(dirname "\$(realpath "\$0")")/main.py" "\$@"
RUNWRAP
                    chmod +x "$SCRIPT_DIR/run.sh"

                    echo ""
                    echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
                    echo -e "${GREEN}║  venv created. Use one of these to launch CIRCUIT+:  ║${NC}"
                    echo -e "${GREEN}║                                                      ║${NC}"
                    echo -e "${GREEN}║  ${CYAN}bash run.sh${GREEN}                (recommended)            ║${NC}"
                    echo -e "${GREEN}║  ${CYAN}${VENV_DIR}/bin/python3 main.py${GREEN}  ║${NC}"
                    echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
                    echo ""
                else
                    warn "pip install inside venv failed."
                fi
            else
                warn "Failed to create venv."
                warn "Try manually: sudo apt install python3-venv python3-full"
            fi
        fi
    fi

    # Final failure — print all manual options
    if [[ -z "$INSTALLED_VIA" ]]; then
        echo ""
        error_no_exit() { echo -e "${RED}[X] $1${NC}"; }
        error_no_exit "All strategies failed. Install manually using one of:"
        echo ""
        echo -e "  ${GREEN}[A] System packages:${NC}"
        for pkg in "${PYPI_PKGS[@]}"; do
            dpkg_name=$(get_distro_pkg "$pkg")
            echo -e "      sudo apt install ${dpkg_name}   (or dnf/pacman equivalent)"
        done
        echo ""
        echo -e "  ${GREEN}[B] Force pip (at your own risk):${NC}"
        echo -e "      pip install --break-system-packages ${PYPI_PKGS[*]}"
        echo ""
        echo -e "  ${GREEN}[C] Virtual environment (safest):${NC}"
        echo -e "      python3 -m venv ~/.circuit-venv"
        echo -e "      ~/.circuit-venv/bin/pip install ${PYPI_PKGS[*]}"
        echo -e "      ~/.circuit-venv/bin/python3 main.py"
        echo ""
        exit 1
    fi

else
    # Non-PEP668 pip failure
    echo ""
    warn "pip output: $PIP_OUT"
    error "pip install failed for unknown reason. Check the output above."
fi

read -rp "[?] Install Go-based tools (subfinder, httpx, nuclei...)? [Y/n]: " go_ans
[[ "${go_ans:-Y}" =~ ^[Yy]$ ]] && install_go_tools

read -rp "[?] Install RustScan? [Y/n]: " rust_ans
[[ "${rust_ans:-Y}" =~ ^[Yy]$ ]] && install_rustscan

echo ""
success "Done! Run: python3 main.py"
