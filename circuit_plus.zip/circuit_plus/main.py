#!/usr/bin/env python3
"""
CIRCUIT+ — Main Entry Point
Startup sequence, first-run wizard, and main interactive loop.

  ███████╗███████╗ ██████╗  ██████╗██╗███████╗████████╗██╗   ██╗
  ██╔════╝██╔════╝██╔═══██╗██╔════╝██║██╔════╝╚══██╔══╝╚██╗ ██╔╝
  █████╗  ███████╗██║   ██║██║     ██║█████╗     ██║    ╚████╔╝
  ██╔══╝  ╚════██║██║   ██║██║     ██║██╔══╝     ██║     ╚██╔╝
  ██║     ███████║╚██████╔╝╚██████╗██║███████╗   ██║      ██║
  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝╚═╝╚══════╝   ╚═╝      ╚═╝

  AUTHORIZED USE ONLY — Penetration Testing Framework
"""
from __future__ import annotations

import os
import sys
import json
import platform
from pathlib import Path

# ── Enforce Linux ─────────────────────────────────────────────────────────────
if platform.system() != "Linux":
    print(f"\n[!] CIRCUIT+ requires Linux. Detected: {platform.system()}")
    print("    Exiting.\n")
    sys.exit(1)

# ── Enforce Python 3.10+ ──────────────────────────────────────────────────────
if sys.version_info < (3, 10):
    print(f"\n[!] Python 3.10+ required. Found: {sys.version}")
    print("    Run: sudo apt install python3.11  |  sudo dnf install python3.11")
    sys.exit(1)

# ── Dependency check before any rich imports ──────────────────────────────────
def _check_python_deps() -> None:
    """Verify Rich, Pydantic, platformdirs are installed. Offer to install if missing."""
    missing: list[str] = []
    for pkg, import_name in [
        ("rich",         "rich"),
        ("pydantic",     "pydantic"),
        ("platformdirs", "platformdirs"),
        ("requests",     "requests"),
    ]:
        try:
            __import__(import_name)
        except ImportError:
            missing.append(pkg)

    if not missing:
        return

    print(f"\n[!] Missing Python packages: {', '.join(missing)}")
    try:
        ans = input("[?] Install them now? [Y/n]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = "n"

    if ans not in ("", "y", "yes"):
        print("[!] Cannot proceed without required packages.")
        sys.exit(1)

    import subprocess

    # ── Detect distro package manager ────────────────────────────────────────
    def _detect_pkg_manager() -> tuple[str, str]:
        """Return (manager_name, install_command_prefix)."""
        import shutil
        if shutil.which("apt-get"):
            return ("apt", "sudo apt-get install -y")
        if shutil.which("dnf"):
            return ("dnf", "sudo dnf install -y")
        if shutil.which("pacman"):
            return ("pacman", "sudo pacman -S --noconfirm")
        if shutil.which("zypper"):
            return ("zypper", "sudo zypper install -y")
        return ("unknown", "")

    # Map PyPI package names → distro package names (apt/dnf/pacman)
    _DISTRO_PKG_MAP: dict[str, dict[str, str]] = {
        "rich":         {"apt": "python3-rich",        "dnf": "python3-rich",        "pacman": "python-rich",        "zypper": "python3-rich"},
        "pydantic":     {"apt": "python3-pydantic",    "dnf": "python3-pydantic",    "pacman": "python-pydantic",    "zypper": "python3-pydantic"},
        "platformdirs": {"apt": "python3-platformdirs","dnf": "python3-platformdirs","pacman": "python-platformdirs","zypper": "python3-platformdirs"},
        "requests":     {"apt": "python3-requests",    "dnf": "python3-requests",    "pacman": "python-requests",    "zypper": "python3-requests"},
    }

    def _is_externally_managed(stderr: str, stdout: str) -> bool:
        """Detect PEP 668 / externally-managed-environment error."""
        combined = (stderr + stdout).lower()
        return any(phrase in combined for phrase in [
            "externally-managed-environment",
            "externally managed",
            "pep 668",
            "break-system-packages",
            "external managed",
        ])

    def _try_pip(pkgs: list[str], extra_flags: list[str] = []) -> tuple[bool, str, str]:
        """Attempt pip install. Returns (success, stdout, stderr)."""
        cmd = [sys.executable, "-m", "pip", "install", "--quiet"] + extra_flags + pkgs
        print(f"  $ {' '.join(cmd)}")
        r = subprocess.run(cmd, capture_output=True, text=True)
        return r.returncode == 0, r.stdout, r.stderr

    def _try_system_pkg_manager(pkgs: list[str], mgr: str, install_cmd: str) -> bool:
        """Attempt installation via distro package manager."""
        distro_pkgs = [_DISTRO_PKG_MAP.get(p, {}).get(mgr, "") for p in pkgs]
        distro_pkgs = [p for p in distro_pkgs if p]  # drop unmapped
        if not distro_pkgs:
            return False
        cmd_str = f"{install_cmd} {' '.join(distro_pkgs)}"
        print(f"\n[*] Trying system package manager...")
        print(f"  $ {cmd_str}")
        r = subprocess.run(cmd_str, shell=True)
        return r.returncode == 0

    def _try_venv(pkgs: list[str]) -> None:
        """
CIRCUIT+ — Entry point, startup sequence, and main menu routing.
        """
        venv_path = Path.home() / ".local" / "share" / "circuit_plus" / "venv"
        print(f"\n[*] Creating virtual environment at: {venv_path}")
        venv_path.parent.mkdir(parents=True, exist_ok=True)

        r = subprocess.run([sys.executable, "-m", "venv", str(venv_path)])
        if r.returncode != 0:
            print("[!] Failed to create venv. Try: sudo apt install python3-venv python3-full")
            sys.exit(1)

        venv_python = venv_path / "bin" / "python3"
        venv_pip    = venv_path / "bin" / "pip"

        print(f"[*] Installing packages into venv...")
        r2 = subprocess.run([str(venv_pip), "install", "--quiet"] + pkgs)
        if r2.returncode != 0:
            print(f"[!] venv pip install failed.")
            sys.exit(1)

        print(f"[+] Packages installed in venv.")
        print(f"[*] Re-launching CIRCUIT+ inside venv Python...\n")
        os.execv(str(venv_python), [str(venv_python)] + sys.argv)

    # ── Installation strategy cascade ────────────────────────────────────────
    # Step 1: plain pip
    print("\n[*] Attempting pip install...")
    ok, stdout, stderr = _try_pip(missing)
    if ok:
        print("[+] Packages installed via pip. Restarting...")
        os.execv(sys.executable, [sys.executable] + sys.argv)

    # Step 2: detected externally-managed-environment → try system pkg manager first
    if _is_externally_managed(stderr, stdout):
        print("\n[~] Detected: externally-managed Python environment (PEP 668).")
        print("    System pip is locked to prevent breaking your OS packages.")

        mgr, install_cmd = _detect_pkg_manager()

        if mgr != "unknown":
            print(f"\n[*] Strategy 1 — Install via system package manager ({mgr})...")
            if _try_system_pkg_manager(missing, mgr, install_cmd):
                # Re-check if imports now work
                still_missing = []
                for pkg, imp in [("rich","rich"),("pydantic","pydantic"),
                                  ("platformdirs","platformdirs"),("requests","requests")]:
                    try:
                        __import__(imp)
                    except ImportError:
                        if pkg in missing:
                            still_missing.append(pkg)

                if not still_missing:
                    print("[+] All packages installed via system manager. Restarting...")
                    os.execv(sys.executable, [sys.executable] + sys.argv)
                else:
                    print(f"[~] Still missing after system install: {still_missing}")
                    missing[:] = still_missing  # update for venv fallback

        # Step 3: pip --break-system-packages (last resort before venv)
        print("\n[*] Strategy 2 — pip with --break-system-packages flag...")
        ok2, stdout2, stderr2 = _try_pip(missing, ["--break-system-packages"])
        if ok2:
            print("[+] Packages installed (--break-system-packages). Restarting...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
        else:
            print("[~] --break-system-packages also failed (may need sudo or is restricted).")

        # Step 4: virtual environment fallback
        print("\n[*] Strategy 3 — Creating a virtual environment (safest option)...")
        try:
            ans2 = input("[?] Create venv at ~/.local/share/circuit_plus/venv ? [Y/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            ans2 = "y"
        if ans2 in ("", "y", "yes"):
            _try_venv(missing)
        else:
            _print_manual_install_help(missing, mgr, install_cmd)
            sys.exit(1)

    else:
        # Non-PEP668 pip failure — print help and exit
        print(f"\n[!] pip install failed for unknown reason.")
        mgr, install_cmd = _detect_pkg_manager()
        _print_manual_install_help(missing, mgr, install_cmd)
        sys.exit(1)


def _print_manual_install_help(pkgs: list[str], mgr: str, install_cmd: str) -> None:
    """Print manual install instructions for each strategy."""
    print("\n── Manual Install Options ──────────────────────────────────")

    # Option A: system packages
    if mgr == "apt":
        apt_pkgs = " ".join(f"python3-{p}" for p in pkgs)
        print(f"  [A] System packages:  sudo apt install {apt_pkgs}")
    elif mgr == "dnf":
        dnf_pkgs = " ".join(f"python3-{p}" for p in pkgs)
        print(f"  [A] System packages:  sudo dnf install {dnf_pkgs}")
    elif mgr == "pacman":
        pac_pkgs = " ".join(f"python-{p}" for p in pkgs)
        print(f"  [A] System packages:  sudo pacman -S {pac_pkgs}")

    # Option B: venv
    print(f"  [B] Virtual env:      python3 -m venv ~/.circuit-venv")
    print(f"                        ~/.circuit-venv/bin/pip install {' '.join(pkgs)}")
    print(f"                        ~/.circuit-venv/bin/python3 main.py")

    # Option C: pipx (for end-user tools)
    print(f"  [C] Force pip:        pip install --break-system-packages {' '.join(pkgs)}")
    print("────────────────────────────────────────────────────────────\n")


_check_python_deps()

# ── Safe imports (after dep check) ───────────────────────────────────────────
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt
from rich import box

from config import (
    Config, load_config, save_config, config_exists,
    ensure_dirs, append_history, CONFIG_FILE, HISTORY_FILE, _cfg_to_dict, update_config
)
from ui.effects import clear_screen, typewriter_line, glitch_effect, pause, press_enter
from ui.banner import print_banner, print_mini_banner, print_separator
from ui.menus import show_main_menu, get_choice, divider, section_header, show_section_a, show_section_b, show_section_c, show_section_d
from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import timestamp, human_timestamp

# ── Setup Wizard (first run + wordlist check) ────────────────────────────────

_FIRST_RUN_LOGO = r"""
  ███████╗███████╗ ██████╗  ██████╗██╗███████╗████████╗██╗   ██╗
  ██╔════╝██╔════╝██╔═══██╗██╔════╝██║██╔════╝╚══██╔══╝╚██╗ ██╔╝
  █████╗  ███████╗██║   ██║██║     ██║█████╗     ██║    ╚████╔╝
  ██╔══╝  ╚════██║██║   ██║██║     ██║██╔══╝     ██║     ╚██╔╝
  ██║     ███████║╚██████╔╝╚██████╗██║███████╗   ██║      ██║
  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝╚═╝╚══════╝   ╚═╝      ╚═╝"""


def _wizard_step(num: int, total: int, title: str, subtitle: str = "") -> None:
    """Print a wizard step header."""
    from rich.panel import Panel as _Panel
    sub = f"\n  [dim]{subtitle}[/dim]" if subtitle else ""
    console.print()
    console.print(_Panel(
        f"  [bold bright_green]Step {num} of {total}:[/bold bright_green] "
        f"[white]{title}[/white]{sub}",
        border_style="bright_green",
        expand=False,
    ))


def _wizard_done(label: str, value: str) -> None:
    """Print a confirmed wizard value."""
    console.print(f"  [green]✓[/green] [dim]{label}:[/dim] [cyan]{value}[/cyan]")


def _pick_operator_name() -> str:
    """Wizard step: choose operator alias."""
    _wizard_step(1, 5, "Operator Alias",
                 "Your callsign — shown in greetings and reports.")
    try:
        name = input("\033[92m  Enter alias [operator]: \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        name = ""
    return name or "operator"


def _pick_wordlist_dir(default: str) -> str:
    """
    Wizard step: choose wordlist directory.
    This is REQUIRED — loops until a valid directory is set or user downloads one.
    """
    from utils.picker import pick_directory, get_backend, backend_label
    from modules.installer import _run_live

    _wizard_step(2, 5, "Wordlist Directory  [REQUIRED]",
                 "CIRCUIT+ needs a wordlist directory to run web fuzzing & DNS brute-force.\n"
                 "  Recommended: download SecLists (~450 MB) or point to an existing collection.")

    while True:
        console.print(
            f"\n  [bold cyan]Options:[/bold cyan]\n"
            f"  [1] Pick existing directory  ({backend_label()})\n"
            f"  [2] Download SecLists now    (~450 MB, git clone)\n"
            f"  [3] Use default path         ({default})\n"
            f"  [0] Skip for now             (some features will be limited)"
        )
        try:
            choice = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
        except (EOFError, KeyboardInterrupt):
            choice = "0"

        if choice == "0":
            console.print("  [yellow][~] Wordlist skipped — web fuzzing and DNS brute-force will prompt you later.[/yellow]")
            return default

        elif choice == "3":
            Path(default).mkdir(parents=True, exist_ok=True)
            _wizard_done("Wordlist dir", default)
            return default

        elif choice == "2":
            dest = Path(default) / "SecLists"
            console.print(f"\n  [*] Cloning SecLists → {dest}")
            try:
                Path(default).mkdir(parents=True, exist_ok=True)
                ok = _run_live(
                    f"git clone --depth 1 https://github.com/danielmiessler/SecLists.git {dest}",
                    "Download SecLists"
                )
                if ok:
                    _wizard_done("Wordlist dir", default)
                    return default
                else:
                    console.print("  [red][!] Clone failed. Check your internet connection.[/red]")
            except KeyboardInterrupt:
                console.print("  [yellow][~] Download cancelled.[/yellow]")

        elif choice == "1":
            result = pick_directory(
                title="Select Wordlist Directory",
                label="Wordlist directory",
                initial_dir=default,
                must_exist=True,
                default=default,
            )
            if result and Path(result).is_dir():
                _wizard_done("Wordlist dir", result)
                return result
            elif result:
                console.print(f"  [red][!] Not a valid directory: {result}[/red]")
            else:
                console.print("  [dim]  Cancelled.[/dim]")

        else:
            console.print(f"  [red][!] Invalid choice: {choice}[/red]")


def _pick_default_wordlist(wl_dir: str) -> str:
    """
    Wizard step: pick a *specific* wordlist file as the default for fuzzing.
    Scans the wordlist directory and shows a numbered list.
    """
    from utils.picker import pick_wordlist, validate_wordlist

    _wizard_step(3, 5, "Default Fuzzing Wordlist",
                 "This file will be pre-filled when you run content discovery.\n"
                 "  You can always override it per-scan.")

    # Prefer known good defaults
    preferred_paths = [
        "SecLists/Discovery/Web-Content/common.txt",
        "SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt",
        "SecLists/Discovery/Web-Content/raft-medium-directories.txt",
        "OneListForAll/onelistforallmicro.txt",
        "common.txt",
    ]
    wl_root = Path(wl_dir)
    auto_default = ""
    for rel in preferred_paths:
        candidate = wl_root / rel
        if candidate.exists():
            auto_default = str(candidate)
            break

    console.print(
        f"\n  [bold cyan]Options:[/bold cyan]\n"
        f"  [1] Pick from wordlist directory  (numbered list + picker)\n"
        f"  [2] Use auto-detected default     "
        + (f"[green]{auto_default}[/green]" if auto_default else "[dim]none found[/dim]") +
        f"\n  [0] Skip"
    )
    try:
        choice = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
    except (EOFError, KeyboardInterrupt):
        choice = "0"

    if choice == "0":
        return auto_default

    if choice == "2" and auto_default:
        _wizard_done("Default wordlist", auto_default)
        return auto_default

    # Use picker
    class _FakeCfg:
        wordlist_path = wl_dir

    result = pick_wordlist(
        cfg=_FakeCfg(),
        title="Select Default Fuzzing Wordlist",
    )
    if result:
        ok, info = validate_wordlist(result)
        if ok:
            _wizard_done("Default wordlist", f"{result}  ({info})")
            return result
        console.print(f"  [red][!] {info}[/red]")

    return auto_default


def _pick_loot_dir(default: str) -> str:
    """Wizard step: choose loot output directory."""
    from utils.picker import pick_directory

    _wizard_step(4, 5, "Loot / Output Directory",
                 "Where CIRCUIT+ saves scan results, reports and findings.")

    console.print(
        f"\n  [bold cyan]Options:[/bold cyan]\n"
        f"  [1] Browse for directory  (picker)\n"
        f"  [2] Use default           ({default})\n"
        f"  [3] Type path manually"
    )
    try:
        choice = input("\033[92m  Choice [2]: \033[0m").strip() or "2"
    except (EOFError, KeyboardInterrupt):
        return default

    if choice == "2":
        Path(default).mkdir(parents=True, exist_ok=True)
        _wizard_done("Loot dir", default)
        return default

    if choice == "1":
        result = pick_directory(
            title="Select Loot Directory",
            label="Loot output directory",
            initial_dir=str(Path.home()),
            must_exist=False,
            default=default,
        )
        if result:
            Path(result).mkdir(parents=True, exist_ok=True)
            _wizard_done("Loot dir", result)
            return result

    if choice == "3":
        try:
            raw = input(f"\033[92m  Path [{default}]: \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            raw = ""
        result = raw or default
        Path(result).mkdir(parents=True, exist_ok=True)
        _wizard_done("Loot dir", result)
        return result

    return default


def _wizard_tool_check(cfg: Config) -> None:
    """Wizard step: scan tools, offer to open installer."""
    from core.validator import check_all, TOOL_REGISTRY

    _wizard_step(5, 5, "Tool Check",
                 "Scanning for installed security tools...")

    results = check_all()
    found   = [n for n, ok in results.items() if ok]
    missing = [n for n, ok in results.items() if not ok]
    required_missing = [n for n in missing if TOOL_REGISTRY.get(n, ("","",False))[2]]

    console.print(
        f"\n  [green]✓  Found:   {len(found)} tools[/green]\n"
        f"  [red]✗  Missing: {len(missing)} tools[/red]"
        + (f"\n  [bold red]★  Required tools missing: {', '.join(required_missing)}[/bold red]"
           if required_missing else "")
    )

    if missing:
        console.print()
        try:
            ans = input("\033[92m[?] Open Install Manager now to install missing tools? [Y/n]: \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            ans = "n"
        if ans in ("", "y", "yes"):
            from modules.installer import run_installer_menu
            run_installer_menu(cfg)
    else:
        console.print("  [bold green][+] All tools present — you're ready to go![/bold green]")


def first_run_wizard() -> Config:
    """
    Full interactive first-run setup wizard.
    Steps: operator alias → wordlist dir → default wordlist → loot dir → tool check.

    Returns:
        Saved Config instance.
    """
    clear_screen()
    sys.stdout.write("\033[92m")
    print(_FIRST_RUN_LOGO)
    sys.stdout.write("\033[0m")

    from rich.panel import Panel as _P
    console.print(_P(
        "[bold bright_green]  FIRST RUN SETUP[/bold bright_green]\n\n"
        "  Welcome to CIRCUIT+. This wizard configures your environment.\n"
        "  [dim]All settings saved to: ~/.config/circuit_plus/config.json[/dim]\n"
        "  [dim]You can change anything later from [cyan][D] Settings → [1] Configuration[/cyan][/dim]",
        border_style="bright_green", expand=False,
    ))

    default_wl   = str(Path.home() / ".local" / "share" / "wordlists")
    default_loot = "./loot"

    operator_name   = _pick_operator_name()
    wordlist_dir    = _pick_wordlist_dir(default_wl)
    default_wl_file = _pick_default_wordlist(wordlist_dir)
    loot_dir        = _pick_loot_dir(default_loot)

    cfg = Config(
        operator_name=operator_name,
        wordlist_path=wordlist_dir,
        loot_dir=loot_dir,
        first_run=False,
    )
    # Store default wordlist file in tools field (reuse as metadata)
    ensure_dirs(cfg)
    save_config(cfg)

    # Save the default wordlist path separately in history metadata
    from config import append_history
    if default_wl_file:
        append_history({"ts": "setup", "action": "set_default_wordlist",
                        "path": default_wl_file})

    console.print()
    from rich.panel import Panel as _PP
    console.print(_PP(
        f"  [green]✓[/green] Operator:          [cyan]{operator_name}[/cyan]\n"
        f"  [green]✓[/green] Wordlist dir:      [cyan]{wordlist_dir}[/cyan]\n"
        f"  [green]✓[/green] Default wordlist:  [cyan]{default_wl_file or '(none)'}[/cyan]\n"
        f"  [green]✓[/green] Loot directory:    [cyan]{loot_dir}[/cyan]",
        title="[bold bright_green]// Setup Summary[/bold bright_green]",
        border_style="bright_green", expand=False,
    ))

    _wizard_tool_check(cfg)

    console.print()
    press_enter("Setup complete. Press [ENTER] to launch CIRCUIT+...")
    return cfg


def _run_tool_check_quiet() -> None:
    """Check required tools and show a compact status line."""
    from core.validator import check_required, REQUIRED_TOOLS
    missing = check_required()
    total = len(REQUIRED_TOOLS)
    found = total - len(missing)
    if missing:
        log_warn(f"Tools: {found}/{total} required. Missing: {', '.join(missing)}")
        console.print("[dim]  → [cyan][D] Settings → [2] Install Manager[/cyan] from main menu[/dim]")
    else:
        log_ok(f"All {total} required tools found.")


def _check_wordlist_on_startup(cfg: Config) -> Config:
    """
    After a normal startup, verify the configured wordlist path exists.
    If missing, prompt to fix it now. Non-blocking — user can skip.
    """
    from utils.picker import pick_directory, validate_wordlist
    wl_path = Path(cfg.wordlist_path)

    if wl_path.exists() and any(wl_path.rglob("*.txt")):
        return cfg  # fine

    console.print()
    from rich.panel import Panel as _P
    console.print(_P(
        f"[bold yellow][~] Wordlist Directory Issue[/bold yellow]\n\n"
        f"  Configured path: [cyan]{cfg.wordlist_path}[/cyan]\n"
        f"  [red]→ Directory not found or contains no .txt files.[/red]\n\n"
        f"  Web fuzzing and DNS brute-force will not work without wordlists.",
        border_style="yellow", expand=False,
    ))
    console.print(
        "  [1] Pick a different directory now\n"
        "  [2] Download SecLists now (~450 MB)\n"
        "  [0] Continue anyway (some features limited)"
    )
    try:
        choice = input("\033[92m[?] Choice [0]: \033[0m").strip() or "0"
    except (EOFError, KeyboardInterrupt):
        choice = "0"

    if choice == "1":
        result = pick_directory(
            title="Select Wordlist Directory",
            label="Wordlist directory",
            initial_dir=str(Path.home()),
            must_exist=True,
        )
        if result:
            from config import update_config, save_config as _sc
            cfg = update_config(cfg, wordlist_path=result)
            _sc(cfg)
            log_ok(f"Wordlist path updated: {result}")

    elif choice == "2":
        from modules.installer import _run_live
        dest = Path(cfg.wordlist_path) / "SecLists"
        Path(cfg.wordlist_path).mkdir(parents=True, exist_ok=True)
        _run_live(
            f"git clone --depth 1 https://github.com/danielmiessler/SecLists.git {dest}",
            "Download SecLists"
        )

    return cfg


# ── Normal Startup Sequence ───────────────────────────────────────────────────

VERSION = "1.1"


def _render_main_menu_plain(cfg: Config) -> None:
    """
    Render the main menu WITHOUT prompting — used by the intro flash sequence.
    """
    from ui.menus import show_main_menu
    show_main_menu(cfg.operator_name)


def startup_sequence(cfg: Config) -> None:
    """
    Cinematic startup sequence:
      1. Resize terminal
      2. ASCII art line-by-line reveal
      3. 3-second hold
      4. "Hello, {name}" typewrite
      5. "are you ready?" flash
      6. "CIRCUIT+" glitch
      7. Menu flash → final show
      Then: tool warning if missing.
    """
    from ui.intro import run_intro

    def _show_menu():
        _render_main_menu_plain(cfg)

    run_intro(cfg.operator_name, _show_menu)

    # After intro — non-blocking tool warning printed below the menu
    from core.validator import check_required
    missing = check_required()
    if missing:
        log_warn(f"Missing required tools: {', '.join(missing)}")
        console.print("[dim]  → [cyan][D] Settings → [2] Install Manager[/cyan] from main menu[/dim]")
        console.print()


# ── Config Sub-Menu Handler ───────────────────────────────────────────────────

def run_config_menu(cfg: Config) -> Config:
    """
    Interactive configuration editor.

    Args:
        cfg: Current config object.
    Returns:
        Updated (and saved) config object.
    """
    from ui.menus import show_config_menu, get_choice, divider
    from core.validator import print_tool_status

    while True:
        try:
            console.print()
            show_config_menu()
            choice = get_choice("config> ")

            if choice == "0":
                break

            elif choice == "1":
                # View config
                divider()
                _print_config_table(cfg)

            elif choice == "2":
                # Edit operator name
                divider()
                try:
                    name = input(f"\033[92m[?] New operator alias [{cfg.operator_name}]: \033[0m").strip()
                    if name:
                        cfg = update_config(cfg, operator_name=name)
                        save_config(cfg)
                        log_ok(f"Operator alias updated: {name}")
                except (EOFError, KeyboardInterrupt):
                    pass

            elif choice == "3":
                # Set wordlist path
                divider()
                try:
                    path = input(f"\033[92m[?] Wordlist path [{cfg.wordlist_path}]: \033[0m").strip()
                    if path:
                        cfg = update_config(cfg, wordlist_path=path)
                        save_config(cfg)
                        log_ok(f"Wordlist path updated: {path}")
                except (EOFError, KeyboardInterrupt):
                    pass

            elif choice == "4":
                # Set threads
                divider()
                try:
                    val = input(f"\033[92m[?] Thread count [{cfg.threads}]: \033[0m").strip()
                    if val.isdigit():
                        cfg = update_config(cfg, threads=int(val))
                        save_config(cfg)
                        log_ok(f"Threads updated: {val}")
                except (EOFError, KeyboardInterrupt):
                    pass

            elif choice == "5":
                # Set loot dir
                divider()
                try:
                    path = input(f"\033[92m[?] Loot directory [{cfg.loot_dir}]: \033[0m").strip()
                    if path:
                        cfg = update_config(cfg, loot_dir=path)
                        ensure_dirs(cfg)
                        save_config(cfg)
                        log_ok(f"Loot dir updated: {path}")
                except (EOFError, KeyboardInterrupt):
                    pass

            elif choice == "6":
                # Check all tools / open installer
                divider()
                print_tool_status()
                console.print()
                try:
                    go_install = input(
                        "[92m[?] Open Install Manager to fix missing tools? [y/N]: [0m"
                    ).strip().lower()
                except (EOFError, KeyboardInterrupt):
                    go_install = "n"
                if go_install in ("y", "yes"):
                    from modules.installer import run_installer_menu
                    run_installer_menu(cfg)

            elif choice == "99":
                break

            else:
                log_warn(f"Unknown option: {choice}")

        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — returning to main menu[/yellow]")
            break

    return cfg


def _print_config_table(cfg: Config) -> None:
    """Display current config as a Rich table."""
    table = Table(
        title="[bold bright_green]// Current Configuration[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
    )
    table.add_column("Setting",  style="bold cyan", width=20)
    table.add_column("Value",    style="white",     width=45)

    rows = [
        ("Operator",       cfg.operator_name),
        ("Wordlist Path",  cfg.wordlist_path),
        ("Loot Directory", cfg.loot_dir),
        ("Threads",        str(cfg.threads)),
        ("Timeout",        f"{cfg.timeout}s"),
        ("Rate Limit",     f"{cfg.rate_limit:,} pps"),
        ("Nuclei Sev.",    cfg.nuclei_severity),
        ("Config File",    str(CONFIG_FILE)),
    ]

    for i, (k, v) in enumerate(rows):
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(k, v, style=style)

    console.print(table)


# ── History Viewer ────────────────────────────────────────────────────────────

def run_history_viewer() -> None:
    """Display past session history from ~/.config/circuit_plus/history.json."""
    if not HISTORY_FILE.exists():
        log_warn("No history found. Run some modules first.")
        return

    try:
        history = json.loads(HISTORY_FILE.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        log_err("History file is corrupted.")
        return

    if not history:
        log_warn("History is empty.")
        return

    table = Table(
        title=f"[bold bright_green]// Session History ({len(history)} entries)[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
    )
    table.add_column("#",       width=5,  justify="right", style="dim")
    table.add_column("Time",    width=20, style="dim")
    table.add_column("Action",  width=18, style="bold cyan")
    table.add_column("Target",  width=30, style="white")
    table.add_column("Result",  width=20, style="green")

    for i, entry in enumerate(history[-50:], 1):   # show last 50
        ts    = entry.get("ts", "")[:19].replace("T", " ")
        action = entry.get("action", "unknown")
        target = entry.get("target", entry.get("domain", ""))
        result_parts = []
        for key in ("results", "live", "findings", "open_ports"):
            if key in entry:
                val = entry[key]
                if isinstance(val, list):
                    result_parts.append(f"{key}={len(val)}")
                else:
                    result_parts.append(f"{key}={val}")
        result = ", ".join(result_parts) if result_parts else "—"
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(str(i), ts, action, target[:29], result[:19], style=style)

    console.print(table)

    try:
        ans = input("\n\033[92m[?] Clear history? [y/N]: \033[0m").strip().lower()
        if ans in ("y", "yes"):
            HISTORY_FILE.write_text("[]", encoding='utf-8')
            log_ok("History cleared.")
    except (EOFError, KeyboardInterrupt):
        pass


# ── HTML Report Export ────────────────────────────────────────────────────────

def export_html_report(cfg: Config) -> None:
    """
    Generate an HTML report from the most recent loot directory contents.
    """
    loot_path = Path(cfg.loot_dir)
    if not loot_path.exists():
        log_err(f"Loot directory not found: {loot_path}")
        return

    # Gather all summary.md files
    summaries = list(loot_path.rglob("summary.md"))
    if not summaries:
        log_warn("No summary reports found in loot directory.")
        return

    report_html = loot_path / "circuit_plus_report.html"
    sections: list[str] = []

    for md_file in sorted(summaries):
        content = md_file.read_text(encoding='utf-8', errors='ignore')
        # Very basic MD → HTML conversion
        html_content = content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        html_content = "\n".join(
            f"<h2>{l[3:]}</h2>" if l.startswith("## ") else
            f"<h3>{l[4:]}</h3>" if l.startswith("### ") else
            f"<h1>{l[2:]}</h1>" if l.startswith("# ") else
            f"<pre>{l[3:]}</pre>" if l.startswith("```") else
            f"<p><code>{l[1:]}</code></p>" if l.startswith("`") else
            f"<hr>" if l.startswith("---") else
            f"<p>{l}</p>" if l.strip() else ""
            for l in html_content.splitlines()
        )
        sections.append(f'<section>\n<p class="path">{md_file}</p>\n{html_content}\n</section>')

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CIRCUIT+ Report</title>
  <style>
    body      {{ background:#0d0d0d; color:#00ff41; font-family:monospace; padding:2rem; }}
    h1        {{ color:#00ff41; border-bottom:1px solid #00ff41; }}
    h2        {{ color:#00cc33; margin-top:2rem; }}
    h3        {{ color:#00aa22; }}
    pre, code {{ background:#111; padding:.2rem .5rem; border-radius:3px; color:#aaffaa; }}
    section   {{ border:1px solid #003300; padding:1rem; margin:1.5rem 0; border-radius:6px; }}
    hr        {{ border-color:#003300; }}
    .path     {{ color:#006600; font-size:.8rem; }}
    table     {{ border-collapse:collapse; width:100%; }}
    td, th    {{ border:1px solid #003300; padding:.4rem .8rem; text-align:left; }}
    th        {{ background:#002200; }}
    tr:nth-child(even) {{ background:#0a0a0a; }}
  </style>
</head>
<body>
  <h1>CIRCUIT+ — Recon Report</h1>
  <p style="color:#666">Generated: {human_timestamp()}</p>
  {''.join(sections)}
</body>
</html>"""

    report_html.write_text(html, encoding='utf-8')
    log_ok(f"HTML report exported: {report_html}")

    try:
        ans = input("\033[92m[?] Open in browser? [y/N]: \033[0m").strip().lower()
        if ans in ("y", "yes"):
            import subprocess
            subprocess.Popen(["xdg-open", str(report_html)])
    except (EOFError, KeyboardInterrupt):
        pass


# ── Shutdown ──────────────────────────────────────────────────────────────────

def graceful_exit(cfg: Config) -> None:
    """Clean shutdown with farewell message."""
    console.print()
    console.print(
        Panel(
            f"  [bright_green]Session terminated.[/bright_green]\n"
            f"  [dim]Operator: {cfg.operator_name}[/dim]\n"
            f"  [dim]Loot dir: {cfg.loot_dir}[/dim]\n\n"
            f"  [dim italic]\"Control is an illusion.\"[/dim italic]",
            border_style="bright_green",
            title="[bold bright_green]// CIRCUIT+[/bold bright_green]",
            expand=False,
        )
    )
    console.print()
    sys.exit(0)


# ── Main Loop ─────────────────────────────────────────────────────────────────

# ── Section Runners ───────────────────────────────────────────────────────────

def _run_section_a(cfg: Config) -> None:
    """Section A — Scanning & Recon loop."""
    from ui.menus import show_section_a
    while True:
        try:
            console.print()
            show_section_a()
            choice = get_choice("circuit+> ")
            if choice == "0": break
            elif choice == "1":
                from modules.recon import run_recon_menu
                run_recon_menu(cfg)
            elif choice == "2":
                from modules.web import run_web_menu
                run_web_menu(cfg)
            elif choice == "3":
                from modules.network import run_network_menu
                run_network_menu(cfg)
            elif choice == "4":
                from modules.workflow import run_workflow_menu
                run_workflow_menu(cfg)
            elif choice == "5":
                from modules.massscan import run_massscan_menu
                run_massscan_menu(cfg)
            elif choice == "6":
                from modules.totalrecon import run_total_recon_menu
                run_total_recon_menu(cfg)
            elif choice == "7":
                from modules.modrunner import run_mods_menu
                run_mods_menu(cfg)
            else:
                log_warn(f"Unknown option: '{choice}'")
        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — back to main menu[/yellow]")
            break


def _run_section_b(cfg: Config) -> None:
    """Section B — OSINT & Intel loop."""
    from ui.menus import show_section_b
    while True:
        try:
            console.print()
            show_section_b()
            choice = get_choice("circuit+> ")
            if choice == "0": break
            elif choice == "1":
                from modules.cloudenum import run_cloud_menu
                run_cloud_menu(cfg)
            elif choice == "2":
                from modules.cve import run_cve_menu
                run_cve_menu(cfg)
            elif choice == "3":
                from modules.diff import run_diff_menu
                run_diff_menu(cfg)
            elif choice == "4":
                from modules.screenshots import run_screenshot_menu
                run_screenshot_menu(cfg)
            else:
                log_warn(f"Unknown option: '{choice}'")
        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — back to main menu[/yellow]")
            break


def _run_section_c(cfg: Config) -> None:
    """Section C — Utilities loop."""
    from ui.menus import show_section_c
    while True:
        try:
            console.print()
            show_section_c()
            choice = get_choice("circuit+> ")
            if choice == "0": break
            elif choice == "1":
                from modules.toolkit import run_toolkit_menu
                run_toolkit_menu(cfg)
            elif choice == "2":
                from modules.plugins import run_plugin_menu
                run_plugin_menu(cfg)
            elif choice == "3":
                from modules.lootbrowser import run_loot_browser
                run_loot_browser(cfg)
            elif choice == "4":
                from modules.session import run_session_menu
                run_session_menu(cfg)
            elif choice == "5":
                from modules.scope import run_scope_menu
                run_scope_menu()
            elif choice == "6":
                from modules.tutorial import run_tutorial
                run_tutorial(cfg)
            else:
                log_warn(f"Unknown option: '{choice}'")
        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — back to main menu[/yellow]")
            break


def _run_section_d(cfg: Config) -> Config:
    """Section D — Settings loop. Returns updated cfg."""
    from ui.menus import show_section_d
    while True:
        try:
            console.print()
            show_section_d()
            choice = get_choice("circuit+> ")
            if choice == "0": break
            elif choice == "1":
                cfg = run_config_menu(cfg)
            elif choice == "2":
                divider()
                from modules.installer import run_installer_menu
                run_installer_menu(cfg)
            elif choice == "3":
                from utils.notify import run_notify_config
                run_notify_config()
            elif choice == "4":
                divider()
                run_history_viewer()
            elif choice == "5":
                divider()
                export_html_report(cfg)
            else:
                log_warn(f"Unknown option: '{choice}'")
        except KeyboardInterrupt:
            console.print("\n[yellow][~] Ctrl+C — back to main menu[/yellow]")
            break
    return cfg



def main() -> None:
    """
    CIRCUIT+ main entry point.
    Handles first-run wizard and main interactive menu loop.
    """
    try:
        # ── First Run or Normal Startup ───────────────────────────
        if not config_exists():
            cfg = first_run_wizard()
        else:
            cfg = load_config()
            ensure_dirs(cfg)

        # ── Startup sequence ──────────────────────────────────────
        startup_sequence(cfg)
        cfg = _check_wordlist_on_startup(cfg)

        # ── Main Menu Loop (hub-and-spoke) ───────────────────────
        while True:
            try:
                show_main_menu(cfg.operator_name)
                section = get_choice("circuit> ").upper().strip()

                if section in ("0", "Q", "QUIT", "EXIT"):
                    graceful_exit(cfg)

                elif section == "A":
                    _run_section_a(cfg)

                elif section == "B":
                    _run_section_b(cfg)

                elif section == "C":
                    _run_section_c(cfg)

                elif section == "D":
                    cfg = _run_section_d(cfg)

                elif section == "":
                    continue

                else:
                    log_warn(f"Unknown section: '{section}' — type A, B, C, or D.")

            except KeyboardInterrupt:
                console.print()
                try:
                    ans = input("\033[92m[?] Exit CIRCUIT+? [y/N]: \033[0m").strip().lower()
                    if ans in ("y", "yes"):
                        graceful_exit(cfg)
                except (EOFError, KeyboardInterrupt):
                    graceful_exit(cfg)

    except KeyboardInterrupt:
        console.print("\n\n[yellow][~] Interrupted during startup. Exiting.[/yellow]\n")
        sys.exit(0)

    except Exception as exc:
        console.print(f"\n[bold red][!] Fatal error: {exc}[/bold red]")
        import traceback
        traceback.print_exc()
        sys.exit(1)


# ── Entry ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    main()
