#!/usr/bin/env python3
"""
CIRCUIT+ — Slack/Discord/generic webhook notifications.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from datetime import datetime
from typing import Any, Optional

from utils.logger import log_ok, log_warn, log_err, console

# ── Send helpers ──────────────────────────────────────────────────────────────

def _post_json(url: str, payload: dict) -> bool:
    """POST JSON to a URL using curl. Returns True on success."""
    if not shutil.which("curl"):
        log_warn("notify: curl not found — cannot send webhook.")
        return False
    body = json.dumps(payload)
    try:
        r = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "-X", "POST", "-H", "Content-Type: application/json",
             "-d", body, url],
            capture_output=True, text=True, timeout=15,
        )
        code = r.stdout.strip()
        return code.startswith("2")
    except Exception as e:
        log_warn(f"notify: request failed — {e}")
        return False


def send_slack(webhook_url: str, text: str, title: str = "CIRCUIT+") -> bool:
    """
    Send a Slack incoming-webhook message.

    Args:
        webhook_url: Slack webhook URL from config.
        text:        Message body (plain text or mrkdwn).
        title:       Block title.

    Returns:
        True if HTTP 2xx received.
    """
    payload = {
        "blocks": [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": f"🛡️ {title}"},
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": text[:2800]},
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"*CIRCUIT+ v1.1* | {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                    }
                ],
            },
        ]
    }
    return _post_json(webhook_url, payload)


def send_discord(webhook_url: str, text: str, title: str = "CIRCUIT+", color: int = 0x00FF41) -> bool:
    """
    Send a Discord embed webhook message.

    Args:
        webhook_url: Discord webhook URL.
        text:        Embed description.
        title:       Embed title.
        color:       Embed left-bar color (hex int, default matrix green).

    Returns:
        True if HTTP 2xx received.
    """
    payload = {
        "embeds": [
            {
                "title":       title,
                "description": text[:4000],
                "color":       color,
                "footer":      {"text": f"CIRCUIT+ v1.1 • {datetime.now().strftime('%Y-%m-%d %H:%M')}"},
            }
        ]
    }
    return _post_json(webhook_url, payload)


def send_generic(webhook_url: str, text: str, title: str = "CIRCUIT+") -> bool:
    """
    POST a simple JSON payload to any URL (generic webhook).

    Args:
        webhook_url: Target URL.
        text:        Message text.
        title:       Message title.

    Returns:
        True on HTTP 2xx.
    """
    payload = {
        "title":     title,
        "text":      text,
        "timestamp": datetime.now().isoformat(),
        "source":    "CIRCUIT+ v1.1",
    }
    return _post_json(webhook_url, payload)


# ── Auto-dispatch (detects type from URL) ─────────────────────────────────────

def notify(text: str, title: str = "CIRCUIT+ Alert") -> bool:
    """
    Send a notification to the configured webhook endpoint(s).
    Reads URL(s) from extended config. Dispatches to Slack/Discord/generic
    based on URL pattern. Silently does nothing if no webhook is configured.

    Args:
        text:  Notification body.
        title: Notification title.

    Returns:
        True if at least one webhook succeeded.
    """
    from config import get_ext
    urls = get_ext("notify_webhooks", [])
    if isinstance(urls, str):
        urls = [urls]
    if not urls:
        return False

    any_ok = False
    for url in urls:
        url = url.strip()
        if not url:
            continue
        if "hooks.slack.com" in url:
            ok = send_slack(url, text, title)
        elif "discord.com/api/webhooks" in url:
            ok = send_discord(url, text, title)
        else:
            ok = send_generic(url, text, title)

        if ok:
            log_ok(f"Notification sent → {url[:40]}…")
            any_ok = True
        else:
            log_warn(f"Notification failed → {url[:40]}…")

    return any_ok


def notify_scan_complete(target: str, phase_count: int, loot_path: str) -> None:
    """Convenience: fire a 'scan complete' notification."""
    text = (
        f"**Target:** `{target}`\n"
        f"**Phases:** {phase_count} completed\n"
        f"**Loot:** `{loot_path}`"
    )
    notify(text, title="✅ Mass Scan Complete")


def notify_critical_finding(target: str, template: str, severity: str, matched: str) -> None:
    """Convenience: fire a critical nuclei finding alert."""
    color = 0xFF0000 if severity.lower() == "critical" else 0xFF6600
    text = (
        f"**Target:** `{target}`\n"
        f"**Template:** `{template}`\n"
        f"**Severity:** `{severity.upper()}`\n"
        f"**Matched:** `{matched}`"
    )
    notify(text, title=f"⚠️ {severity.upper()} Finding — {target}")


# ── Interactive config menu ───────────────────────────────────────────────────

def run_notify_config() -> None:
    """Interactively configure notification webhooks."""
    from config import get_ext, set_ext
    from rich.panel import Panel as _P
    from rich.table import Table as _T
    from rich import box as _box

    current: list[str] = get_ext("notify_webhooks", [])
    if isinstance(current, str):
        current = [current] if current else []

    while True:
        console.print()
        tbl = _T(box=_box.SIMPLE_HEAVY, border_style="bright_green",
                 show_header=True, header_style="bold bright_green", expand=False)
        tbl.add_column("#",    width=4,  style="dim",       justify="right")
        tbl.add_column("URL",  width=55, style="cyan")
        tbl.add_column("Type", width=10, style="dim")

        for i, url in enumerate(current, 1):
            kind = "Slack" if "slack" in url else "Discord" if "discord" in url else "Generic"
            tbl.add_row(str(i), url[:54], kind, style="on grey11" if i % 2 == 0 else "")

        if not current:
            tbl.add_row("", "[dim]No webhooks configured[/dim]", "", style="on grey11")

        console.print(_P(
            tbl,
            title="[bold bright_green]// Notification Webhooks[/bold bright_green]",
            border_style="bright_green", expand=False,
        ))
        console.print(
            "  [cyan][a][/cyan] Add webhook    "
            "[cyan][d #][/cyan] Delete by #    "
            "[cyan][t][/cyan] Send test    "
            "[cyan][0][/cyan] Back"
        )

        try:
            cmd = input("\033[92m  notify> \033[0m").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break

        if cmd in ("0", "back"):
            break
        elif cmd == "a":
            try:
                url = input("\033[92m[?] Webhook URL: \033[0m").strip()
                if url and url.startswith("http"):
                    current.append(url)
                    set_ext("notify_webhooks", current)
                    log_ok("Webhook added.")
            except (EOFError, KeyboardInterrupt):
                pass
        elif cmd.startswith("d "):
            try:
                idx = int(cmd.split()[1]) - 1
                if 0 <= idx < len(current):
                    removed = current.pop(idx)
                    set_ext("notify_webhooks", current)
                    log_ok(f"Removed: {removed[:40]}")
            except (ValueError, IndexError):
                pass
        elif cmd == "t":
            if current:
                ok = notify("🔔 Test notification from CIRCUIT+ v1.1", "Test Alert")
                if not ok:
                    log_warn("Test failed — check URL and internet connectivity.")
            else:
                log_warn("No webhooks configured yet.")
