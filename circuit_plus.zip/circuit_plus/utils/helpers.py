#!/usr/bin/env python3
"""
CIRCUIT+ — URL validators, file utilities, and timestamp helpers.
"""
from __future__ import annotations

import re
import os
import hashlib
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from typing import Optional


# ── Timestamp ─────────────────────────────────────────────────────────────────
def timestamp() -> str:
    """Return filesystem-safe timestamp string: YYYYMMDD_HHMMSS"""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def human_timestamp() -> str:
    """Return human-readable timestamp."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ── URL / Domain Helpers ──────────────────────────────────────────────────────
def is_valid_domain(domain: str) -> bool:
    """Validate a bare domain name (no scheme, no path)."""
    pattern = r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    return bool(re.match(pattern, domain.strip()))


def is_valid_url(url: str) -> bool:
    """Validate a full URL with scheme."""
    try:
        parsed = urlparse(url)
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False


def is_valid_ip(ip: str) -> bool:
    """Validate an IPv4 address."""
    pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if not re.match(pattern, ip):
        return False
    return all(0 <= int(o) <= 255 for o in ip.split('.'))


def is_valid_cidr(cidr: str) -> bool:
    """Validate a CIDR range like 10.0.0.0/24."""
    pattern = r'^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$'
    if not re.match(pattern, cidr):
        return False
    ip, prefix = cidr.split('/')
    return is_valid_ip(ip) and 0 <= int(prefix) <= 32


def normalize_url(url: str) -> str:
    """Ensure URL has a scheme; default to https."""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.rstrip('/')


def domain_from_url(url: str) -> str:
    """Extract bare domain from URL."""
    return urlparse(normalize_url(url)).netloc


# ── Loot Directory Helpers ────────────────────────────────────────────────────
def make_loot_dir(base: Path, target: str, module: str) -> Path:
    """
    Create and return loot path: {base}/{target}/{timestamp}/{module}/
    """
    ts = timestamp()
    safe_target = sanitize_filename(target)
    path = base / safe_target / ts / module
    path.mkdir(parents=True, exist_ok=True)
    return path


def sanitize_filename(name: str) -> str:
    """Remove characters that are unsafe in file/directory names."""
    return re.sub(r'[^\w\-_\.]', '_', name)


def count_lines(path: Path) -> int:
    """Count lines in a text file efficiently."""
    if not path.exists():
        return 0
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return sum(1 for _ in f)
    except OSError:
        return 0


def read_lines(path: Path) -> list[str]:
    """Read non-empty lines from a file, stripped."""
    if not path.exists():
        return []
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return [line.strip() for line in f if line.strip()]
    except OSError:
        return []


def write_lines(path: Path, lines: list[str]) -> int:
    """Write a list of lines to a file. Returns count written."""
    path.parent.mkdir(parents=True, exist_ok=True)
    unique = sorted(set(lines))
    path.write_text('\n'.join(unique) + '\n', encoding='utf-8')
    return len(unique)


def merge_files(sources: list[Path], dest: Path) -> int:
    """Merge multiple text files, deduplicating lines. Returns total unique lines."""
    all_lines: set[str] = set()
    for src in sources:
        all_lines.update(read_lines(src))
    return write_lines(dest, list(all_lines))


# ── Formatting Helpers ────────────────────────────────────────────────────────
def human_filesize(size_bytes: int) -> str:
    """Format bytes to human readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes //= 1024
    return f"{size_bytes:.1f} TB"


def truncate(text: str, max_len: int = 80) -> str:
    """Truncate string to max_len with ellipsis."""
    return text if len(text) <= max_len else text[:max_len - 3] + "..."


def parse_ports(port_string: str) -> list[int]:
    """
    Parse a port string like '22,80,443,8000-8100' into a list of ints.
    """
    ports: list[int] = []
    for part in port_string.split(','):
        part = part.strip()
        if '-' in part:
            start, end = part.split('-', 1)
            ports.extend(range(int(start), int(end) + 1))
        else:
            ports.append(int(part))
    return sorted(set(ports))


def file_md5(path: Path) -> str:
    """Compute MD5 hash of a file."""
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


# ── Input Prompts ─────────────────────────────────────────────────────────────
def prompt_target(prompt_text: str = "Enter target (domain/IP): ") -> Optional[str]:
    """Prompt for a target and validate it's a domain, IP, or URL."""
    try:
        val = input(prompt_text).strip()
        if not val:
            return None
        if is_valid_domain(val) or is_valid_ip(val) or is_valid_url(val) or is_valid_cidr(val):
            return val
        return val  # Return anyway and let module validate
    except (EOFError, KeyboardInterrupt):
        return None


def confirm(prompt_text: str, default: bool = False) -> bool:
    """Yes/No confirmation prompt."""
    hint = "[Y/n]" if default else "[y/N]"
    try:
        resp = input(f"{prompt_text} {hint}: ").strip().lower()
        if not resp:
            return default
        return resp in ('y', 'yes')
    except (EOFError, KeyboardInterrupt):
        return False
