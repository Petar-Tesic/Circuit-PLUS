#!/usr/bin/env python3
"""
CIRCUIT+ — Console logging helpers and loot file logger.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

try:
    from rich.console import Console
    from rich.text import Text
except ImportError:
    pass


# ── Console (shared, importable) ─────────────────────────────────────────────
console = Console(highlight=False)
err_console = Console(stderr=True, highlight=False)


# ── Log Levels / Styled Output ────────────────────────────────────────────────
def log_ok(msg: str) -> None:
    """Print a success-level message."""
    console.print(f"[bold green]\\[+][/bold green] {msg}")


def log_err(msg: str) -> None:
    """Print an error-level message."""
    err_console.print(f"[bold red]\\[!][/bold red] {msg}")


def log_info(msg: str) -> None:
    """Print an informational message."""
    console.print(f"[bold cyan]\\[*][/bold cyan] {msg}")


def log_warn(msg: str) -> None:
    """Print a warning message."""
    console.print(f"[bold yellow]\\[~][/bold yellow] {msg}")


def log_find(msg: str) -> None:
    """Print a finding/discovery message."""
    console.print(f"[bold magenta]\\[>][/bold magenta] {msg}")


def log_cmd(cmd: list[str]) -> None:
    """Print the command being run."""
    cmd_str = ' '.join(str(c) for c in cmd)
    console.print(f"[dim cyan]  $ {cmd_str}[/dim cyan]")


# ── File Logger ───────────────────────────────────────────────────────────────
class LootLogger:
    """
    Writes structured logs to loot directory.
    Also writes a human-readable .log file alongside JSON.
    """

    def __init__(self, loot_dir: Path, module: str = "general") -> None:
        self.loot_dir  = loot_dir
        self.module    = module
        self.log_file  = loot_dir / f"{module}.log"
        self.json_file = loot_dir / f"{module}_events.json"
        self.events: list[dict[str, Any]] = []
        loot_dir.mkdir(parents=True, exist_ok=True)

    def _write_line(self, level: str, msg: str) -> None:
        ts = datetime.now().isoformat()
        line = f"[{ts}] [{level}] {msg}\n"
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(line)
        except OSError:
            pass

        event: dict[str, Any] = {"ts": ts, "level": level, "msg": msg}
        self.events.append(event)

    def ok(self, msg: str) -> None:
        self._write_line("SUCCESS", msg)

    def err(self, msg: str) -> None:
        self._write_line("ERROR", msg)

    def info(self, msg: str) -> None:
        self._write_line("INFO", msg)

    def warn(self, msg: str) -> None:
        self._write_line("WARN", msg)

    def finding(self, data: dict[str, Any]) -> None:
        """Log a structured finding (vuln, open port, etc.)."""
        self.events.append({"ts": datetime.now().isoformat(), "type": "finding", **data})

    def command(self, cmd: list[str], exit_code: int, stdout_lines: int) -> None:
        """Log an executed command."""
        self._write_line("CMD", f"exit={exit_code} lines={stdout_lines} cmd={' '.join(str(c) for c in cmd)}")

    def flush(self) -> None:
        """Write all JSON events to disk."""
        try:
            with open(self.json_file, 'w', encoding='utf-8') as f:
                json.dump(self.events, f, indent=2, default=str)
        except OSError:
            pass

    def __del__(self) -> None:
        try:
            self.flush()
        except Exception:
            pass


# ── Session Logger ────────────────────────────────────────────────────────────
class SessionLogger:
    """
    Global session logger that writes to ~/.config/circuit_plus/session.log
    """
    _instance: Optional["SessionLogger"] = None

    def __init__(self) -> None:
        from config import CONFIG_DIR
        self._log_path = CONFIG_DIR / "session.log"
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(
            filename=str(self._log_path),
            level=logging.DEBUG,
            format="%(asctime)s [%(levelname)s] %(message)s"
        )
        self._logger = logging.getLogger("circuit_plus")

    @classmethod
    def get(cls) -> "SessionLogger":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def info(self, msg: str) -> None:
        self._logger.info(msg)

    def error(self, msg: str) -> None:
        self._logger.error(msg)

    def debug(self, msg: str) -> None:
        self._logger.debug(msg)
