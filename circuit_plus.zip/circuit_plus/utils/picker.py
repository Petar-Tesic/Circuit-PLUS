#!/usr/bin/env python3
"""
CIRCUIT+ — File/directory picker: tkinter → zenity → kdialog → console.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import List, Optional

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich import box
except ImportError:
    pass

console = Console(highlight=False)


# ══════════════════════════════════════════════════════════════════════════════
# BACKEND DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def _has_display() -> bool:
    """Return True if a graphical display is available."""
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def _try_tkinter() -> bool:
    """Return True if tkinter + Tk display is available."""
    if not _has_display():
        return False
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.destroy()
        return True
    except Exception:
        return False


def _has_zenity() -> bool:
    return _has_display() and bool(shutil.which("zenity"))


def _has_kdialog() -> bool:
    return _has_display() and bool(shutil.which("kdialog"))


def _detect_backend() -> str:
    """Return 'tkinter', 'zenity', 'kdialog', or 'console'."""
    if _try_tkinter():
        return "tkinter"
    if _has_zenity():
        return "zenity"
    if _has_kdialog():
        return "kdialog"
    return "console"


# Cache the backend detection (expensive because Tk spawns a window briefly)
_BACKEND: Optional[str] = None

def get_backend() -> str:
    global _BACKEND
    if _BACKEND is None:
        _BACKEND = _detect_backend()
    return _BACKEND


def backend_label() -> str:
    b = get_backend()
    labels = {
        "tkinter": "GUI (tkinter)",
        "zenity":  "GUI (zenity)",
        "kdialog": "GUI (kdialog)",
        "console": "Console input",
    }
    return labels.get(b, b)


# ══════════════════════════════════════════════════════════════════════════════
# TKINTER PICKERS
# ══════════════════════════════════════════════════════════════════════════════

def _tk_pick_file(
    title: str = "Select file",
    initial_dir: str = str(Path.home()),
    filetypes: List[tuple] = (("All files", "*.*"),),
) -> str:
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.lift()
    root.attributes("-topmost", True)
    result = filedialog.askopenfilename(
        title=title,
        initialdir=initial_dir,
        filetypes=filetypes,
        parent=root,
    )
    root.destroy()
    return result or ""


def _tk_pick_dir(
    title: str = "Select directory",
    initial_dir: str = str(Path.home()),
) -> str:
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.lift()
    root.attributes("-topmost", True)
    result = filedialog.askdirectory(
        title=title,
        initialdir=initial_dir,
        parent=root,
    )
    root.destroy()
    return result or ""


def _tk_save_file(
    title: str = "Save file as",
    initial_dir: str = str(Path.home()),
    default_ext: str = "",
) -> str:
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.lift()
    root.attributes("-topmost", True)
    result = filedialog.asksaveasfilename(
        title=title,
        initialdir=initial_dir,
        defaultextension=default_ext,
        parent=root,
    )
    root.destroy()
    return result or ""


# ══════════════════════════════════════════════════════════════════════════════
# ZENITY PICKERS
# ══════════════════════════════════════════════════════════════════════════════

def _zenity(args: List[str]) -> str:
    try:
        r = subprocess.run(
            ["zenity"] + args,
            capture_output=True, text=True, timeout=60,
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _zenity_pick_file(title: str, initial_dir: str) -> str:
    return _zenity(["--file-selection", f"--title={title}", f"--filename={initial_dir}/"])


def _zenity_pick_dir(title: str, initial_dir: str) -> str:
    return _zenity(["--file-selection", "--directory", f"--title={title}", f"--filename={initial_dir}/"])


def _zenity_save_file(title: str, initial_dir: str) -> str:
    return _zenity(["--file-selection", "--save", f"--title={title}", f"--filename={initial_dir}/"])


# ══════════════════════════════════════════════════════════════════════════════
# KDIALOG PICKERS
# ══════════════════════════════════════════════════════════════════════════════

def _kdialog(args: List[str]) -> str:
    try:
        r = subprocess.run(
            ["kdialog"] + args,
            capture_output=True, text=True, timeout=60,
        )
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def _kdialog_pick_file(title: str, initial_dir: str) -> str:
    return _kdialog(["--getopenfilename", initial_dir, f"--title={title}"])


def _kdialog_pick_dir(title: str, initial_dir: str) -> str:
    return _kdialog(["--getexistingdirectory", initial_dir, f"--title={title}"])


def _kdialog_save_file(title: str, initial_dir: str) -> str:
    return _kdialog(["--getsavefilename", initial_dir, f"--title={title}"])


# ══════════════════════════════════════════════════════════════════════════════
# CONSOLE PICKER  (always works, no display needed)
# ══════════════════════════════════════════════════════════════════════════════

def _console_pick_path(
    prompt: str,
    must_exist: bool = True,
    default: str = "",
    is_dir: bool = False,
) -> str:
    """
    Console fallback: prompt user to type a path with basic tab-completion.
    Loops until a valid path is entered (or empty to cancel).
    """
    import readline  # enables tab completion in input()

    # Enable tab completion for paths
    def _complete(text: str, state: int):
        results = []
        try:
            expanded = os.path.expanduser(text)
            parent   = os.path.dirname(expanded) or "."
            partial  = os.path.basename(expanded)
            for name in os.listdir(parent):
                if name.startswith(partial):
                    full = os.path.join(parent, name)
                    results.append(full + ("/" if os.path.isdir(full) else ""))
        except Exception:
            pass
        return results[state] if state < len(results) else None

    readline.set_completer(_complete)
    readline.set_completer_delims(" \t\n")
    readline.parse_and_bind("tab: complete")

    default_hint = f" [{default}]" if default else ""
    console.print(f"[dim]  (Tab for completion, Enter to use default, empty = cancel)[/dim]")

    while True:
        try:
            raw = input(f"\033[92m  {prompt}{default_hint}: \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            return ""

        if not raw:
            if default:
                raw = default
            else:
                return ""

        # Expand ~ and env vars
        expanded = str(Path(os.path.expanduser(raw)).expanduser())

        if must_exist:
            p = Path(expanded)
            if is_dir and not p.is_dir():
                console.print(f"[red]  [!] Directory not found: {expanded}[/red]")
                console.print(f"  [dim]Try again or press Ctrl+C to cancel.[/dim]")
                continue
            elif not is_dir and not p.is_file():
                console.print(f"[red]  [!] File not found: {expanded}[/red]")
                console.print(f"  [dim]Try again or press Ctrl+C to cancel.[/dim]")
                continue

        return expanded


def _console_pick_from_list(
    prompt: str,
    items: List[str],
    title: str = "Select",
) -> str:
    """
    Let the user pick from a numbered list via console.
    Returns the selected string, or "" if cancelled.
    """
    if not items:
        return ""

    table = Table(box=box.SIMPLE_HEAVY, border_style="green", show_header=False)
    table.add_column("#",    width=5,  style="dim", justify="right")
    table.add_column("Path", style="cyan")
    for i, item in enumerate(items, 1):
        table.add_row(str(i), item, style="on grey11" if i % 2 == 0 else "")
    console.print(table)

    while True:
        try:
            raw = input(f"\033[92m  {prompt} (1-{len(items)}, 0=cancel): \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            return ""
        if raw == "0" or not raw:
            return ""
        if raw.isdigit() and 1 <= int(raw) <= len(items):
            return items[int(raw) - 1]
        console.print(f"[red]  [!] Enter a number between 1 and {len(items)}.[/red]")


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC API — unified pick_*() functions
# ══════════════════════════════════════════════════════════════════════════════

def _prompt_method(label: str) -> str:
    """
    Ask the user: GUI dialog or type manually?
    Returns 'gui' or 'console'.
    """
    backend = get_backend()
    if backend == "console":
        return "console"

    console.print(
        f"\n  [bold cyan]{label}[/bold cyan]\n"
        f"  [dim]Backend available: {backend_label()}[/dim]"
    )
    console.print(
        "  [1] Open file dialog  (GUI)\n"
        "  [2] Type path manually  (console)"
    )
    try:
        choice = input("\033[92m  Pick input method [1]: \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        choice = "1"
    return "console" if choice == "2" else "gui"


def pick_file(
    title: str = "Select a file",
    label: str = "Select file",
    initial_dir: str = str(Path.home()),
    must_exist: bool = True,
    default: str = "",
    filetypes: List[tuple] = (("All files", "*.*"),),
    force_console: bool = False,
) -> str:
    """
    Unified file picker. Tries GUI then console.

    Args:
        title:         Window title for GUI dialog.
        label:         Console prompt label.
        initial_dir:   Starting directory for GUI / hint for console.
        must_exist:    Validate the path exists before returning.
        default:       Default value pre-filled in console mode.
        filetypes:     GUI filetypes filter list.
        force_console: Skip GUI even if available.

    Returns:
        Absolute path string, or "" if cancelled.
    """
    method = "console" if force_console else _prompt_method(label)
    backend = get_backend()
    result  = ""

    if method == "gui" and backend != "console":
        console.print(f"  [dim]Opening {backend_label()} dialog...[/dim]")
        try:
            if backend == "tkinter":
                result = _tk_pick_file(title, initial_dir, filetypes)
            elif backend == "zenity":
                result = _zenity_pick_file(title, initial_dir)
            elif backend == "kdialog":
                result = _kdialog_pick_file(title, initial_dir)
        except Exception as e:
            console.print(f"  [yellow][~] GUI picker failed ({e}), falling back to console.[/yellow]")
            result = ""

        if not result:
            console.print("  [dim]Dialog cancelled or failed — type path manually.[/dim]")
            method = "console"

    if method == "console" or not result:
        result = _console_pick_path(
            label, must_exist=must_exist, default=default, is_dir=False
        )

    return result


def pick_directory(
    title: str = "Select a directory",
    label: str = "Select directory",
    initial_dir: str = str(Path.home()),
    must_exist: bool = False,
    default: str = "",
    force_console: bool = False,
) -> str:
    """
    Unified directory picker.

    Returns:
        Absolute path string, or "" if cancelled.
    """
    method = "console" if force_console else _prompt_method(label)
    backend = get_backend()
    result  = ""

    if method == "gui" and backend != "console":
        console.print(f"  [dim]Opening {backend_label()} dialog...[/dim]")
        try:
            if backend == "tkinter":
                result = _tk_pick_dir(title, initial_dir)
            elif backend == "zenity":
                result = _zenity_pick_dir(title, initial_dir)
            elif backend == "kdialog":
                result = _kdialog_pick_dir(title, initial_dir)
        except Exception as e:
            console.print(f"  [yellow][~] GUI picker failed ({e}), falling back to console.[/yellow]")
            result = ""

        if not result:
            console.print("  [dim]Dialog cancelled or failed — type path manually.[/dim]")
            method = "console"

    if method == "console" or not result:
        result = _console_pick_path(
            label, must_exist=must_exist, default=default, is_dir=True
        )

    return result or default


def pick_wordlist(
    cfg=None,
    title: str = "Select Wordlist",
    label: str = "Wordlist file",
    force_console: bool = False,
) -> str:
    """
    Specialised picker for wordlist files.
    First offers a quick list of wordlists found under cfg.wordlist_path,
    then falls back to the full file picker.

    Args:
        cfg:  CIRCUIT+ Config (used to scan wordlist_path).
        title: Dialog title.
        label: Console prompt.

    Returns:
        Absolute path to the selected wordlist, or "".
    """
    # ── Try to find existing wordlists ──────────────────────────────────────
    found_lists: List[str] = []
    if cfg:
        wl_root = Path(cfg.wordlist_path)
        if wl_root.exists():
            # Collect common wordlist files, capped at 50
            for ext in ("*.txt", "*.lst", "*.wordlist"):
                found_lists.extend(
                    str(p) for p in sorted(wl_root.rglob(ext))[:50]
                )
            found_lists = sorted(set(found_lists))[:60]

    if found_lists:
        console.print(
            Panel(
                f"[bold bright_green]{title}[/bold bright_green]\n"
                f"[dim]  Found {len(found_lists)} wordlist(s) in {getattr(cfg,'wordlist_path','~/.local/share/wordlists')}[/dim]",
                border_style="bright_green",
                expand=False,
            )
        )
        console.print(
            "  [1] Pick from found wordlists  (numbered list)\n"
            "  [2] Browse for a file          (GUI / console)\n"
            "  [0] Cancel"
        )
        try:
            sub = input("\033[92m  Choice [1]: \033[0m").strip() or "1"
        except (EOFError, KeyboardInterrupt):
            return ""

        if sub == "0":
            return ""
        elif sub == "1":
            return _console_pick_from_list("Select wordlist #", found_lists, title)
        # else fall through to full picker

    else:
        console.print(
            f"[yellow]  [~] No wordlists found in the configured directory.[/yellow]\n"
            f"  [dim]  wordlist_path = {getattr(cfg,'wordlist_path','(not set)')}[/dim]"
        )

    # ── Full file picker ─────────────────────────────────────────────────────
    initial = str(Path(cfg.wordlist_path).expanduser()) if cfg else str(Path.home())
    return pick_file(
        title=title,
        label=label,
        initial_dir=initial,
        must_exist=True,
        filetypes=[
            ("Text wordlists", "*.txt *.lst *.wordlist"),
            ("All files", "*.*"),
        ],
        force_console=force_console,
    )


# ══════════════════════════════════════════════════════════════════════════════
# WORDLIST VALIDATION HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def validate_wordlist(path: str, min_lines: int = 1) -> tuple[bool, str]:
    """
    Validate a wordlist path exists and has content.

    Returns:
        (valid: bool, error_message: str)
    """
    if not path:
        return False, "No wordlist path provided."
    p = Path(path)
    if not p.exists():
        return False, f"File not found: {path}"
    if not p.is_file():
        return False, f"Not a file: {path}"
    if p.stat().st_size == 0:
        return False, f"File is empty: {path}"
    try:
        count = sum(1 for _ in open(p, errors="ignore"))
        if count < min_lines:
            return False, f"File has only {count} line(s) (need ≥ {min_lines}): {path}"
        return True, f"{count:,} words"
    except OSError as e:
        return False, f"Cannot read file: {e}"


def require_wordlist(
    wordlist_arg: str,
    cfg=None,
    context: str = "this operation",
    force_console: bool = False,
) -> Optional[str]:
    """
    Ensure a valid wordlist is available. If wordlist_arg is invalid/empty,
    show a clear error and offer the picker to select one.

    Args:
        wordlist_arg:  Path string supplied by caller (may be empty/invalid).
        cfg:           Config (for wordlist_path scanning).
        context:       Human-readable description of what needs the wordlist.
        force_console: Skip GUI picker.

    Returns:
        Valid wordlist path string, or None if user cancelled.
    """
    from utils.logger import log_err, log_warn, log_info

    # First try the supplied argument
    if wordlist_arg:
        valid, msg = validate_wordlist(wordlist_arg)
        if valid:
            log_info(f"Wordlist: {wordlist_arg} ({msg})")
            return wordlist_arg
        else:
            console.print(
                Panel(
                    f"[bold red][!] Wordlist Error[/bold red]\n\n"
                    f"  {msg}\n\n"
                    f"  [dim]Required for: {context}[/dim]",
                    border_style="red",
                    expand=False,
                )
            )

    else:
        console.print(
            Panel(
                f"[bold yellow][~] No Wordlist Specified[/bold yellow]\n\n"
                f"  No wordlist was provided for [cyan]{context}[/cyan].\n"
                f"  Please select one to continue.",
                border_style="yellow",
                expand=False,
            )
        )

    # Offer picker
    console.print()
    try:
        ans = input("\033[92m[?] Select a wordlist now? [Y/n]: \033[0m").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return None
    if ans not in ("", "y", "yes"):
        log_err(f"No wordlist — {context} aborted.")
        return None

    result = pick_wordlist(cfg=cfg, title=f"Wordlist for {context}", force_console=force_console)
    if not result:
        log_err(f"No wordlist selected — {context} aborted.")
        return None

    valid, msg = validate_wordlist(result)
    if not valid:
        log_err(f"Selected file invalid: {msg}")
        return None

    log_info(f"Wordlist selected: {result} ({msg})")
    return result
