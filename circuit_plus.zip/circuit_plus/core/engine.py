#!/usr/bin/env python3
"""
CIRCUIT+ — Subprocess wrapper with real-time output streaming.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Callable, Generator, List, Optional, Tuple

try:
    from rich.console import Console
    from rich.live import Live
    from rich.spinner import Spinner
    from rich.text import Text
    from rich.progress import (
        Progress, SpinnerColumn, TextColumn,
        BarColumn, TimeElapsedColumn, TaskID
    )
except ImportError:
    pass

from utils.logger import console, log_err, log_info, log_cmd

# ── Engine ────────────────────────────────────────────────────────────────────

class ProcessError(Exception):
    """Raised when a subprocess returns a non-zero exit code."""
    def __init__(self, cmd: list, returncode: int, stderr: str) -> None:
        self.cmd = cmd
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(f"Command failed (exit {returncode}): {' '.join(str(c) for c in cmd)}")


def run_tool(
    command: List[str | Path],
    cwd: Optional[Path] = None,
    timeout: Optional[int] = None,
    env: Optional[dict] = None,
    silent: bool = False,
    stream_callback: Optional[Callable[[str], None]] = None,
) -> Tuple[int, str, str]:
    """
    Execute an external tool via subprocess with real-time output streaming.

    Args:
        command:         Argument list (e.g. ['nmap', '-sV', '192.168.1.1']).
        cwd:             Working directory for the process.
        timeout:         Optional timeout in seconds.
        env:             Environment variables dict (merged with current env).
        silent:          If True, suppress live console output.
        stream_callback: Optional callback(line) for each stdout line.

    Returns:
        Tuple of (return_code, stdout_text, stderr_text).

    Raises:
        FileNotFoundError: If the binary is not found.
    """
    cmd_strs = [str(c) for c in command]

    # Resolve binary
    binary = cmd_strs[0]
    if not shutil.which(binary):
        log_err(f"Binary not found in PATH: '{binary}'")
        raise FileNotFoundError(f"'{binary}' not found in PATH")

    if not silent:
        log_cmd(cmd_strs)

    proc_env = os.environ.copy()
    if env:
        proc_env.update(env)

    stdout_lines: list[str] = []
    stderr_lines: list[str] = []

    try:
        process = subprocess.Popen(
            cmd_strs,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            errors='replace',
            cwd=str(cwd) if cwd else None,
            env=proc_env,
        )

        def _read_stderr() -> None:
            """Read stderr in a background thread to prevent deadlock."""
            assert process.stderr is not None
            for line in process.stderr:
                line = line.rstrip()
                if line:
                    stderr_lines.append(line)

        stderr_thread = threading.Thread(target=_read_stderr, daemon=True)
        stderr_thread.start()

        # Stream stdout
        assert process.stdout is not None
        for line in process.stdout:
            line = line.rstrip()
            if line:
                stdout_lines.append(line)
                if not silent:
                    console.print(f"  [dim]{line}[/dim]")
                if stream_callback:
                    stream_callback(line)

        process.wait(timeout=timeout)
        stderr_thread.join(timeout=5)

        return_code = process.returncode
        stdout_text  = '\n'.join(stdout_lines)
        stderr_text  = '\n'.join(stderr_lines)

        if not silent and return_code != 0:
            log_err(f"Exit code {return_code}: {cmd_strs[0]}")
            if stderr_text:
                for err_line in stderr_text.splitlines()[:5]:
                    console.print(f"  [dim red]{err_line}[/dim red]")

        return return_code, stdout_text, stderr_text

    except subprocess.TimeoutExpired:
        process.kill()
        log_err(f"Timeout after {timeout}s: {' '.join(cmd_strs)}")
        return 124, '\n'.join(stdout_lines), "TIMEOUT"

    except KeyboardInterrupt:
        process.kill()
        log_err("Interrupted by user (Ctrl+C)")
        return 130, '\n'.join(stdout_lines), "INTERRUPTED"

    except FileNotFoundError:
        raise

    except Exception as exc:
        log_err(f"Unexpected error running {binary}: {exc}")
        return 1, '', str(exc)


def run_piped(
    commands: List[List[str | Path]],
    cwd: Optional[Path] = None,
    silent: bool = False,
) -> Tuple[int, str, str]:
    """
    Run a pipeline of commands (cmd1 | cmd2 | cmd3).

    Args:
        commands: List of command lists.
        cwd:      Working directory.
        silent:   Suppress output.

    Returns:
        Tuple of (last_return_code, stdout_text, stderr_text).
    """
    if not commands:
        return 0, '', ''

    cmd_strs_list = [[str(c) for c in cmd] for cmd in commands]

    if not silent:
        pipe_str = ' | '.join(' '.join(c) for c in cmd_strs_list)
        console.print(f"  [dim cyan]  $ {pipe_str}[/dim cyan]")

    procs: list[subprocess.Popen] = []
    try:
        prev_stdout = None
        for i, cmd in enumerate(cmd_strs_list):
            is_last = (i == len(cmd_strs_list) - 1)
            proc = subprocess.Popen(
                cmd,
                stdin=prev_stdout,
                stdout=subprocess.PIPE if not is_last else subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='replace',
                cwd=str(cwd) if cwd else None,
            )
            if prev_stdout is not None:
                prev_stdout.close()
            prev_stdout = proc.stdout
            procs.append(proc)

        # Collect last process output
        last = procs[-1]
        stdout_text, stderr_text = last.communicate()
        last_code = last.returncode

        # Wait for all others
        for p in procs[:-1]:
            p.wait()

        if not silent and stdout_text:
            for line in stdout_text.splitlines()[:50]:  # limit display
                console.print(f"  [dim]{line}[/dim]")

        return last_code, stdout_text, stderr_text

    except KeyboardInterrupt:
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass
        log_err("Pipeline interrupted by user")
        return 130, '', 'INTERRUPTED'

    except Exception as exc:
        log_err(f"Pipeline error: {exc}")
        return 1, '', str(exc)


def stream_lines(
    command: List[str | Path],
    cwd: Optional[Path] = None,
) -> Generator[str, None, None]:
    """
    Generator that yields stdout lines from a command in real time.

    Args:
        command: Argument list.
        cwd:     Working directory.

    Yields:
        Each output line (stripped).
    """
    cmd_strs = [str(c) for c in command]
    if not shutil.which(cmd_strs[0]):
        log_err(f"Binary not found: '{cmd_strs[0]}'")
        return

    try:
        process = subprocess.Popen(
            cmd_strs,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding='utf-8',
            errors='replace',
            cwd=str(cwd) if cwd else None,
        )
        assert process.stdout is not None
        for line in process.stdout:
            stripped = line.rstrip()
            if stripped:
                yield stripped
        process.wait()
    except KeyboardInterrupt:
        process.kill()
    except Exception as exc:
        log_err(f"Stream error: {exc}")


def run_with_progress(
    command: List[str | Path],
    description: str = "Running...",
    cwd: Optional[Path] = None,
    collect_output: bool = True,
) -> Tuple[int, str, str]:
    """
    Run a command with a Rich spinner progress indicator.

    Args:
        command:        Argument list.
        description:    Spinner label text.
        cwd:            Working directory.
        collect_output: Collect stdout into returned string.

    Returns:
        Tuple of (return_code, stdout_text, stderr_text).
    """
    from utils.logger import log_ok

    cmd_strs = [str(c) for c in command]
    log_cmd(cmd_strs)

    stdout_lines: list[str] = []
    stderr_lines: list[str] = []
    return_code  = [0]

    def _worker() -> None:
        try:
            proc = subprocess.Popen(
                cmd_strs,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='replace',
                cwd=str(cwd) if cwd else None,
            )
            assert proc.stdout is not None
            assert proc.stderr is not None

            def _err() -> None:
                for line in proc.stderr:
                    stderr_lines.append(line.rstrip())

            t = threading.Thread(target=_err, daemon=True)
            t.start()

            for line in proc.stdout:
                stdout_lines.append(line.rstrip())

            proc.wait()
            t.join(timeout=3)
            return_code[0] = proc.returncode
        except Exception as exc:
            stderr_lines.append(str(exc))
            return_code[0] = 1

    with Progress(
        SpinnerColumn(style="bright_green"),
        TextColumn(f"[bright_green]{description}"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(description)
        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
        thread.join()
        progress.update(task, completed=True)

    rc = return_code[0]
    stdout = '\n'.join(stdout_lines)
    stderr = '\n'.join(stderr_lines)

    if rc == 0:
        log_ok(f"Completed: {description}")
    else:
        log_err(f"Failed (exit {rc}): {description}")

    return rc, stdout, stderr
