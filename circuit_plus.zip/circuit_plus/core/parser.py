#!/usr/bin/env python3
"""
CIRCUIT+ — Parse tool output (JSON/XML/text) into Rich tables.
"""
from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich import box
except ImportError:
    pass

from utils.logger import console, log_warn, log_err

# ── ffuf JSON Parser ──────────────────────────────────────────────────────────

def parse_ffuf_json(json_text: str) -> List[Dict[str, Any]]:
    """
    Parse ffuf JSON output into a list of result dicts.

    Args:
        json_text: Raw JSON string from ffuf -o output.
    Returns:
        List of {'url', 'status', 'length', 'words', 'lines'} dicts.
    """
    try:
        data = json.loads(json_text)
        results = data.get("results", [])
        return [
            {
                "url":    r.get("url", ""),
                "status": r.get("status", 0),
                "length": r.get("length", 0),
                "words":  r.get("words", 0),
                "lines":  r.get("lines", 0),
            }
            for r in results
        ]
    except (json.JSONDecodeError, KeyError):
        log_warn("ffuf: JSON parse failed, falling back to text parsing")
        return []


def parse_ffuf_file(path: Path) -> List[Dict[str, Any]]:
    """Parse a ffuf JSON output file."""
    if not path.exists():
        log_err(f"ffuf output not found: {path}")
        return []
    try:
        return parse_ffuf_json(path.read_text(encoding='utf-8'))
    except OSError as e:
        log_err(f"Cannot read {path}: {e}")
        return []


def print_ffuf_results(results: List[Dict[str, Any]]) -> None:
    """Display ffuf results as a Rich table."""
    if not results:
        log_warn("No ffuf results to display.")
        return

    table = Table(
        title="[bold bright_green]// Content Discovery Results[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
    )
    table.add_column("Status", style="bold", width=8, justify="center")
    table.add_column("URL",    style="cyan",  width=55)
    table.add_column("Length", width=8,  justify="right")
    table.add_column("Words",  width=7,  justify="right")

    for i, r in enumerate(results):
        status = r["status"]
        color = _status_color(status)
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(
            f"[{color}]{status}[/{color}]",
            r["url"],
            str(r["length"]),
            str(r["words"]),
            style=style,
        )

    console.print(table)


# ── nuclei JSON-Lines Parser ──────────────────────────────────────────────────

def parse_nuclei_line(line: str) -> Optional[Dict[str, Any]]:
    """
    Parse a single nuclei JSON-line output.

    Args:
        line: One JSON line from nuclei stdout.
    Returns:
        Dict with finding info, or None on parse failure.
    """
    try:
        data = json.loads(line)
        return {
            "template_id": data.get("template-id", "unknown"),
            "name":        data.get("info", {}).get("name", ""),
            "severity":    data.get("info", {}).get("severity", "unknown"),
            "host":        data.get("host", ""),
            "matched":     data.get("matched-at", ""),
            "tags":        ", ".join(data.get("info", {}).get("tags", [])),
        }
    except (json.JSONDecodeError, AttributeError):
        return None


def print_nuclei_finding(finding: Dict[str, Any]) -> None:
    """Print a single nuclei finding with severity color."""
    sev = finding.get("severity", "unknown").lower()
    sev_color = _severity_color(sev)
    console.print(
        f"  [{sev_color}][{sev.upper()}][/{sev_color}] "
        f"[cyan]{finding.get('template_id', '')}[/cyan] "
        f"→ [white]{finding.get('host', '')}[/white] "
        f"[dim]{finding.get('matched', '')}[/dim]"
    )


def print_nuclei_summary(findings: List[Dict[str, Any]]) -> None:
    """Display a summary table of nuclei findings."""
    if not findings:
        console.print("[dim]  No findings.[/dim]")
        return

    table = Table(
        title="[bold bright_green]// Nuclei Findings[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
    )
    table.add_column("Severity",    width=10)
    table.add_column("Template",    style="cyan",  width=30)
    table.add_column("Name",        style="white", width=30)
    table.add_column("Host",        style="dim",   width=35)
    table.add_column("Matched",     style="dim",   width=40)

    for i, f in enumerate(findings):
        sev = f.get("severity", "unknown").lower()
        color = _severity_color(sev)
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(
            f"[{color}]{sev.upper()}[/{color}]",
            f.get("template_id", ""),
            f.get("name", ""),
            f.get("host", ""),
            f.get("matched", ""),
            style=style,
        )

    console.print(table)


# ── nmap / RustScan Parsers ───────────────────────────────────────────────────

def parse_rustscan_ports(output: str) -> List[int]:
    """
    Extract open port numbers from rustscan stdout.

    Args:
        output: Raw rustscan stdout text.
    Returns:
        Sorted list of open port numbers.
    """
    ports: list[int] = []
    # RustScan outputs: "Open 192.168.1.1:22"
    for line in output.splitlines():
        match = re.search(r':(\d+)', line)
        if match and 'Open' in line:
            try:
                ports.append(int(match.group(1)))
            except ValueError:
                pass
    return sorted(set(ports))


def parse_nmap_xml(xml_path: Path) -> List[Dict[str, Any]]:
    """
    Parse nmap XML output into structured host/port dicts.

    Args:
        xml_path: Path to .xml file from nmap -oX.
    Returns:
        List of host dicts with 'host', 'ports' fields.
    """
    if not xml_path.exists():
        log_err(f"nmap XML not found: {xml_path}")
        return []

    results: list[Dict[str, Any]] = []
    try:
        tree = ET.parse(str(xml_path))
        root = tree.getroot()

        for host_el in root.findall('.//host'):
            addr_el = host_el.find('address[@addrtype="ipv4"]')
            hostname_el = host_el.find('.//hostname')
            address = addr_el.attrib.get('addr', 'unknown') if addr_el is not None else 'unknown'
            hostname = hostname_el.attrib.get('name', '') if hostname_el is not None else ''

            ports: list[Dict[str, str]] = []
            for port_el in host_el.findall('.//port'):
                state_el  = port_el.find('state')
                service_el = port_el.find('service')
                if state_el is not None and state_el.attrib.get('state') == 'open':
                    ports.append({
                        'port':     port_el.attrib.get('portid', ''),
                        'protocol': port_el.attrib.get('protocol', 'tcp'),
                        'service':  service_el.attrib.get('name', '') if service_el is not None else '',
                        'version':  service_el.attrib.get('version', '') if service_el is not None else '',
                        'product':  service_el.attrib.get('product', '') if service_el is not None else '',
                    })

            if ports:
                results.append({'host': address, 'hostname': hostname, 'ports': ports})

    except (ET.ParseError, OSError) as e:
        log_err(f"nmap XML parse error: {e}")

    return results


def print_nmap_results(results: List[Dict[str, Any]]) -> None:
    """Display nmap results as a Rich table."""
    if not results:
        console.print("[dim]  No open ports found.[/dim]")
        return

    table = Table(
        title="[bold bright_green]// Port Scan Results[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
    )
    table.add_column("Host",     style="cyan",  width=18)
    table.add_column("Port",     style="bold",  width=7,  justify="center")
    table.add_column("Proto",    style="dim",   width=6)
    table.add_column("Service",  style="white", width=14)
    table.add_column("Version",  style="dim",   width=28)

    for host_data in results:
        host = host_data['host']
        hostname = host_data.get('hostname', '')
        host_str = f"{host} ({hostname})" if hostname else host
        for i, port in enumerate(host_data['ports']):
            style = "on grey11" if i % 2 == 0 else ""
            table.add_row(
                host_str if i == 0 else "",
                port['port'],
                port['protocol'],
                port['service'],
                f"{port.get('product','')} {port.get('version','')}".strip(),
                style=style,
            )

    console.print(table)


# ── httpx Parser ──────────────────────────────────────────────────────────────

def parse_httpx_jsonl(output: str) -> List[Dict[str, Any]]:
    """
    Parse httpx JSON-lines output.

    Args:
        output: Raw stdout from httpx -json.
    Returns:
        List of host info dicts.
    """
    results: list[Dict[str, Any]] = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
            results.append({
                'url':    data.get('url', ''),
                'status': data.get('status_code', 0),
                'title':  data.get('title', ''),
                'tech':   ', '.join(data.get('tech', [])),
                'server': data.get('webserver', ''),
                'ip':     data.get('host', ''),
            })
        except (json.JSONDecodeError, KeyError):
            # If not JSON, parse plain text
            if line.startswith('http'):
                results.append({'url': line, 'status': 0, 'title': '', 'tech': '', 'server': '', 'ip': ''})

    return results


def print_httpx_results(results: List[Dict[str, Any]]) -> None:
    """Display httpx results in a Rich table."""
    if not results:
        console.print("[dim]  No live hosts.[/dim]")
        return

    table = Table(
        title="[bold bright_green]// Live Web Hosts[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        expand=False,
    )
    table.add_column("Status", width=8,  justify="center")
    table.add_column("URL",    style="cyan", width=45)
    table.add_column("Title",  style="white", width=30)
    table.add_column("Tech",   style="dim green", width=25)
    table.add_column("Server", style="dim", width=15)

    for i, r in enumerate(results):
        color = _status_color(r.get('status', 0))
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(
            f"[{color}]{r.get('status', '')}[/{color}]",
            r.get('url', ''),
            r.get('title', '')[:29],
            r.get('tech', '')[:24],
            r.get('server', '')[:14],
            style=style,
        )

    console.print(table)


# ── Subdomain List Parser ─────────────────────────────────────────────────────

def print_subdomain_list(subdomains: List[str], title: str = "Subdomains") -> None:
    """Display a list of subdomains in a compact table."""
    if not subdomains:
        console.print("[dim]  No subdomains found.[/dim]")
        return

    table = Table(
        title=f"[bold bright_green]// {title} ({len(subdomains)})[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        header_style="bold bright_green",
        show_header=True,
    )
    table.add_column("#",   width=5,  justify="right", style="dim")
    table.add_column("Subdomain", style="cyan", width=50)

    for i, sub in enumerate(subdomains[:200]):  # cap display
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(str(i + 1), sub, style=style)

    if len(subdomains) > 200:
        table.add_row("...", f"[dim]+{len(subdomains) - 200} more (see output file)[/dim]")

    console.print(table)


# ── Color Helpers ─────────────────────────────────────────────────────────────

def _status_color(status: int) -> str:
    """Map HTTP status code to Rich color name."""
    if 200 <= status < 300:
        return "bold green"
    elif 300 <= status < 400:
        return "bold cyan"
    elif 400 <= status < 500:
        return "bold yellow"
    elif 500 <= status < 600:
        return "bold red"
    else:
        return "dim"


def _severity_color(severity: str) -> str:
    """Map nuclei severity to Rich color name."""
    mapping = {
        "critical": "bold red",
        "high":     "red",
        "medium":   "yellow",
        "low":      "green",
        "info":     "cyan",
        "unknown":  "dim",
    }
    return mapping.get(severity.lower(), "dim")
