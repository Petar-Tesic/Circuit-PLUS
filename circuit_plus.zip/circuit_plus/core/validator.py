#!/usr/bin/env python3
"""
CIRCUIT+ — Binary dependency checker with install hints.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import Dict, List, Tuple, Optional

try:
    from rich.console import Console
    from rich.table import Table
    from rich import box
except ImportError:
    pass

console = Console(highlight=False)

# ── Tool Registry ─────────────────────────────────────────────────────────────
# Maps tool name → (description, install hint, required/optional)
TOOL_REGISTRY: Dict[str, Tuple[str, str, bool]] = {
    # Core / always-needed
    "nmap":        ("Port scanner",                 "sudo apt install nmap",                       True),
    "curl":        ("HTTP client",                  "sudo apt install curl",                       True),
    "git":         ("Version control",              "sudo apt install git",                        True),

    # Recon
    "subfinder":   ("Subdomain enum",               "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest", False),
    "amass":       ("OWASP subdomain enum",         "go install github.com/owasp-amass/amass/v4/...@master",                   False),
    "dnsx":        ("DNS resolver/toolkit",         "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest",             False),
    "massdns":     ("Fast DNS bruteforcer",         "Build from: github.com/blechschmidt/massdns",                            False),
    "alterx":      ("Subdomain permutations",       "go install github.com/projectdiscovery/alterx/cmd/alterx@latest",        False),

    # Web
    "httpx":       ("HTTP prober/tech detect",      "go install github.com/projectdiscovery/httpx/cmd/httpx@latest",          False),
    "ffuf":        ("Web fuzzer",                   "go install github.com/ffuf/ffuf/v2@latest",                              False),
    "nuclei":      ("Vulnerability scanner",        "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",     False),
    "katana":      ("Web crawler",                  "go install github.com/projectdiscovery/katana/cmd/katana@latest",        False),
    "gau":         ("URL harvester",                "go install github.com/lc/gau/v2/cmd/gau@latest",                        False),
    "feroxbuster": ("Recursive content discovery",  "cargo install feroxbuster",                                              False),

    # Network
    "rustscan":    ("Fast port scanner",            "cargo install rustscan",                                                  False),
    "masscan":     ("Mass IP scanner",              "sudo apt install masscan",                                                False),
    "naabu":       ("Port scanner (PD)",            "go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",       False),
}

# Required-only subset for quick checks
REQUIRED_TOOLS = [name for name, (_, _, req) in TOOL_REGISTRY.items() if req]


# ── Check Functions ───────────────────────────────────────────────────────────
def check_dependency(binary: str) -> bool:
    """
    Return True if `binary` is found in PATH via shutil.which.

    Args:
        binary: Executable name to check.
    Returns:
        True if found, False if missing.
    """
    return shutil.which(binary) is not None


def check_all() -> Dict[str, bool]:
    """
    Check all registered tools.

    Returns:
        Dict mapping tool name → found (bool).
    """
    return {name: check_dependency(name) for name in TOOL_REGISTRY}


def check_required() -> List[str]:
    """
    Return list of required tools that are missing.
    """
    return [t for t in REQUIRED_TOOLS if not check_dependency(t)]


def get_version(binary: str) -> Optional[str]:
    """
    Attempt to get the version string of a binary.

    Args:
        binary: Executable name.
    Returns:
        Version string, or None if not available.
    """
    for flag in ["--version", "-version", "version", "-V"]:
        try:
            result = subprocess.run(
                [binary, flag],
                capture_output=True,
                text=True,
                timeout=5
            )
            output = (result.stdout + result.stderr).strip()
            if output:
                # Return first non-empty line
                for line in output.splitlines():
                    if line.strip():
                        return line.strip()[:60]
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            continue
    return None


# ── Rich Table Display ────────────────────────────────────────────────────────
def print_tool_status() -> None:
    """
    Print a Rich table showing all tools, their status, and install hints.
    """
    results = check_all()

    table = Table(
        title="[bold bright_green]// Tool Dependency Status[/bold bright_green]",
        box=box.SIMPLE_HEAVY,
        border_style="bright_green",
        show_header=True,
        header_style="bold bright_green",
        expand=False,
    )

    table.add_column("Tool",        style="bold cyan",  width=14)
    table.add_column("Category",    style="dim",        width=12)
    table.add_column("Status",      width=10)
    table.add_column("Description", style="dim",        width=28)
    table.add_column("Install",     style="dim green",  width=36)

    # Group by category
    categories: Dict[str, List[str]] = {
        "Core":    ["nmap", "curl", "git"],
        "Recon":   ["subfinder", "amass", "dnsx", "massdns", "alterx"],
        "Web":     ["httpx", "ffuf", "nuclei", "katana", "gau", "feroxbuster"],
        "Network": ["rustscan", "masscan", "naabu"],
    }

    for category, tools in categories.items():
        for i, tool in enumerate(tools):
            if tool not in TOOL_REGISTRY:
                continue
            desc, hint, required = TOOL_REGISTRY[tool]
            found = results.get(tool, False)
            req_tag = "[red]★[/red]" if required else " "
            status = "[bold green]✓ FOUND[/bold green]" if found else "[bold red]✗ MISSING[/bold red]"
            row_style = "on grey11" if i % 2 == 0 else ""

            # Truncate hint for display
            display_hint = hint[:35] + "…" if len(hint) > 35 else hint

            table.add_row(
                f"{req_tag} {tool}",
                category,
                status,
                desc,
                display_hint,
                style=row_style,
            )

    console.print(table)
    console.print("[dim]  [red]★[/red] = required tool  |  Others are optional (warn on use)[/dim]")

    missing_required = check_required()
    if missing_required:
        console.print(f"\n[bold red][!] Missing required tools: {', '.join(missing_required)}[/bold red]")
        console.print("[dim]    Run: [cyan]bash install.sh[/cyan] to install dependencies[/dim]")
    else:
        console.print("\n[bold green][+] All required tools present.[/bold green]")


def assert_tool(binary: str) -> bool:
    """
    Check a tool; print error with install hint if missing.

    Args:
        binary: Tool name.
    Returns:
        True if found, False if missing (after printing error).
    """
    if check_dependency(binary):
        return True

    console.print(f"\n[bold red][!] Tool not found:[/bold red] [cyan]{binary}[/cyan]")
    if binary in TOOL_REGISTRY:
        _, hint, _ = TOOL_REGISTRY[binary]
        console.print(f"[dim]    Install with:[/dim] [green]{hint}[/green]")
    else:
        console.print(f"[dim]    Ensure '{binary}' is in your PATH.[/dim]")
    return False
