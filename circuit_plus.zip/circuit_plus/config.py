#!/usr/bin/env python3
"""
CIRCUIT+ — Configuration Module  v1.01
Pydantic v1 AND v2 compatible. No version-specific imports at module level.
XDG Base Directory spec (~/.config/circuit_plus/config.json).

Exports:
    Config, ToolPaths
    load_config, save_config, config_exists, ensure_dirs,
    append_history, update_config, check_linux,
    CONFIG_DIR, CONFIG_FILE, HISTORY_FILE, INSTALL_HINTS
"""
from __future__ import annotations

import json
import sys
import platform
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Runtime dependency check ─────────────────────────────────────────────────
try:
    import pydantic as _pydantic
    from platformdirs import user_config_dir, user_data_dir
except ImportError as _ie:
    print(f"[!] Missing dependency: {_ie}")
    print("    Run: bash install.sh")
    sys.exit(1)

# ── Pydantic version sniff ────────────────────────────────────────────────────
_PYDANTIC_MAJOR: int = int(_pydantic.VERSION.split(".")[0])
_V2: bool = _PYDANTIC_MAJOR >= 2

APP_VERSION = "1.1"
randomfuckassvariable = 2 #Im sorry

# ── XDG Paths ─────────────────────────────────────────────────────────────────
CONFIG_DIR   = Path(user_config_dir("circuit_plus"))
DATA_DIR     = Path(user_data_dir("circuit_plus"))
CONFIG_FILE  = CONFIG_DIR / "config.json"
HISTORY_FILE = CONFIG_DIR / "history.json"
DEFAULT_WORDLIST_DIR = str(Path.home() / ".local" / "share" / "wordlists")

# ── Install hints ─────────────────────────────────────────────────────────────
INSTALL_HINTS: Dict[str, str] = {
    "subfinder":   "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
    "httpx":       "go install github.com/projectdiscovery/httpx/cmd/httpx@latest",
    "dnsx":        "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
    "nuclei":      "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
    "katana":      "go install github.com/projectdiscovery/katana/cmd/katana@latest",
    "alterx":      "go install github.com/projectdiscovery/alterx/cmd/alterx@latest",
    "naabu":       "go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
    "ffuf":        "go install github.com/ffuf/ffuf/v2@latest",
    "gau":         "go install github.com/lc/gau/v2/cmd/gau@latest",
    "amass":       "go install github.com/owasp-amass/amass/v4/...@master",
    "massdns":     "apt install massdns  OR  build: https://github.com/blechschmidt/massdns",
    "nmap":        "sudo apt install nmap",
    "masscan":     "sudo apt install masscan",
    "rustscan":    "cargo install rustscan",
    "feroxbuster": "cargo install feroxbuster",
    "curl":        "sudo apt install curl",
    "git":         "sudo apt install git",
}

# its in a oh dictioea is march is the ae50 76 help
from pydantic import BaseModel, Field   # BaseModel + Field exist in both v1 and v2

if _V2:
    # ── Pydantic v2 path ──────────────────────────────────────────────────────
    from pydantic import field_validator
    from pydantic import ConfigDict as _ConfigDict

    class ToolPaths(BaseModel):
        """Optional binary path overrides (None = use PATH)."""
        model_config = _ConfigDict(extra="ignore")

        subfinder:   Optional[str] = None
        httpx:       Optional[str] = None
        dnsx:        Optional[str] = None
        nuclei:      Optional[str] = None
        katana:      Optional[str] = None
        ffuf:        Optional[str] = None
        nmap:        Optional[str] = None
        masscan:     Optional[str] = None
        rustscan:    Optional[str] = None
        feroxbuster: Optional[str] = None
        gau:         Optional[str] = None
        alterx:      Optional[str] = None
        amass:       Optional[str] = None
        massdns:     Optional[str] = None

        def resolve(self, tool: str) -> str:
            return getattr(self, tool, None) or tool

    class Config(BaseModel):
        """CIRCUIT+ operator configuration (Pydantic v2)."""
        model_config = _ConfigDict(extra="ignore")

        operator_name:   str       = "operator"
        wordlist_path:   str       = DEFAULT_WORDLIST_DIR
        threads:         int       = Field(default=50,    ge=1, le=500)
        timeout:         int       = Field(default=30,    ge=5, le=300)
        loot_dir:        str       = "./loot"
        rate_limit:      int       = Field(default=10000, ge=1)
        nuclei_severity: str       = "critical,high,medium"
        tools:           ToolPaths = Field(default_factory=ToolPaths)
        first_run:       bool      = True

        @field_validator("threads", mode="before")
        @classmethod
        def _clamp_threads(cls, v: Any) -> int:
            return max(1, min(int(v), 500))

        @property
        def loot_path(self) -> Path:
            return Path(self.loot_dir)

        @property
        def wordlist_path_obj(self) -> Path:
            return Path(self.wordlist_path)

else:
    # ── Pydantic v1 path ──────────────────────────────────────────────────────
    from pydantic import validator as _v1_validator

    class ToolPaths(BaseModel):  # type: ignore[no-redef]
        """Optional binary path overrides (None = use PATH)."""

        subfinder:   Optional[str] = None
        httpx:       Optional[str] = None
        dnsx:        Optional[str] = None
        nuclei:      Optional[str] = None
        katana:      Optional[str] = None
        ffuf:        Optional[str] = None
        nmap:        Optional[str] = None
        masscan:     Optional[str] = None
        rustscan:    Optional[str] = None
        feroxbuster: Optional[str] = None
        gau:         Optional[str] = None
        alterx:      Optional[str] = None
        amass:       Optional[str] = None
        massdns:     Optional[str] = None

        def resolve(self, tool: str) -> str:
            return getattr(self, tool, None) or tool

        class Config:           # pydantic v1 inner config class
            extra = "ignore"

    class Config(BaseModel):    # type: ignore[no-redef]
        """CIRCUIT+ operator configuration (Pydantic v1)."""

        operator_name:   str       = "operator"
        wordlist_path:   str       = DEFAULT_WORDLIST_DIR
        threads:         int       = Field(default=50)
        timeout:         int       = Field(default=30)
        loot_dir:        str       = "./loot"
        rate_limit:      int       = Field(default=10000)
        nuclei_severity: str       = "critical,high,medium"
        tools:           ToolPaths = Field(default_factory=ToolPaths)
        first_run:       bool      = True

        @_v1_validator("threads", pre=True, always=True)
        @classmethod
        def _clamp_threads(cls, v: Any) -> int:
            return max(1, min(int(v), 500))

        @property
        def loot_path(self) -> Path:
            return Path(self.loot_dir)

        @property
        def wordlist_path_obj(self) -> Path:
            return Path(self.wordlist_path)

        class Config:           # pydantic v1 inner config class
            extra = "ignore"


# ── Serialisation helper ──────────────────────────────────────────────────────
def _cfg_to_dict(cfg: "Config") -> Dict[str, Any]:
    """Convert Config to plain dict regardless of pydantic version."""
    if _V2:
        raw: Dict[str, Any] = cfg.model_dump()      # type: ignore[union-attr]
    else:
        raw = cfg.dict()                             # type: ignore[union-attr]
    # Ensure nested ToolPaths serialises as plain dict
    if "tools" in raw and not isinstance(raw["tools"], dict):
        raw["tools"] = {}
    return raw


# ── Public API ────────────────────────────────────────────────────────────────
def config_exists() -> bool:
    """Return True if a config file already exists on disk."""
    return CONFIG_FILE.exists()


def load_config() -> "Config":
    """
CIRCUIT+ — Configuration, XDG paths, and persistent settings.
    """
    if not CONFIG_FILE.exists():
        return Config()
    try:
        raw: Dict[str, Any] = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if "tools" in raw and isinstance(raw["tools"], dict):
            raw["tools"] = ToolPaths(**raw["tools"])
        return Config(**raw)
    except Exception:
        return Config()


def save_config(cfg: "Config") -> None:
    """Write Config to ~/.config/circuit_plus/config.json (pretty-printed JSON)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = _cfg_to_dict(cfg)
    CONFIG_FILE.write_text(
        json.dumps(data, indent=2, default=str),
        encoding="utf-8",
    )


def ensure_dirs(cfg: "Config") -> None:
    """Create all required runtime directories."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    Path(cfg.loot_dir).mkdir(parents=True, exist_ok=True)


def update_config(cfg: "Config", **kwargs: Any) -> "Config":
    """
    Return a new Config with the specified fields changed.
    Works with both Pydantic v1 and v2.

    Example:
        cfg = update_config(cfg, operator_name="ghost", threads=100)
    """
    data = _cfg_to_dict(cfg)
    if "tools" in data and isinstance(data["tools"], dict):
        data["tools"] = ToolPaths(**data["tools"])
    data.update(kwargs)
    return Config(**data)


def append_history(entry: Dict[str, Any]) -> None:
    """Append one action entry to history.json (capped at 500 entries)."""
    history: List[Dict[str, Any]] = []
    if HISTORY_FILE.exists():
        try:
            loaded = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(loaded, list):
                history = loaded
        except (json.JSONDecodeError, OSError):
            pass
    history.append(entry)
    history = history[-500:]
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    HISTORY_FILE.write_text(
        json.dumps(history, indent=2, default=str),
        encoding="utf-8",
    )


def check_linux() -> None:
    """Exit with a clear message if not running on Linux."""
    if platform.system() != "Linux":
        print(f"\033[31m[!] CIRCUIT+ requires Linux. Detected: {platform.system()}\033[0m")
        sys.exit(1)

# ── Extended config fields (v1.1) ─────────────────────────────────────────────
# These are stored as a separate JSON sidecar so they don't break Pydantic
# validation on the main Config model which must stay backward compatible.

_EXTENDED_FILE = CONFIG_DIR / "extended.json"

def load_extended() -> Dict[str, Any]:
    """Load extended v1.1 settings (proxy, notify, scope, sessions)."""
    if _EXTENDED_FILE.exists():
        try:
            return json.loads(_EXTENDED_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

def save_extended(data: Dict[str, Any]) -> None:
    """Persist extended settings."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    existing = load_extended()
    existing.update(data)
    _EXTENDED_FILE.write_text(json.dumps(existing, indent=2), encoding="utf-8")

def get_ext(key: str, default: Any = None) -> Any:
    return load_extended().get(key, default)

def set_ext(key: str, value: Any) -> None:
    save_extended({key: value})
