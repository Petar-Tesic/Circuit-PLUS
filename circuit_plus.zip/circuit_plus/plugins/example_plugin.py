#!/usr/bin/env python3
"""
CIRCUIT+ Plugin Example — robots.txt & sitemap.xml checker

Drop any .py file in the plugins/ directory with these attributes:
  PLUGIN_NAME        str   — displayed in the plugin menu
  PLUGIN_DESC        str   — one-line description
  PLUGIN_VERSION     str   — semver string
  PLUGIN_AUTHOR      str   — your handle
  run(cfg) -> None         — called when user selects this plugin
"""
from __future__ import annotations

# ── Plugin metadata ───────────────────────────────────────────────────────────
PLUGIN_NAME    = "robots.txt / sitemap Inspector"
PLUGIN_DESC    = "Fetch robots.txt and sitemap.xml, highlight juicy paths"
PLUGIN_VERSION = "1.0"
PLUGIN_AUTHOR  = "circuit-community"

# ── Plugin implementation ─────────────────────────────────────────────────────
import shutil
import subprocess
from pathlib import Path

from rich.panel import Panel
from rich.syntax import Syntax

from utils.logger import console, log_ok, log_err, log_info, log_warn
from utils.helpers import normalize_url, make_loot_dir, timestamp
from config import Config


def run(cfg: Config) -> None:
    """Main plugin entry point — called by the plugin loader."""
    console.print(Panel(
        f"  [bold]{PLUGIN_NAME}[/bold]\n"
        f"  [dim]{PLUGIN_DESC}[/dim]",
        border_style="bright_green", expand=False,
    ))

    try:
        url = input("\033[92m[?] Target URL: \033[0m").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if not url:
        return

    url   = normalize_url(url)
    host  = url.replace("https://","").replace("http://","").split("/")[0]
    loot  = make_loot_dir(cfg.loot_path, host, "plugins")

    if not shutil.which("curl"):
        log_err("curl not found.")
        return

    juicy_patterns = [
        "/admin", "/backup", "/api", "/internal", "/secret",
        "/private", "/config", "/upload", "/login", "/dev",
        "/.git", "/.env", "/staging", "/test", "/debug",
    ]

    for resource in ("robots.txt", "sitemap.xml", "sitemap_index.xml"):
        target_url = f"{url}/{resource}"
        log_info(f"Fetching {target_url}")
        r = subprocess.run(
            ["curl", "-sL", "--max-time", "10", target_url],
            capture_output=True, text=True, timeout=15,
        )
        if r.returncode != 0 or len(r.stdout) < 10:
            log_warn(f"Not found: {resource}")
            continue

        content = r.stdout
        # Save
        #awme[fopiawnemgone4o[tinwo[w]riobaw[orenbo[wernia[oiwenroainweionrgoonie[
        out = loot / resource
        out.write_text(content, encoding="utf-8")
        log_ok(f"Saved {resource} ({len(content)} bytes)")

        # Highlight
        lexer = "xml" if resource.endswith(".xml") else "text"
        console.print(Syntax(content[:3000], lexer, theme="monokai",
                              line_numbers=False, word_wrap=True))

        # Flag juicy paths
        found_juicy = [p for p in juicy_patterns if p in content.lower()]
        if found_juicy:
            console.print(
                f"\n  [bold yellow]⚑ Interesting paths found:[/bold yellow] "
                + ", ".join(found_juicy)
            )
