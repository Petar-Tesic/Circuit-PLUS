# CIRCUIT+
### Offensive Security Framework — v1.1

```
  ██████╗██╗██████╗  ██████╗██╗   ██╗██╗████████╗ ██╗
 ██╔════╝██║██╔══██╗██╔════╝██║   ██║██║╚══██╔══╝ ╚═╝
 ██║     ██║██████╔╝██║     ██║   ██║██║   ██║
 ██║     ██║██╔══██╗██║     ██║   ██║██║   ██║
 ╚██████╗██║██║  ██║╚██████╗╚██████╔╝██║   ██║  ██╗
  ╚═════╝╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝   ╚═╝  ╚═╝
```

> **For authorized penetration testing and security research only.**
> Always obtain written permission before testing any target you do not own.

---

## Quick Start

```bash
bash install.sh      # Detect distro, install deps
python3 main.py      # Launch CIRCUIT+
```

On first launch: setup wizard walks through operator alias, wordlist directory, and tool check.

---

## Navigation

CIRCUIT+ uses a **hub-and-spoke** menu:

| Section | Contents |
|---|---|
| **A — Scanning & Recon** | Recon · Web · Network · Total Recon · Mass Scan · Mods |
| **B — OSINT & Intel** | Cloud Enum · CVE Correlator · Scan Diff · Screenshots |
| **C — Utilities** | Toolkit · Plugins · Loot Browser · Sessions · Scope · Tutorial |
| **D — Settings** | Config · Install Manager · Notifications · History · Export |

---

## Key Features

**Total Recon (A→6)** — 16-phase comprehensive scan: subdomain enum → DNS brute → permutations → host probe → port scan → web crawl → content discovery → vuln scan → cloud enum → SSL audit → tech fingerprint → CVE correlation → whois/GeoIP → screenshots → backup hunt → full HTML report.

**Mass Scan (A→5)** — 10-phase quick intel dump on any IP/domain/URL.

**Mods (A→7)** — FSCF scripting language. Drop `.fscf` files into `Modifs/` to add automation scripts. Syntax: `var = input("prompt")`, `sys(command {var})`, `print("text {var}")`.

**Install Manager (D→2)** — Installs 60+ security tools (Go/Rust/apt/dnf/pacman/zypper), wordlists, and Nuclei templates with one menu.

---

## Config & Loot

| Path | Purpose |
|---|---|
| `~/.config/circuit_plus/config.json` | Operator settings |
| `~/.config/circuit_plus/scope.txt` | Authorized target scope |
| `~/.config/circuit_plus/sessions/` | Saved scan sessions |
| `./loot/{target}/{timestamp}/{module}/` | All scan output |

---

## Requirements

- Linux (Ubuntu, Kali, Parrot, Arch, Fedora, etc.)
- Python 3.10+
- `nmap`, `curl`, `git` (required) — others optional, installed via Install Manager

---

## Tutorial

New to CIRCUIT+? Run the built-in tutorial: **C → 6 → Tutorial**

---

*CIRCUIT+ — Authorized Use Only*

*Note: i didnt write this fuckass md i hate typing them*
