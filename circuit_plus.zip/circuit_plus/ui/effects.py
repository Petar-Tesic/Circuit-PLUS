#!/usr/bin/env python3
"""
CIRCUIT+ — Terminal effects: typewriter, glitch, clear, pause.
"""

from __future__ import annotations

import os
import random
import sys
import time

from rich.console import Console

console = Console()

_GLITCH_CHARS = "!@#$%^&*<>?/\\|{}[]~`░▒▓█▄▀■□▪▫"


def clear_screen() -> None:
    """Clear the terminal completely."""
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def typewriter(
    text: str,
    color: str = "bright_green",
    delay: float = 0.05,
    newline: bool = True,
) -> None:
    """
    Print text one character at a time with a delay.

    Args:
        text:    Text to display.
        color:   Rich color string.
        delay:   Seconds between characters.
        newline: Print trailing newline.
    """
    for char in text:
        console.print(char, style=color, end="", highlight=False)
        sys.stdout.flush()
        time.sleep(delay)
    if newline:
        print()


def glitch_effect(text: str, duration: float = 0.6, cycles: int = 8) -> None:
    """
    Briefly corrupt `text` with random characters, then restore it.

    Args:
        text:     Original text to glitch.
        duration: Total glitch duration in seconds.
        cycles:   Number of glitch frames.
    """
    interval = duration / cycles
    for _ in range(cycles):
        glitched = "".join(
            random.choice(_GLITCH_CHARS) if random.random() < 0.35 else ch
            for ch in text
        )
        sys.stdout.write(f"\r\033[32m{glitched}\033[0m")
        sys.stdout.flush()
        time.sleep(interval)
    sys.stdout.write(f"\r\033[32m{text}\033[0m\n")
    sys.stdout.flush()


def countdown_bar(seconds: int, label: str = "Loading") -> None:
    """Simple ASCII countdown with overwrite."""
    width = 30
    for i in range(seconds * 10):
        filled = int((i / (seconds * 10)) * width)
        bar = "█" * filled + "░" * (width - filled)
        pct = int((i / (seconds * 10)) * 100)
        sys.stdout.write(f"\r\033[32m[*] {label}: [{bar}] {pct}%\033[0m")
        sys.stdout.flush()
        time.sleep(0.1)
    sys.stdout.write(f"\r\033[32m[+] {label}: [{'█' * width}] 100%\033[0m\n")
    sys.stdout.flush()


def spinner_message(message: str, duration: float = 2.0) -> None:
    """Spin a simple ASCII spinner next to a message."""
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    end_time = time.time() + duration
    i = 0
    while time.time() < end_time:
        sys.stdout.write(f"\r\033[36m {frames[i % len(frames)]}  {message}\033[0m")
        sys.stdout.flush()
        time.sleep(0.08)
        i += 1
    sys.stdout.write(f"\r\033[32m [+] {message} — done\033[0m\n")
    sys.stdout.flush()


def typewriter_line(
    text: str,
    color: str = "bright_green",
    delay: float = 0.045,
) -> None:

    typewriter(text, color=color, delay=delay, newline=True)


def pause(seconds: float = 2.0) -> None:
    """Non-interactive sleep."""
    time.sleep(seconds)


def press_enter(msg: str = "Press [ENTER] to continue...") -> None:
    """Block until the user hits Enter."""
    try:
        input(f"\033[2m{msg}\033[0m")
    except (KeyboardInterrupt, EOFError):
        pass
