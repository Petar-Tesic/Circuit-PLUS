#!/usr/bin/env python3
"""
CIRCUIT+ — Cinematic startup sequence with ASCII art reveal.
"""
from __future__ import annotations

import os
import random
import sys
import subprocess
import time

# ── ASCII Art ─────────────────────────────────────────────────────────────────

CIRCUIT_PLUS_ART = r"""
________/\\\\\\\\\_        
 _____/\\\////////__       
  ___/\\\/___________      
   __/\\\_____________     
    _\/\\\_____________    
     _\//\\\____________   
      __\///\\\__________  
       ____\////\\\\\\\\\_ 
        _______\/////////__
__/\\\\\\\\\\\_            
 _\/////\\\///__           
  _____\/\\\_____          
   _____\/\\\_____         
    _____\/\\\_____        
     _____\/\\\_____       
      _____\/\\\_____      
       __/\\\\\\\\\\\_     
        _\///////////__    
____/\\\\\\\\\_____        
 __/\\\///////\\\___       
  _\/\\\_____\/\\\___      
   _\/\\\\\\\\\\\/____     
    _\/\\\//////\\\____    
     _\/\\\____\//\\\___   
      _\/\\\_____\//\\\__  
       _\/\\\______\//\\\_ 
        _\///________\///__
________/\\\\\\\\\_        
 _____/\\\////////__       
  ___/\\\/___________      
   __/\\\_____________     
    _\/\\\_____________    
     _\//\\\____________   
      __\///\\\__________  
       ____\////\\\\\\\\\_ 
        _______\/////////__
__/\\\________/\\\_        
 _\/\\\_______\/\\\_       
  _\/\\\_______\/\\\_      
   _\/\\\_______\/\\\_     
    _\/\\\_______\/\\\_    
     _\/\\\_______\/\\\_   
      _\//\\\______/\\\__  
       __\///\\\\\\\\\/___ 
        ____\/////////_____
__/\\\\\\\\\\\_            
 _\/////\\\///__           
  _____\/\\\_____          
   _____\/\\\_____         
    _____\/\\\_____        
     _____\/\\\_____       
      _____\/\\\_____      
       __/\\\\\\\\\\\_     
        _\///////////__    
__/\\\\\\\\\\\\\\\_        
 _\///////\\\/////__       
  _______\/\\\_______      
   _______\/\\\_______     
    _______\/\\\_______    
     _______\/\\\_______   
      _______\/\\\_______  
       _______\/\\\_______ 
        _______\///________
"""

# ── Terminal resize ───────────────────────────────────────────────────────────

def resize_terminal(cols: int = 120, rows: int = 40) -> None:
    try:
        sys.stdout.write(f"\033[8;{rows};{cols}t")
        sys.stdout.flush()
        time.sleep(0.15)   # give the terminal time to actually resize
    except Exception:
        pass


# ── Helpers ───────────────────────────────────────────────────────────────────

_GREEN       = "\033[32m"
_BRIGHT_GREEN = "\033[92m"
_DIM         = "\033[2m"
_BOLD        = "\033[1m"
_RED         = "\033[31m"
_WHITE       = "\033[97m"
_RESET       = "\033[0m"
_CLEAR       = "\033[2J\033[H"


def _write(text: str) -> None:
    sys.stdout.write(text)
    sys.stdout.flush()


def _clear() -> None:
    _write(_CLEAR)


def _center_text(text: str, width: int = 78) -> str:
    """Center a string, ignoring ANSI escape codes for width calculation."""
    import re
    visible = re.sub(r'\033\[[0-9;]*m', '', text)
    pad = max(0, (width - len(visible)) // 2)
    return " " * pad + text


# ── ASCII art line-by-line reveal ─────────────────────────────────────────────

def _show_art_line_by_line(delay: float = 0.018) -> None:
    """
    Print each line of CIRCUIT_PLUS_ART one at a time with a tiny delay,
    giving a draw-in effect. Lines outside the terminal width are not truncated.
    """
    _clear()
    lines = CIRCUIT_PLUS_ART.split("\n")
    for line in lines:
        _write(f"{_GREEN}{line}{_RESET}\n")
        time.sleep(delay)


# ── tuff text moments ────────────────────────────────────────────────────

def _flicker(text: str, color: str = _WHITE, flickers: int = 4) -> None:
    """Very fast blink then hold — like a CRT powering on."""
    for i in range(flickers):
        _write(f"\r{color}{text}{_RESET}")
        time.sleep(0.06)
        _write(f"\r{' ' * len(text)}")
        time.sleep(0.03)
    _write(f"\r{color}{text}{_RESET}\n")


def _typewrite_slow(text: str, color: str = _WHITE, delay: float = 0.09) -> None:
    """Slow typewriter — each char, long delay."""
    for ch in text:
        _write(f"{color}{ch}{_RESET}")
        time.sleep(delay)
    _write("\n")


def _typewrite_fast(text: str, color: str = _GREEN, delay: float = 0.03) -> None:
    for ch in text:
        _write(f"{color}{ch}{_RESET}")
        time.sleep(delay)
    _write("\n")


def _glitch_line(text: str, duration: float = 0.4, color: str = _GREEN) -> None:
    """Corrupt a line of text briefly then show original."""
    _GLITCH = "!@#$%^&*<>/\\|{}[]~`░▒▓"
    end = time.time() + duration
    while time.time() < end:
        g = "".join(
            random.choice(_GLITCH) if random.random() < 0.4 else c
            for c in text
        )
        _write(f"\r{color}{g}{_RESET}")
        time.sleep(0.04)
    _write(f"\r{color}{text}{_RESET}\n")


def _flash_clear(times: int = 3, on_ms: float = 0.07, off_ms: float = 0.04) -> None:
    """Flash the screen by alternating clear/restore content rapidly."""
    for _ in range(times):
        _write(_CLEAR)
        time.sleep(off_ms)
        _write("\033[H")          # cursor home — content stays, just repositions
        time.sleep(on_ms)


# ── Menu flash (show menu multiple times fast then hold) ──────────────────────

def _flash_menu(show_menu_fn, flashes: int = 5) -> None:
    """
    Rapidly flash the menu screen — show it, clear it — building anticipation,
    then finally let it sit.
    """
    for i in range(flashes):
        _clear()
        show_menu_fn()
        delay = 0.08 + i * 0.06      # each flash slightly longer
        time.sleep(delay)
        if i < flashes - 1:
            _clear()
            time.sleep(0.05)
    # Final show :000 leave it on screen


# ── Main intro sequence ───────────────────────────────────────────────────────

def run_intro(operator_name: str, show_menu_fn) -> None:
    """
    Full cinematic intro sequence.

    Steps:
      1. Resize terminal to 120×42
      2. ASCII art reveal, line by line
      3. Hold 3 seconds
      4. Clear
      5. "Hello, {operator_name}"  — slow typewrite, centered
      6. Pause
      7. "system ready."  — dim, fast flicker, very brief
      8. Clear
      9. "CIRCUIT+"            — glitch effect, flash, gone
      10. Flash menu screen → final show

    Args:
        operator_name: The operator's alias (from config).
        show_menu_fn:  Callable that renders the main menu (no args).
    """
    try:
        # ── 1. Resize terminal ─────────────────────────────────────────────
        resize_terminal(cols=120, rows=42)

        # ── 2. ASCII art line-by-line ──────────────────────────────────────
        _show_art_line_by_line(delay=0.016)

        # ── 3. Hold 3 seconds ─────────────────────────────────────────────
        time.sleep(3.0)

        # ── 4. Clear ───────────────────────────────────────────────────────
        _clear()
        time.sleep(0.3)

        # ── 5. "Hello, {name}" ─────────────────────────────────────────────
        _write("\n\n\n")
        hello_text = f"Hello, {operator_name}."
        _typewrite_slow(
            _center_text(hello_text, 76),
            color=_WHITE,
            delay=0.11,
        )
        time.sleep(1.4)

        # ── 6. "system ready." ────────────────────────────────────
        _write("\n")
        wake_text = "system ready."
        _write(f"\r{_DIM}{_center_text(wake_text, 76)}{_RESET}")
        time.sleep(0.18)   # split-second visible
        _write(f"\r{' ' * 78}\r")   # erase it
        time.sleep(0.05)

        # ── 7. Clear + "CIRCUIT+" ──────────────────────────────────────
        _clear()
        time.sleep(0.1)

        fs_text = "CIRCUIT+"
        # Center it vertically-ish
        _write("\n" * 10)
        _glitch_line(
            _center_text(fs_text, 76),
            duration=0.5,
            color=_BRIGHT_GREEN,
        )
        time.sleep(0.1)

        # Flash screen on/off after the line
        for _ in range(6):
            _write(_CLEAR)
            time.sleep(0.04)
            _write(f"\n" * 10 + f"{_BRIGHT_GREEN}{_center_text(fs_text, 76)}{_RESET}\n")
            time.sleep(0.05)

        # ── 8. Flash menu ──────────────────────────────────────────────────
        _clear()
        time.sleep(0.1)
        _flash_menu(show_menu_fn, flashes=5)

    except KeyboardInterrupt:
        # Skip intro gracefully
        _clear()
        try:
            show_menu_fn()
        except Exception:
            pass
#is the benywise 
