#!/usr/bin/env python3
"""
CIRCUIT+ — Hub-and-spoke menu system with tips and section routing.
"""
from __future__ import annotations

import textwrap
from typing import Callable, Optional

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.columns import Columns
    from rich.text import Text
    from rich import box
except ImportError:
    pass

console = Console(highlight=False)

# ── Menu Item Type ─────────────────────────────────────────────────────────────
MenuItem = tuple[str, str, Callable]  



import random

# ── benywise ────────────────────────────────────────────
_TIPS: list[str] = [
    "Use [bold]Mass Scan[/bold] on an unknown target first — it maps the full surface in one run.",
    "Gobuster [bold]Full Scan[/bold] chains 5 modes automatically: dir, deep-dir, DNS, vhost, and backup files.",
    "[bold]small.txt[/bold] is ~950 words and finishes in seconds. [bold]big.txt[/bold] is ~20k — use it when quick gives no results.",
    "Run [bold]Probe Hosts[/bold] after subdomain enum to filter only live web targets before vuln scanning.",
    "Pass [bold]-json[/bold] output from nuclei directly into your CI/CD pipeline for automated triage.",
    "[bold]SSL certs[/bold] often leak internal hostnames in SANs — always check them on corporate targets.",
    "Use [bold]whois[/bold] on the IP (not just the domain) — the IP block may belong to a different org.",
    "[bold]X-Powered-By[/bold] and [bold]Server[/bold] headers reveal the stack. Missing them is a good sign.",
    "[bold]HSTS[/bold] missing = SSL stripping is possible. [bold]CSP[/bold] missing = XSS is likely easier to exploit.",
    "GeoIP says [bold]Hosting/DC[/bold]? The real server IP is probably behind a CDN — try origin hunting.",
    "Subfinder uses passive OSINT only — combine with [bold]DNS brute-force[/bold] for full coverage.",
    "Check [bold]/.git[/bold], [bold]/.env[/bold], [bold]/backup.zip[/bold] — exposed files are still found daily.",
    "[bold]traceroute[/bold] to an internal IP can leak cloud provider metadata and routing architecture.",
    "Nuclei template severity [bold]critical[/bold] first, then [bold]high[/bold]. Don't drown in info findings.",
    "The [bold]Port Check[/bold] tool uses raw Python sockets — no nmap needed for a quick connectivity test.",
    "[bold]VHost enumeration[/bold] can find hidden admin panels on shared hosting environments.",
    "Always check [bold]robots.txt[/bold] and [bold]sitemap.xml[/bold] — they're free recon.",
    "[bold]Wayback Machine[/bold] (via gau) reveals old paths that may still be accessible.",
    "Open [bold]Redis (6379)[/bold] without auth? Run [bold]INFO server[/bold] — often full RCE.",
    "MongoDB on [bold]27017[/bold] without auth exposes all databases. Check with mongostat.",
    "Set your [bold]threads[/bold] to 50 for local networks, 10-20 for external targets to stay polite.",
    "[bold]ARP scan[/bold] is the fastest way to map a local subnet — more reliable than ping.",
    "Combine katana + gau output to find [bold]hidden API endpoints[/bold] not in the sitemap.",
    "Use [bold]alterx[/bold] to generate subdomain permutations from existing subs — often finds more.",
    "The loot directory is timestamped — you can run multiple scans on the same target without overwriting.",
    "Check [bold]HTTP OPTIONS[/bold] method — servers that allow PUT/DELETE on web roots are wide open.",
    "[bold]SSRF[/bold] is often found in URL parameters that fetch remote resources. Always test fetch= and url=.",
    "Look for [bold]/api/swagger.json[/bold] or [bold]/openapi.json[/bold] — exposed API docs = free attack surface map.",
    "Tech fingerprint detects [bold]Cloudflare[/bold] — use DNS history tools to find the origin IP.",
    "[bold]Mass Scan[/bold] results save as both JSON (for scripting) and TXT (for humans).",
]


def get_tip() -> str:
    """Return a random tip string."""
    return random.choice(_TIPS)


# ══════════════════════════════════════════════════════════════════════════════
# HUB MENU  (5 section cards)
# ══════════════════════════════════════════════════════════════════════════════

_SECTIONS = [
    ("A", "SCANNING & RECON",
     "Recon · Web · Network · Workflows · Total Recon · Mass Scan · Mods",
     "bright_green"),
    ("B", "OSINT & INTEL",
     "Cloud Enum · CVE Correlator · Scan Diff · Screenshots",
     "bright_cyan"),
    ("C", "UTILITIES",
     "Network Toolkit · Plugins · Loot Browser · Sessions · Scope · Tutorial",
     "bright_yellow"),
    ("D", "SETTINGS & SYSTEM",
     "Config · Install Manager · Notifications · History · Export Report",
     "bright_magenta"),
    ("0", "EXIT", "Terminate CIRCUIT+ session", "dim"),
]


def build_main_table(operator: str = "operator") -> Table:
    table = Table(
        box=box.DOUBLE_EDGE,
        border_style="bright_green",
        show_header=True,
        header_style="bold bright_green",
        expand=False,
        min_width=66,
        padding=(0, 1),
    )
    table.add_column(" Key", style="bold", justify="center", width=5)
    table.add_column("Section",     style="bold", width=22)
    table.add_column("Contains",    style="dim",  width=46)

    for key, name, tools, color in _SECTIONS:
        style = "on grey11" if key in ("A","C") else ""
        table.add_row(
            f"[{color}][{key}][/{color}]",
            f"[{color}]{name}[/{color}]",
            tools,
            style=style,
        )
    return table


def show_main_menu(operator: str = "operator") -> None:
    """Render the hub menu."""
    table = build_main_table(operator)
    panel = Panel(
        table,
        title=f"[bold bright_green]// CIRCUIT+[/bold bright_green] [dim]v1.1 — {operator}[/dim]",
        subtitle="[dim]Type a letter (A/B/C/D) and press ENTER[/dim]",
        border_style="bright_green",
        padding=(0, 1),
    )
    console.print(panel)
    _tip = get_tip()
    _wrapped = "\n    ".join(textwrap.wrap(_tip, 70))
    console.print(f"[dim]  [bold cyan]Tip:[/bold cyan] {_wrapped}[/dim]\n")
    print("The install manager wont work so you have to run in every session, im not fixing it")

# ── Section Submenus ──────────────────────────────────────────────────────────

def show_section_a() -> None:
    """Section A — Scanning & Recon."""
    _show_submenu(
        title="// A — SCANNING & RECON",
        color="bright_green",
        items=[
            ("1",  "Reconnaissance",   "subfinder · dnsx · httpx · alterx · amass"),
            ("2",  "Web Assessment",   "ffuf · nuclei · gobuster · feroxbuster"),
            ("3",  "Network",          "rustscan · nmap · masscan · naabu"),
            ("4",  "Workflows",        "Automated full recon pipeline chains"),
            ("5",  "Mass Scan",        "10-phase intel dump — any IP/domain/URL"),
            ("6",  "Total Recon",      "16-phase full authorized domain recon"),
            ("7",  "Mods",             "Run .fscf automation scripts"),
            ("0",  "← Back",          "Return to main menu"),
        ],
    )


def show_section_b() -> None:
    """Section B — OSINT & Intelligence."""
    _show_submenu(
        title="// B — OSINT & INTEL",
        color="bright_cyan",
        items=[
            ("1",  "Cloud Enum",       "S3 · GCS · Azure open bucket hunting"),
            ("2",  "CVE Correlator",   "Tech fingerprint → known CVE matches"),
            ("3",  "Scan Diff",        "Compare two scan reports — what changed?"),
            ("4",  "Screenshots",      "gowitness visual gallery of live hosts"),
            ("0",  "← Back",          "Return to main menu"),
        ],
    )


def show_section_c() -> None:
    """Section C — Utilities."""
    _show_submenu(
        title="// C — UTILITIES",
        color="bright_yellow",
        items=[
            ("1",  "Network Toolkit",  "ping · dig · whois · curl · SSL · GeoIP"),
            ("2",  "Plugins",          "Community plugins — drop .py to add"),
            ("3",  "Loot Browser",     "Browse · view · copy past scan results"),
            ("4",  "Session Manager",  "Save · pause · resume scan sessions"),
            ("5",  "Scope Manager",    "Define and enforce authorized target scope"),
            ("6",  "Tutorial",         "Interactive guide for new users"),
            ("0",  "← Back",          "Return to main menu"),
        ],
    )


def show_section_d() -> None:
    """Section D — Settings & System."""
    _show_submenu(
        title="// D — SETTINGS",
        color="bright_magenta",
        items=[
            ("1",  "Configuration",   "Operator · wordlists · loot dir · threads"),
            ("2",  "Install Manager", "Install / update all security tools"),
            ("3",  "Notifications",   "Slack · Discord webhook config"),
            ("4",  "History",         "View past commands and findings"),
            ("5",  "Export Report",   "Generate HTML report from loot directory"),
            ("0",  "← Back",         "Return to main menu"),
        ],
    )


# ── Recon Submenu ─────────────────────────────────────────────────────────────
def show_recon_menu() -> None:
    """Display the Reconnaissance submenu."""
    _show_submenu(
        title="// RECONNAISSANCE",
        items=[
            ("1", "Subdomain Enumeration",  "subfinder + dnsx → live hosts"),
            ("2", "DNS Bruteforce",          "shuffledns/massdns with wordlist"),
            ("3", "Probe Hosts",             "httpx: tech detect, status codes"),
            ("4", "Alterx Permutations",     "Generate sub permutations (alterx)"),
            ("0", "← Back",                 "Return to main menu"),
        ]
    )


def show_web_menu() -> None:
    """Display the Web Assessment submenu."""
    _show_submenu(
        title="// WEB ASSESSMENT",
        items=[
            ("1", "Content Discovery",   "ffuf  — quick/normal/custom wordlist"),
            ("2", "Vulnerability Scan",  "nuclei templates: crit/high/med"),
            ("3", "Crawl Target",        "katana JS crawl + gau URL harvest"),
            ("4", "Feroxbuster Scan",    "Recursive dir brute-force (Rust)"),
            ("5", "Gobuster Scan",       "dir / dns / vhost brute-force"),
            ("0", "← Back",             "Return to main menu"),
        ]
    )


def show_network_menu() -> None:
    """Display the Network module submenu."""
    _show_submenu(
        title="// NETWORK",
        items=[
            ("1", "Port Scan (RustScan)", "Fast scan → nmap service/script"),
            ("2", "Nmap Direct",          "Full nmap with custom flags"),
            ("3", "Massive CIDR Scan",    "masscan high-rate CIDR sweep"),
            ("4", "Naabu Scan",           "projectdiscovery/naabu scanner"),
            ("0", "← Back",              "Return to main menu"),
        ]
    )


def show_workflow_menu() -> None:
    """Display the Workflow/Automation submenu."""
    _show_submenu(
        title="// WORKFLOWS",
        items=[
            ("1", "Full Recon Pipeline", "enum → probe → crawl → vuln scan"),
            ("2", "Web Target Chain",    "Content + vulns on single URL"),
            ("3", "Network Recon",       "RustScan + nmap + banner grab"),
            ("0", "← Back",             "Return to main menu"),
        ]
    )


def show_config_menu() -> None:
    """Display the Configuration submenu."""
    _show_submenu(
        title="// CONFIGURATION",
        items=[
            ("1", "View Config",       "Show current settings"),
            ("2", "Edit Operator",     "Change operator name"),
            ("3", "Set Wordlist Path", "Update wordlist directory"),
            ("4", "Set Threads",       "Adjust thread count"),
            ("5", "Set Loot Dir",      "Change output directory"),
            ("6", "Check Tools",       "Validate all binary dependencies"),
            ("0", "← Back",           "Return to main menu"),
        ]
    )


# ── Generic Submenu Renderer ──────────────────────────────────────────────────
def _show_submenu(title: str, items: list[tuple[str, str, str]],
                  color: str = "bright_green") -> None:
    """Render a submenu as a Rich Panel + Table."""
    table = Table(
        box=box.SIMPLE_HEAVY,
        border_style=color,
        show_header=False,
        expand=False,
        min_width=60,
        padding=(0, 1),
    )
    table.add_column("Key",   style=f"bold {color}",  justify="center", width=5)
    table.add_column("Item",  style="bold white",      width=22)
    table.add_column("Desc",  style="dim",             width=42)

    for i, (key, label, desc) in enumerate(items):
        style = "on grey11" if i % 2 == 0 else ""
        table.add_row(f"[{key}]", label, desc, style=style)

    panel = Panel(
        table,
        title=f"[bold {color}]{title}[/bold {color}]",
        subtitle=f"[dim][0] Back  [Ctrl+C] Cancel[/dim]",
        border_style=color,
        padding=(0, 1),
    )
    console.print(panel)


# ── Prompt / Choice ───────────────────────────────────────────────────────────
def get_choice(prompt: str = "circuit+> ", valid: Optional[list[str]] = None) -> str:
    """
    Prompt for user input, return the stripped string.
    Raises KeyboardInterrupt on Ctrl+C.
    """
    try:
        choice = input(f"\n\033[92m{prompt}\033[0m").strip()
        return choice
    except EOFError:
        return "0"


def divider(color: str = "bright_green") -> None:
    """Print a visual divider."""
    console.print(f"[{color}]{'─' * 60}[/{color}]")


def section_header(text: str) -> None:
    """Print a section header panel."""
    console.print(
        Panel(
            f"[bold white]{text}[/bold white]",
            border_style="bright_green",
            expand=False,
        )
    )
