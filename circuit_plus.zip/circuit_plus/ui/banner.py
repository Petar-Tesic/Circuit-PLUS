#!/usr/bin/env python3
"""
CIRCUIT+ — ASCII banners with random glitch-style variants.
"""

from __future__ import annotations

import random
import sys
import time

from rich.console import Console
from rich.text import Text

console = Console()

_BANNER_1 = r"""
_________ .__                     .__  __               
\_   ___ \|__|______   ____  __ __|__|/  |_     .__     
/    \  \/|  \_  __ \_/ ___\|  |  \  \   __\  __|  |___ 
\     \___|  ||  | \/\  \___|  |  /  ||  |   /__    __/ 
 \______  /__||__|    \___  >____/|__||__|      |__|    
        \/                \/                            """

_BANNER_2 = _BANNER_1 #i was going to make anotaher banner but i just gave up

_BANNER_3 = r"""
  ·▄▄▄  .▄▄ · ...
  ▐▄▄·▐█ ▀. ▪
  ██▪  ▄▀▀▀█▄ ▄█▀▄
  ██▌.▐█▄▪▐█▐█▌.▐▌
  ▀▀▀  ▀▀▀▀  ▀█▄▀▪   CIRCUIT+  ·  PWNING SINCE NEVER"""

_TAGLINES = [
    "// i defined a string at 4AM and tried to use it as a float",
    "// ok",
    "// [Insert hacker shit here]",
    "// if cybersecurity is your power, what are you without it?",
    "// oijewfoiawhe[oawe idk what to type anymore",
]

_BANNERS = [_BANNER_1, _BANNER_2, _BANNER_3]


def generate_banner() -> str:
    """Return a random banner string."""
    return random.choice(_BANNERS)


def display_banner(pause: float = 2.0) -> None:
    """
    Print a random banner with color, tagline, then pause.

    Args:
        pause: Seconds to display before clearing.
    """
    banner = generate_banner()
    tagline = random.choice(_TAGLINES)

    lines = banner.strip("\n").split("\n")
    colors = ["bright_green", "green", "dark_green"]

    console.print()
    for i, line in enumerate(lines):
        col = colors[i % len(colors)]
        console.print(line, style=col, highlight=False)

    console.print(f"\n  {tagline}", style="dim green")
    console.print(
        f"  [dim]v1.1  ·  python 3.10+  ·  authorized use only[/dim]",
    )
    console.print()

    time.sleep(pause)


def mini_banner() -> None:
    """Compact one-line logo for first-run and sub-screens."""
    console.print(
        " [bright_green]▶ CIRCUIT+[/bright_green]"
        " [dim green]// offensive security framework[/dim green]"
    )
    console.print()


# ── Aliases expected by main.py ───────────────────────────────────────────────
def print_banner(glitch: bool = True) -> None:
    """Alias for display_banner() — shows startup ASCII art for 2s then clears."""
    display_banner(pause=2.0)


def print_mini_banner() -> None:
    """Alias for mini_banner() — compact single-line header."""
    mini_banner()


def print_separator(char: str = "─", width: int = 60, color: str = "bright_green") -> None:
    """Print a separator line."""
    from rich.console import Console as _C
    _C(highlight=False).print(f"[{color}]{char * width}[/{color}]")
